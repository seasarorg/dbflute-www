#!/bin/sh

export MY_PROJECT_NAME=demo

export DBFLUTE_HOME=../mydbflute/dbflute-0.5.6
