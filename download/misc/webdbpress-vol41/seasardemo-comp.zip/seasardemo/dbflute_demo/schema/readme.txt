Directory for SchemaFile
