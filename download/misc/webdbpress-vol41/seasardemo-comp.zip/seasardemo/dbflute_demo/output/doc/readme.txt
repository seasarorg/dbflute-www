Directory for Document
