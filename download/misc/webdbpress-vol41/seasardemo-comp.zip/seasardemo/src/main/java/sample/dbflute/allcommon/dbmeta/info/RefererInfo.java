package sample.dbflute.allcommon.dbmeta.info;


import sample.dbflute.allcommon.dbmeta.DBMeta;

/**
 * The class of referer information.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class RefererInfo implements RelationInfo {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    protected String refererPropertyName;
    protected DBMeta localDBMeta;
    protected DBMeta refererDBMeta;
    protected java.util.Map<ColumnInfo, ColumnInfo> localRefererColumnInfoMap;
    protected java.util.Map<ColumnInfo, ColumnInfo> refererLocalColumnInfoMap;
    protected boolean oneToOne;

    // ===================================================================================
    //                                                                              Finder
    //                                                                              ======
    public ColumnInfo findLocalByReferer(String refererColumnDbName) {
        final ColumnInfo keyColumnInfo = new ColumnInfo(refererDBMeta, refererColumnDbName);
        final ColumnInfo resultColumnInfo = (ColumnInfo)refererLocalColumnInfoMap.get(keyColumnInfo);
        if (resultColumnInfo == null) {
            String msg = "Not found by refererColumnDbName in refererLocalColumnInfoMap:";
            msg = msg + " refererColumnDbName=" + refererColumnDbName + " refererLocalColumnInfoMap=" + refererLocalColumnInfoMap;
            throw new IllegalArgumentException(msg);
        }
        return resultColumnInfo;
    }

    public ColumnInfo findRefererByLocal(String localColumnDbName) {
        final ColumnInfo keyColumnInfo = new ColumnInfo(localDBMeta, localColumnDbName);
        final ColumnInfo resultColumnInfo = (ColumnInfo)localRefererColumnInfoMap.get(keyColumnInfo);
        if (resultColumnInfo == null) {
            String msg = "Not found by localColumnDbName in localRefererColumnInfoMap:";
            msg = msg + " localColumnDbName=" + localColumnDbName + " localRefererColumnInfoMap=" + localRefererColumnInfoMap;
            throw new IllegalArgumentException(msg);
        }
        return resultColumnInfo;
    }

    // ===================================================================================
    //                                                                             Builder
    //                                                                             =======
    public String buildInitCapPropertyName() {
        return initCap(this.refererPropertyName);
    }

    // ===================================================================================
    //                                                                              Finder
    //                                                                              ======
    public java.lang.reflect.Method findSetter() {
        return findMethod(localDBMeta.getEntityType(), "set" + buildInitCapPropertyName(), new Class[] { java.util.List.class });
    }

    public java.lang.reflect.Method findGetter() {
        return findMethod(localDBMeta.getEntityType(), "get" + buildInitCapPropertyName(), new Class[] {});
    }

    // ===================================================================================
    //                                                                           Implement
    //                                                                           =========
    public String getRelationPropertyName() {
        return getRefererPropertyName();
    }

    public DBMeta getTargetDBMeta() {
        return getRefererDBMeta();
    }

    public java.util.Map<ColumnInfo, ColumnInfo> getLocalTargetColumnInfoMap() {
        return getLocalRefererColumnInfoMap();
    }

    public boolean isReferer() {
        return true;
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    public String getRefererPropertyName() {
        return refererPropertyName;
    }

    public void setRefererPropertyName(String refererPropertyName) {
        this.refererPropertyName = refererPropertyName;
    }

    public DBMeta getLocalDBMeta() {
        return localDBMeta;
    }

    public void setLocalDBMeta(DBMeta localDBMeta) {
        this.localDBMeta = localDBMeta;
    }

    public DBMeta getRefererDBMeta() {
        return refererDBMeta;
    }

    public void setRefererDBMeta(DBMeta refererDBMeta) {
        this.refererDBMeta = refererDBMeta;
    }

    public java.util.Map<ColumnInfo, ColumnInfo> getLocalRefererColumnInfoMap() {
        return localRefererColumnInfoMap;
    }

    public void setLocalRefererColumnInfoMap(java.util.Map<ColumnInfo, ColumnInfo> localRefererColumnInfoMap) {
        this.localRefererColumnInfoMap = localRefererColumnInfoMap;
        final java.util.Set keySet = localRefererColumnInfoMap.keySet();
        refererLocalColumnInfoMap = new java.util.LinkedHashMap<ColumnInfo, ColumnInfo>();
        for (final java.util.Iterator ite = keySet.iterator(); ite.hasNext(); ) {
            final ColumnInfo key = (ColumnInfo)ite.next();
            final ColumnInfo value = (ColumnInfo)localRefererColumnInfoMap.get(key);
            refererLocalColumnInfoMap.put(value, key);
        }
    }

    public java.util.Map<ColumnInfo, ColumnInfo> getRefererLocalColumnInfoMap() {
        return refererLocalColumnInfoMap;
    }

    public boolean isOneToOne() {
        return oneToOne;
    }

    public void setOneToOne(boolean oneToOne) {
        this.oneToOne = oneToOne;
    }

    // ===================================================================================
    //                                                                     Internal Helper
    //                                                                     ===============
    protected String initCap(final String name) {
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    protected java.lang.reflect.Method findMethod(Class clazz, String methodName, Class[] argTypes) {
        try {
            return clazz.getMethod(methodName, argTypes);
        } catch (NoSuchMethodException ex) {
            String msg = "class=" + clazz + " method=" + methodName + "-" + java.util.Arrays.asList(argTypes);
            throw new RuntimeException(msg, ex);
        }
    }
}
