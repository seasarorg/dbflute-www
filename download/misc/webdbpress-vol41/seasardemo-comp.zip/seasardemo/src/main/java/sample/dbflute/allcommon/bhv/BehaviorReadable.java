package sample.dbflute.allcommon.bhv;

import sample.dbflute.allcommon.DaoSelector;
import sample.dbflute.allcommon.DaoReadable;
import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.cbean.ListResultBean;
import sample.dbflute.allcommon.cbean.OrderByBean;
import sample.dbflute.allcommon.cbean.PagingBean;
import sample.dbflute.allcommon.cbean.PagingResultBean;
import sample.dbflute.allcommon.dbmeta.DBMeta;

import sample.dbflute.allcommon.bhv.batch.TokenFileOutputOption;
import sample.dbflute.allcommon.bhv.batch.TokenFileOutputResult;

/**
 * The interface of behavior-readable.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface BehaviorReadable {

    // =====================================================================================
    //                                                                            Definition
    //                                                                            ==========
    /** Map-string map-mark. */
    public static final String MAP_STRING_MAP_MARK = "map:";

    /** Map-string list-mark. */
    public static final String MAP_STRING_LIST_MARK = "list:";

    /** Map-string start-brace. */
    public static final String MAP_STRING_START_BRACE = "@{";

    /** Map-string end-brace. */
    public static final String MAP_STRING_END_BRACE = "@}";

    /** Map-string delimiter. */
    public static final String MAP_STRING_DELIMITER = "@;";

    /** Map-string equal. */
    public static final String MAP_STRING_EQUAL = "@=";

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * Get table db-name.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName();

    // =====================================================================================
    //                                                                                DBMeta
    //                                                                                ======
    /**
     * Get dbmeta.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta();

    // =====================================================================================
    //                                                                          Dao Accessor
    //                                                                          ============
    /**
     * Get dao-readable.
     * 
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable getDaoReadable();

    /**
     * Get dao-selector.
     * 
     * @return Dao-selector.
     */
    public DaoSelector getDaoSelector();

    /**
     * Set dao-selector.
     * 
     * @param value Dao-selector.
     */
    public void setDaoSelector(DaoSelector value);

    // =====================================================================================
    //                                                                          New Instance
    //                                                                          ============
    /**
     * New entity.
     * 
     * @return Entity. (NotNull)
     */
    public Entity newEntity();

    /**
     * New condition-bean.
     * 
     * @return Condition-bean. (NotNull)
     */
    public ConditionBean newConditionBean();

    // =====================================================================================
    //                                                                         Basic Get All
    //                                                                         =============
    /**
     * Get count all.
     * 
     * @return Count all.
     */
    public int getCountAll();

    // =====================================================================================
    //                                                                      Basic Read Count
    //                                                                      ================
    /**
     * Read count by condition-bean.
     * <pre>
     * If the argument 'condition-bean' is effective about fetch-scope,
     * this method invoke select count ignoring the fetch-scope.
     * </pre>
     * @param cb Condition-bean. This condition-bean should not be set up about fetch-scope. (NotNull)
     * @return Read count. (NotNull)
     */
    public int readCount(ConditionBean cb);

    // =====================================================================================
    //                                                                     Basic Read Entity
    //                                                                     =================
    /**
     * Read entity by condition-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read entity. (Nullalble)
     * @exception sample.dbflute.allcommon.exception.RecordHasOverlappedException
     */
    public Entity readEntity(ConditionBean cb);

    /**
     * Read simple entity by condition-bean with deleted check.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Entity readEntityWithDeletedCheck(ConditionBean cb);

    // =====================================================================================
    //                                                                       Basic Read List
    //                                                                       ===============
    /**
     * Read list as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return List-result-bean. If the select result is zero, it returns empty list. (NotNull)
     */
    public ListResultBean<Entity> readList(ConditionBean cb);

    /**
     * Read page as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb);

    /**
     * Read page as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb, SelectPageInvoker<Entity> invoker);

    // ===================================================================================
    //                                                                            Sequence
    //                                                                            ========
    /**
     * The implementation.
     * 
     * @return The value of sequence. (NotNull)
     */
    public java.math.BigDecimal readNextVal();

    // =====================================================================================
    //                                                                            Token File
    //                                                                            ==========
    /**
     * Output token-file from this table records.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param filename Name of the file. (NotNull and NotEmpty)
     * @param tokenFileOutputOption token-file-output-option. (NotNull and Required{delimiter and encoding})
     * @return Token-file-output-result. (NotNull)
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public TokenFileOutputResult outputTokenFile(ConditionBean cb, String filename, TokenFileOutputOption tokenFileOutputOption) throws java.io.FileNotFoundException, java.io.IOException;

    /**
     * The interface of select-page callback.
     * 
     * @param <T> The generic template for 'selectedList'.
     */
    public static interface SelectPageCallback<T> {
        public PagingBean getPagingBean();
        public int selectCountIgnoreFetchScope();
        public java.util.List<T> selectListWithFetchScope();
    }

    /**
     * The object of result-bean builder.
     * 
     * @param <T> The generic template for 'resultBean'.
     */
    public static class ResultBeanBuilder<T> {
        protected BehaviorReadable _bhv;
        public ResultBeanBuilder(BehaviorReadable bhv) {
            _bhv = bhv;
        }
        /**
         * Build list-reuslt-bean.
         * 
         * @param ob Order-by-bean. (NotNull)
         * @param selectedList Selected list. (NotNull)
         * @return List-result-bean. (NotNull)
         */
        public ListResultBean<T> buildListResultBean(OrderByBean ob, java.util.List<T> selectedList) {
            ListResultBean<T> rb = new ListResultBean<T>();
            rb.setTableDbName(_bhv.getTableDbName());
            rb.setAllRecordCount(selectedList.size());
            rb.setSelectedList(selectedList);
            rb.setOrderByClause(ob.getSqlComponentOfOrderByClause());
            return rb;
        }
        /**
         * Build paging-reuslt-bean.
         * 
         * @param pb Paging-bean. (NotNull)
         * @param allRecordCount All-record-count.
         * @param selectedList Selected list. (NotNull)
         * @return Paging-result-bean. (NotNull)
         */
        public PagingResultBean<T> buildPagingResultBean(PagingBean pb, int allRecordCount, java.util.List<T> selectedList) {
            PagingResultBean<T> rb = new PagingResultBean<T>();
            rb.setTableDbName(_bhv.getTableDbName());
            rb.setAllRecordCount(allRecordCount);
            rb.setSelectedList(selectedList);
            rb.setPageSize(pb.getFetchSize());
            rb.setCurrentPageNumber(pb.getFetchPageNumber());
            rb.setOrderByClause(pb.getSqlComponentOfOrderByClause());
            return rb;
        }
    }

    public static interface SelectPageInvoker<T> {
        /**
         * Invoke select-page by callback.
         * 
         * @param callback Callback. (NotNull)
         * @return Paging-result-bean. (NotNull)
         */
        public PagingResultBean<T> invokeSelectPage(SelectPageCallback<T> callback);
    }

    /**
     * The object of result-bean builder.
     * 
     * @param <T> The generic template for 'resultBean'.
     */
    public static class SelectPageSimpleInvoker<T> implements SelectPageInvoker<T> {
        protected BehaviorReadable _bhv;
        public SelectPageSimpleInvoker(BehaviorReadable bhv) {
            _bhv = bhv;
        }

        /**
         * Invoke select-page by callback.
         * 
         * @param callback Callback. (NotNull)
         * @return Paging-result-bean. (NotNull)
         */
        public PagingResultBean<T> invokeSelectPage(SelectPageCallback<T> callback) {
            assertObjectNotNull("callback", callback);
            assertObjectNotNull("callback.getPagingBean()", callback.getPagingBean());
            if (!callback.getPagingBean().isFetchScopeEffective()) {
                String msg = "The paging bean is not effective about fetch-scope!";
                msg = msg + " When you select page, you should set up fetch-scope of paging bean(Should invoke fetchFirst() and fetchPage()!).";
                msg = msg + " The paging bean is: " + callback.getPagingBean();
                throw new IllegalStateException(msg);
            }
            final int allRecordCount = callback.selectCountIgnoreFetchScope();
            final java.util.List<T> selectedList = callback.selectListWithFetchScope();
            final PagingResultBean<T> rb = new ResultBeanBuilder<T>(_bhv).buildPagingResultBean(callback.getPagingBean(), allRecordCount, selectedList);
            if (isNecessaryToReadPageAgain(rb)) {
                callback.getPagingBean().fetchPage(rb.getAllPageCount());
                final int reAllRecordCount = callback.selectCountIgnoreFetchScope();
                final java.util.List<T> reSelectedList = callback.selectListWithFetchScope();
                return new ResultBeanBuilder<T>(_bhv).buildPagingResultBean(callback.getPagingBean(), reAllRecordCount, reSelectedList);
            } else {
                return rb;
            }
        }

        /**
         * Is it necessary to read page again?
         * 
         * @param rb Paging-result-bean. (NotNull)
         * @return Determination.
         */
        protected boolean isNecessaryToReadPageAgain(PagingResultBean<T> rb) {
            return rb.getAllRecordCount() > 0 && rb.getSelectedList().isEmpty();
        }

        /**
         * Assert that the object is not null.
         * 
         * @param variableName Variable name. (NotNull)
         * @param value Value. (NotNull)
         * @exception IllegalArgumentException
         */
        protected void assertObjectNotNull(String variableName, Object value) {
            if (variableName == null) {
                String msg = "The value should not be null: variableName=" + variableName + " value=" + value;
                throw new IllegalArgumentException(msg);
            }
            if (value == null) {
                String msg = "The value should not be null: variableName=" + variableName;
                throw new IllegalArgumentException(msg);
            }
        }
    }

    /**
     * The marker interface of simple condition-bean setupper.
     */
    public static interface SimpleCBSetupper {
    }
}
