package sample.dbflute.cbean.cq.ciq;

import sample.dbflute.cbean.cq.bs.*;

import sample.dbflute.allcommon.cbean.*;
import sample.dbflute.allcommon.cbean.ckey.*;
import sample.dbflute.allcommon.cbean.coption.ConditionOption;
import sample.dbflute.allcommon.cbean.cvalue.ConditionValue;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;

/**
 * The condition-inline-query of DEPT.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class DeptCIQ extends AbstractBsDeptCQ {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Corresponding condition query. */
    protected BsDeptCQ _myCQ;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     * @param myCQ Target wrapped condition-qyery. (NotNull)
     */
    public DeptCIQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel, BsDeptCQ myCQ) {
        super(childQuery, sqlClause, aliasName, nestLevel);
        _myCQ = myCQ;
        _foreignPropertyName = _myCQ.getForeignPropertyName();// Accept foreign property name.
        _relationPath = _myCQ.getRelationPath();// Accept relation path.
    }

    // ===================================================================================
    //                                                             Override about Register
    //                                                             =======================
    protected void reflectRelationOnUnionQuery(ConditionQuery baseQueryAsSuper, ConditionQuery unionQueryAsSuper) {
        throw new UnsupportedOperationException("InlineQuery must not need UNION method: " + baseQueryAsSuper + " : " + unionQueryAsSuper);
    }

    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName) {
        registerInlineQuery(key, value, cvalue, colName, capPropName, uncapPropName);
    }

    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName, ConditionOption option) {
        registerInlineQuery(key, value, cvalue, colName, capPropName, uncapPropName, option);
    }

    protected void registerWhereClause(String whereClause) {
        registerInlineWhereClause(whereClause);
    }

    protected String getInScopeSubQueryRealColumnName(String columnName) {
        return columnName;// No append alias name!
    }

    protected void registerExistsSubQuery(ConditionQuery subQuery
                                 , String columnName, String relatedColumnName, String propertyName) {
        throw new UnsupportedOperationException("Sorry! ExistsSubQuery at inline view is unsupported. So please use InScopeSubQyery.");
    }

    // ===================================================================================
    //                                                                Override about Query
    //                                                                ====================
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [DEPT]
    // * * * * * * * * */

  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [ID]
    // - - - - - - - - -/
    protected ConditionValue getCValueId() {
        return _myCQ.getId();
    }

                            
    public String keepId_InScopeSubQuery_EmpList(sample.dbflute.cbean.cq.EmpCQ subQuery) {
        return _myCQ.keepId_InScopeSubQuery_EmpList(subQuery);
    }
                                      
    public String keepId_ExistsSubQuery_EmpList(sample.dbflute.cbean.cq.EmpCQ subQuery) {
        throw new UnsupportedOperationException("ExistsSubQuery at inline() is unsupported! Sorry!");
        // _myCQ.keepId_ExistsSubQuery_EmpList(subQuery);
    }
                                                      
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [NAME]
    // - - - - - - - - -/
    protected ConditionValue getCValueName() {
        return _myCQ.getName();
    }

                                                            
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [VERSION_NO]
    // - - - - - - - - -/
    protected ConditionValue getCValueVersionNo() {
        return _myCQ.getVersionNo();
    }

                                                            
}
