package sample.web.emp;

import org.seasar.framework.container.annotation.tiger.Binding;
import org.seasar.framework.container.annotation.tiger.BindingType;

import sample.dbflute.exbhv.EmpBhv;
import sample.service.ValueLabelService;


public abstract class AbstractEmpPage {
	
	@Binding(bindingType = BindingType.MUST)
	public EmpBhv empBhv;

	@Binding(bindingType = BindingType.MUST)
	public EmpDxo empDxo;

	@Binding(bindingType = BindingType.MUST)	
	ValueLabelService valueLabelService;
	
	/** 
	 * Teedaの規約に沿って、レイアウトのhtmlファイルを指定します。
	 * getLayoutメソッドが存在しなければ、"/view/layout/layout.html" 
	 * が存在すればデフォルトレイアウトとして使用されます。
	 * getLayoutメソッドの戻り値が nullならば、レイアウトは適用されません。	 
	 */
//	public String getLayout() {
//		return null;
//	}

}
