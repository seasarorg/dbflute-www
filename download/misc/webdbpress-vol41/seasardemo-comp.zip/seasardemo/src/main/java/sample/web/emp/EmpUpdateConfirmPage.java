package sample.web.emp;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.seasar.teeda.extension.annotation.convert.DateTimeConverter;

import sample.dbflute.exentity.Emp;

public class EmpUpdateConfirmPage extends AbstractEmpPage {	
	
	// ##### プロパティ #####
	public Integer id;
	
	public String empName;
	
	@DateTimeConverter(pattern = "yyyy年MM月dd日")
	public Date hireDate;
	
	public Integer deptId;	

	public String deptIdLabel;
	
	public List<Map<String, Object>> deptIdItems;
	
	public Integer versionNo;
	
	
	// ##### ロジック #####	
	public Class doOnceUpdate() {
		Emp emp = empDxo.convert(this);
		empBhv.update(emp);
		return EmpUpdateCompletePage.class;
	}

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		deptIdLabel = valueLabelService.getDeptLabel(deptId);		
		return null;
	}

}
