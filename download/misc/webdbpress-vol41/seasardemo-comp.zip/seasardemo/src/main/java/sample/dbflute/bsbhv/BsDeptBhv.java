package sample.dbflute.bsbhv;


import java.util.List;

import sample.dbflute.allcommon.*;
import sample.dbflute.allcommon.bhv.setup.ConditionBeanSetupper;
import sample.dbflute.allcommon.bhv.setup.ValueLabelSetupper;
import sample.dbflute.allcommon.dbmeta.hierarchy.HierarchyArranger;
import sample.dbflute.allcommon.dbmeta.hierarchy.HierarchyBasicRequest;
import sample.dbflute.allcommon.dbmeta.hierarchy.HierarchyRequest;
import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.cbean.ListResultBean;
import sample.dbflute.allcommon.cbean.PagingBean;
import sample.dbflute.allcommon.cbean.PagingResultBean;
import sample.dbflute.allcommon.dbmeta.DBMeta;
  
import sample.dbflute.exbhv.*;
  
import sample.dbflute.exdao.*;
import sample.dbflute.exentity.*;
import sample.dbflute.bsentity.dbmeta.*;
import sample.dbflute.cbean.*;



/**
 * The behavior of DEPT.
 * 
 * <pre>
 * [primary-key]
 *     ID
 * 
 * [column-property]
 *     ID, NAME, VERSION_NO
 * 
 * [foreign-property]
 *     
 * 
 * [referer-property]
 *     empList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     VersionNo
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public abstract class BsDeptBhv extends sample.dbflute.allcommon.bhv.AbstractBehaviorWritable {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Dao instance. */
    protected DeptDao _dao;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    public BsDeptBhv() {
    }

    // ===================================================================================
    //                                                                          Table name
    //                                                                          ==========
    /**
     * The implementation.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return "DEPT";
    }

    // ===================================================================================
    //                                                                              DBMeta
    //                                                                              ======
    /**
     * The implementation.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return DeptDbm.getInstance();
    }

    /**
     * Get my dbmeta.
     * 
     * @return DBMeta. (NotNull)
     */
    public DeptDbm getMyDBMeta() {
        return DeptDbm.getInstance();
    }

    // ===================================================================================
    //                                                                        Dao Accessor
    //                                                                        ============
    /**
     * Get my dao.
     * 
     * @return My dao.
     */
    public DeptDao getMyDao() {
        return _dao;
    }

    /**
     * Set my dao.
     * 
     * @param dao My dao. (NotNull)
     */
    public void setMyDao(DeptDao dao) {
        assertObjectNotNull("dao", dao);
        _dao = dao;
    }

    /**
     * The implementation.
     * 
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable getDaoReadable() {
        return getMyDao();
    }

    /**
     * The implementation.
     * 
     * @return Dao-writable. (NotNull)
     */
    public DaoWritable getDaoWritable() {
        return getMyDao();
    }

    // ===================================================================================
    //                                                                        New Instance
    //                                                                        ============
    /**
     * New entity.
     * 
     * @return Entity. (NotNull)
     */
    public Entity newEntity() {
        return newMyEntity();
    }

    /**
     * New condition-bean.
     * 
     * @return Condition-bean. (NotNull)
     */
    public ConditionBean newConditionBean() {
        return newMyConditionBean();
    }

    /**
     * New my entity.
     * 
     * @return My entity. (NotNull)
     */
    public Dept newMyEntity() {
        return new Dept();
    }

    /**
     * New my condition-bean.
     * 
     * @return My condition-bean. (NotNull)
     */
    public DeptCB newMyConditionBean() {
        return new DeptCB();
    }

    // ===================================================================================
    //                                                                     Delegate Method
    //                                                                     ===============
    // -----------------------------------------------------
    //                                                Select
    //                                                ------
    /**
     * Get count as all. {delegate method}
     * 
     * @return All count. (NotNull)
     */
    public int delegateGetCountAll() {
        return getMyDao().getCountAll();
    }

    /**
     * Get list as all. {delegate method}
     * 
     * @return All list. (NotNull)
     */
    public List<Dept> delegateGetListAll() {
        return getMyDao().getListAll();
    }

    //
    // Get entity. {delegate method}
    // 
    // @param Primary-keys (NotNull)
    // @return Entity. (NotNull)
    //
    public Dept delegateGetEntity(java.lang.Integer id) {
        return getMyDao().getEntity(id);
    }

    /**
     * Select count by condition-bean. {delegate method}
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     */
    public int delegateSelectCount(DeptCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectCount(cb);
    }

    /**
     * Select entity by condition-bean. {delegate method}
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. If the select result is zero, it returns null. (Nullable)
     */
    public Dept delegateSelectEntity(DeptCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectEntity(cb);
    }

    /**
     * Select list by condition-bean. {delegate method}
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list. If the select result is zero, it returns empty list. (NotNull)
     */
    public List<Dept> delegateSelectList(DeptCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectList(cb);
    }


    // -----------------------------------------------------
    //                                                Update
    //                                                ------
    /**
     * Insert one entity. {delegate method}
     * 
     * @param entity Entity. (NotNull)
     * @return Inserted count.
     */
    public int delegateInsert(Dept entity) {
        if (!processBeforeInsert(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().insert(entity);
    }

    /**
     * Update one entity. {delegate method & modified only}
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int delegateUpdate(Dept entity) {
        if (!processBeforeUpdate(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().updateModifiedOnly(entity);
    }

    /**
     * Update one entity non-strictly. {delegate method & modified only}
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int delegateUpdateNonstrict(Dept entity) {
        if (!processBeforeUpdate(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().updateNonstrictModifiedOnly(entity);
    }

    /**
     * Delete one entity. {delegate method}
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delegateDelete(Dept entity) {
        if (!processBeforeDelete(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().delete(entity);
    }

    /**
     * Delete one entity non-strictly. {delegate method}
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delegateDeleteNonstrict(Dept entity) {
        if (!processBeforeDelete(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().deleteNonstrict(entity);
    }


    /**
     * Insert several entities. {delegate method}
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of inserted count.
     */
    public int[] delegateInsertList(List<Dept> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeInsertInternally(entityList);
        return getMyDao().insertList(entityList);
    }

    /**
     * Update several entities. {delegate method} <br />
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of updated count.
     */
    public int[] delegateUpdateList(List<Dept> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeUpdateInternally(entityList);
        return getMyDao().updateList(entityList);
    }

    /**
     * Update several entities non-strictly. {delegate method} <br />
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of updated count.
     */
    public int[] delegateUpdateListNonstrict(List<Dept> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeUpdateInternally(entityList);
        return getMyDao().updateListNonstrict(entityList);
    }

    /**
     * Delete several entities. {delegate method}
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of deleted count.
     */
    public int[] delegateDeleteList(List<Dept> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeDeleteInternally(entityList);
        return getMyDao().deleteList(entityList);
    }

    /**
     * Delete several entities non-strictly. {delegate method}
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of deleted count.
     */
    public int[] delegateDeleteListNonstrict(List<Dept> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeDeleteInternally(entityList);
        return getMyDao().deleteListNonstrict(entityList);
    }

    // ===================================================================================
    //                                                                  Basic Select Count
    //                                                                  ==================
    /**
     * Select count by condition-bean.
     * <pre>
     * If the argument 'condition-bean' is effective about fetch-scope,
     * this method invoke select count ignoring the fetch-scope.
     * </pre>
     * @param cb Condition-bean. This condition-bean should not be set up about fetch-scope. (NotNull)
     * @return Selected count.
     */
    public int selectCount(DeptCB cb) {
        assertConditionBeanNotNull(cb);
        return delegateSelectCount(cb);
    }

    // ===================================================================================
    //                                                                 Basic Select Entity
    //                                                                 ===================
    /**
     * Select entity by condition-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. (Nullalble)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Dept selectEntity(final DeptCB cb) {
        return helpSelectEntityInternally(cb, new InternalSelectEntityCallback<Dept, DeptCB>() {
            public List<Dept> callbackSelectList(DeptCB cb) { return selectList(cb); } });
    }

    /**
     * Select entity by condition-bean with deleted check.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Dept selectEntityWithDeletedCheck(final DeptCB cb) {
        return helpSelectEntityWithDeletedCheckInternally(cb, new InternalSelectEntityWithDeletedCheckCallback<Dept, DeptCB>() {
            public List<Dept> callbackSelectList(DeptCB cb) { return selectList(cb); } });
    }

    /*
     * Select entity with deleted check. {by primary-key}
     * 
     * @param primaryKey
     * @return Selected entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Dept selectByPKValueWithDeletedCheck(java.lang.Integer id) {
        Dept entity = new Dept();
        entity.setId(id);
        final DeptCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(entity));
        return selectEntityWithDeletedCheck(cb);
    }


    // ===================================================================================
    //                                                                   Basic Select List
    //                                                                   =================
    /**
     * Select list as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list-result-bean. (NotNull)
     */
    public ListResultBean<Dept> selectList(DeptCB cb) {
        assertConditionBeanNotNull(cb);
        return new ResultBeanBuilder<Dept>(this).buildListResultBean(cb, delegateSelectList(cb));
    }

    /**
     * Select page as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected paging-result-bean. (NotNull)
     */
    public PagingResultBean<Dept> selectPage(final DeptCB cb) {
        assertConditionBeanNotNull(cb);
        return selectPage(cb, new SelectPageSimpleInvoker<Dept>(this));
    }

    /**
     * Select page.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Selected paging-result-bean. (NotNull)
     */
    public PagingResultBean<Dept> selectPage(final DeptCB cb, SelectPageInvoker<Dept> invoker) {
        assertConditionBeanNotNull(cb);
        final SelectPageCallback<Dept> pageCallback = new SelectPageCallback<Dept>() {
            public PagingBean getPagingBean() { return cb; }
            public int selectCountIgnoreFetchScope() { return selectCount(cb); }
            public List<Dept> selectListWithFetchScope() { return selectList(cb); }
        };
        return invoker.invokeSelectPage(pageCallback);
    }

    // ===================================================================================
    //                                                                      Various Select
    //                                                                      ==============
    /**
     * Select value-label list.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param valueLabelSetupper Value-label-setupper. (NotNull)
     * @return Value-label list. (NotNull)
     */
    public List<java.util.Map<String, Object>> selectValueLabelList(DeptCB cb, ValueLabelSetupper<Dept> valueLabelSetupper) {
        return createValueLabelList(selectList(cb), valueLabelSetupper);
    }

    // ===================================================================================
    //                                                                        Load Referer
    //                                                                        ============
  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   RefererTable    = [EMP]
    //   RefererProperty = [empList]
    // * * * * * * * * */

    /**
     * Load referer of empList.
     * <pre>
     *   You can load referer.
     * 
     *   ex) {Client Example}
     *     final DeptCB cb = new DeptCB();
     *     cb.query().setXxx_Equal("xxx");
     *     final List&lt;Dept&gt; deptList = deptBhv.selectList(cb);
     *     deptBhv.loadEmpList(deptList);
     * 
     *   *About internal policy, the value of primary key(and others too) is treated as CaseInsensitive.
     * </pre>
     * 
     * @param deptList Entity list of dept. (NotNull)
     */
    public void loadEmpList(List<Dept> deptList) {
        final ConditionBeanSetupper<EmpCB> conditionBeanSetupper = new ConditionBeanSetupper<EmpCB>() {
            public void setup(EmpCB cb) {}
        };
        loadEmpList(deptList, conditionBeanSetupper);
    }

    /**
     * Load referer of empList.
     * <pre>
     *   You can load referer with your original condition.
     * 
     *   ex) {Client Example}: Referer conditions are 'Xxx' is not null and order-by 'Yyy' desc
     *     /- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *     final DeptCB cb = new DeptCB();
     *     cb.query().setXxx_Equal("xxx");
     *     final List&lt;Dept&gt; deptList = deptBhv.selectList(cb);
     *     final ConditionBeanSetupper&lt;EmpCB&gt; conditionBeanSetupper = new ConditionBeanSetupper&lt;EmpCB&gt;() {
     *         public void setup(EmpCB cb) {
     *             cb.query().setXxx_IsNotNull();
     *             cb.query().addOrderBy_Yyy_Desc();
     *         }
     *     };
     *     deptBhv.loadEmpList(deptList, conditionBeanSetupper);
     *     - - - - - - - - - -/
     * 
     *   The condition-bean that the setupper provides have settings before you touch it. It is as follows:
     *     /- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *     cb.query().setDeptId_InScope(pkList);
     *     cb.query().addOrderBy_DeptId_Asc();
     *     - - - - - - - - - -/
     * 
     *   *About internal policy, the value of primary key(and others too) is treated as CaseInsensitive.
     * </pre>
     * 
     * @param deptList Entity list of dept. (NotNull)
     * @param conditionBeanSetupper Referer condition setupper instance for registering referer condition. (NotNull)
     */
    public void loadEmpList(List<Dept> deptList, ConditionBeanSetupper<EmpCB> conditionBeanSetupper) {
        assertObjectNotNull("deptList<Dept>", deptList);
        assertObjectNotNull("conditionBeanSetupper<EmpCB>", conditionBeanSetupper);
        if (deptList.isEmpty()) { return; }
        loadEmpList(deptList, new sample.dbflute.allcommon.bhv.load.LoadRefererOption<EmpCB, Emp>(conditionBeanSetupper));
    }

    /**
     * Load referer of empList.
     * <pre>
     *   You can load referer with your original condition.
     * 
     *   ex) {Client Example}: Referer conditions are 'Xxx' is not null and order-by 'Yyy' desc
     *     /- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *     final DeptCB cb = new DeptCB();
     *     cb.query().setXxx_Equal("xxx");
     *     final List&lt;Dept&gt; deptList = deptBhv.selectList(cb);
     *     final ConditionBeanSetupper&lt;EmpCB&gt; cbSetupper = new ConditionBeanSetupper&lt;EmpCB&gt;() {
     *         public void setup(EmpCB cb) {
     *             cb.query().setXxx_IsNotNull();
     *             cb.query().addOrderBy_Yyy_Desc();
     *         }
     *     };
     *     deptBhv.loadEmpList(deptList, new LoadRefererOption<EmpCB, Emp>(cbSetupper));
     *     - - - - - - - - - -/
     * 
     *   The condition-bean that the setupper provides have settings before you touch it. It is as follows:
     *     /- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *     cb.query().setDeptId_InScope(pkList);
     *     cb.query().addOrderBy_DeptId_Asc();
     *     - - - - - - - - - -/
     * 
     *   *About internal policy, the value of primary key(and others too) is treated as CaseInsensitive.
     * </pre>
     * 
     * @param deptList Entity list of dept. (NotNull)
     * @param loadRefererOption Load-referer option. (NotNull)
     */
    public void loadEmpList(List<Dept> deptList, sample.dbflute.allcommon.bhv.load.LoadRefererOption<EmpCB, Emp> loadRefererOption) {
        assertObjectNotNull("deptList<Dept>", deptList);
        assertObjectNotNull("loadRefererOption<Emp, EmpCB>", loadRefererOption);
        if (deptList.isEmpty()) { return; }
        final EmpBhv refererBhv = getBehaviorSelector().select(EmpBhv.class);
        helpLoadRefererInternally(deptList, loadRefererOption, new InternalLoadRefererCallback<Dept, java.lang.Integer, EmpCB, Emp>() {
            public java.lang.Integer callbackBase_getPrimaryKeyValue(Dept entity) { return entity.getId(); }
            public void callbackBase_setRefererList(Dept entity, List<Emp> refererList) { entity.setEmpList(refererList); }
            public EmpCB callbackReferer_newMyConditionBean() { return refererBhv.newMyConditionBean(); }
            public void callbackReferer_queryForeignKeyInScope(EmpCB cb, List<java.lang.Integer> pkList) { cb.query().setDeptId_InScope(pkList); }
            public void callbackReferer_queryAddOrderByForeignKeyAsc(EmpCB cb) { cb.query().addOrderBy_DeptId_Asc(); }
            public List<Emp> callbackReferer_selectList(EmpCB cb) { return refererBhv.selectList(cb); }
            public java.lang.Integer callbackReferer_getForeignKeyValue(Emp entity) { return entity.getDeptId(); }
            public void callbackReferer_setForeignEntity(Emp refererEntity, Dept baseEntity) { refererEntity.setDept(baseEntity); }
        } );
    }
  
    // ===================================================================================
    //                                                                    Pull Out Foreign
    //                                                                    ================
  
    // ===================================================================================
    //                                                                 Basic Entity Update
    //                                                                 ===================
    /**
     * Insert.
     * 
     * @param dept Entity. (NotNull)
     */
    public void insert(Dept dept) {
        assertEntityNotNull(dept);
        delegateInsert(dept);
    }

    protected void doCreate(Entity dept) {
        insert((Dept)dept);
    }

    /**
     * Update. {modified only} <br />
     * If it updates count zero, throws exception. <br />
     * If concurrency control of this table is valid, this update have it. <br />
     * So then the entity of argument should have the value of concurrency column.
     * 
     * @param dept Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void update(final Dept dept) {
        helpUpdateInternally(dept, new InternalUpdateCallback<Dept>() {
            public int callbackDelegateUpdate(Dept entity) { return delegateUpdate(entity); } });
    }

    protected void doModify(Entity entity) {
        update((Dept)entity);
    }

    /**
     * Update non-strictly. {modified only} <br />
     * This update ignores concurrency control. <br />
     * So if the entity of argument have the value of concurrency column, it is ignored.
     * 
     * @param dept Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void updateNonstrict(final Dept dept) {
        helpUpdateNonstrictInternally(dept, new InternalUpdateNonstrictCallback<Dept>() {
            public int callbackDelegateUpdateNonstrict(Dept entity) { return delegateUpdateNonstrict(entity); } });
    }

    protected void doModifyNonstrict(Entity entity) {
        updateNonstrict((Dept)entity);
    }

    /**
     * Update after select. {modified only}
     * <pre>
     * The merit of this method is only Deleted-Check before updating!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param dept Entity. This must contain primary-key value at least. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     * @deprecated Thie method is old style and has wrong performance. Please use update().
     */
    public void updateAfterSelect(Dept dept) {
        assertEntityNotNullAndHasPrimaryKeyValue(dept);
        final DeptCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(dept));
        final Dept currentEntity = selectEntityWithDeletedCheck(cb);
        mergeEntity(dept, currentEntity);
        update(currentEntity);
    }

    protected void doModifyAfterSelect(Entity entity) {
        updateAfterSelect((Dept)entity);
    }

    /**
     * Insert or update. {update: modified only}
     * 
     * @param dept Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void insertOrUpdate(final Dept dept) {
        helpInsertOrUpdateInternally(dept, new InternalInsertOrUpdateCallback<Dept, DeptCB>() {
            public void callbackInsert(Dept entity) { insert(entity); }
            public void callbackUpdate(Dept entity) { update(entity); }
            public DeptCB callbackNewMyConditionBean() { return newMyConditionBean(); }
            public int callbackSelectCount(DeptCB cb) { return selectCount(cb); }
        });
    }

    protected void doCreateOrUpdate(Entity dept) {
        insertOrUpdate((Dept)dept);
    }

    /**
     * Insert or update non-strictly. {update: modified only}
     * 
     * @param dept Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     * @deprecated Sorry! Please use insertOrUpdateNonstrict(). This method name is wrong name.
     */
    public void insertOrUpdateNonStrict(Dept dept) {
        insertOrUpdateNonstrict(dept);
    }

    /**
     * Insert or update non-strictly. {update: modified only}
     * 
     * @param dept Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void insertOrUpdateNonstrict(Dept dept) {
        helpInsertOrUpdateInternally(dept, new InternalInsertOrUpdateNonstrictCallback<Dept>() {
            public void callbackInsert(Dept entity) { insert(entity); }
            public void callbackUpdateNonstrict(Dept entity) { updateNonstrict(entity); }
        });
    }

    protected void doCreateOrUpdateNonstrict(Entity entity) {
        insertOrUpdateNonstrict((Dept)entity);
    }

    /**
     * Insert or update after select. {update: modified properties only}
     * <pre>
     * The merit of this method is only Deleted-Check before updating!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param dept Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @deprecated Thie method is old style and has wrong performance. Please use insertOrUpdate().
     */
    public void insertOrUpdateAfterSelect(Dept dept) {
        assertEntityNotNull(dept);
        if (!dept.hasPrimaryKeyValue()) {
            insert(dept);
            return;
        }
        Dept currentEntity = null;
        try {
            final DeptCB cb = newMyConditionBean();
            cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(dept));
            currentEntity = selectEntityWithDeletedCheck(cb);
        } catch (sample.dbflute.allcommon.exception.EntityAlreadyDeletedException e) {
            insert(dept);
            return;
        }
        assertEntityNotNullAndHasPrimaryKeyValue(dept);
        mergeEntity(dept, currentEntity);
        update(currentEntity);
    }

    protected void doCreateOrModifyAfterSelect(Entity entity) {
        insertOrUpdateAfterSelect((Dept)entity);
    }


    /**
     * The implementation.
     * 
     * @param sourceEntity Source entity. (NotNull)
     * @param destinationEntity Destination entity. (NotNull)
     * @deprecated Thie method is old style and has wrong performance.
     */
    protected void mergeEntity(Entity sourceEntity, Entity destinationEntity) {
        assertEntityNotNull(sourceEntity);
        assertEntityNotNull(destinationEntity);
        final Dept sourceMyEntity = (Dept)sourceEntity;
        final Dept destinationMyEntity = (Dept)destinationEntity;
        destinationMyEntity.clearModifiedPropertyNames();
        final java.util.Set<String> names = sourceMyEntity.getModifiedPropertyNames();

        if (names.contains("id")) { destinationMyEntity.setId(sourceMyEntity.getId()); }
        if (names.contains("name")) { destinationMyEntity.setName(sourceMyEntity.getName()); }
        if (names.contains("versionNo")) { destinationMyEntity.setVersionNo(sourceMyEntity.getVersionNo()); }

    }

    /**
     * Delete.
     * 
     * @param dept Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void delete(Dept dept) {
        helpDeleteInternally(dept, new InternalDeleteCallback<Dept>() {
            public int callbackDelegateDelete(Dept entity) { return delegateDelete(entity); } });
    }

    protected void doRemove(Entity dept) {
        delete((Dept)dept);
    }

    /**
     * Delete after select.
     * <pre>
     * The merit of this method is only Deleted-Check before deleting!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param dept Entity. This must contain primary-key value at least. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     * @deprecated Thie method is old style and has wrong performance. Please use delete().
     */
    public void deleteAfterSelect(Dept dept) {
        assertEntityNotNullAndHasPrimaryKeyValue(dept);
        final DeptCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(dept));
        selectEntityWithDeletedCheck(cb);
        delete(dept);
    }

    /**
     * @param dept Entity. This must contain primary-key value at least. (NotNull)
     * @deprecated Thie method is old style and has wrong performance. Please use delete().
     */
    protected void doRemoveAfterSelect(Entity entity) {
        deleteAfterSelect((Dept)entity);
    }

    /**
     * Delete non-strictly. <br />
     * This delete ignores concurrency control.
     * 
     * @param dept Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void deleteNonstrict(Dept dept) {
        helpDeleteNonstrictInternally(dept, new InternalDeleteNonstrictCallback<Dept>() {
            public int callbackDelegateDeleteNonstrict(Dept entity) { return delegateDeleteNonstrict(entity); } });
    }

    /**
     * Delete non-strictly ignoring deleted. <br />
     * This delete ignores concurrency control.
     * 
     * @param dept Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void deleteNonstrictIgnoreDeleted(Dept dept) {
        helpDeleteNonstrictIgnoreDeletedInternally(dept, new InternalDeleteNonstrictIgnoreDeletedCallback<Dept>() {
            public int callbackDelegateDeleteNonstrict(Dept entity) { return delegateDeleteNonstrict(entity); } });
    }


    // ===================================================================================
    //                                                                  Basic Batch Update
    //                                                                  ==================
    /**
     * Batch insert the list. This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param deptList Entity-list. (NotNull)
     * @return The array of inserted count.
     */
    public int[] batchInsert(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return delegateInsertList(deptList);
    }

    /**
     * Insert list. <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param deptList Entity-list. (NotNull)
     * @return Inserted count.
     * @deprecated Sorry! This method name is very confusing. Please use batchInsert().
     */
    public int insertList(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return batchInsert(deptList).length;
    }

    /**
     * Batch update the list. All columns are update target. {NOT modified only} <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param deptList Entity-list. (NotNull)
     * @return The array of updated count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] batchUpdate(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return delegateUpdateList(deptList);
    }

    /**
     * Batch update the list non-strictly. All columns are update target. {NOT modified only} <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param deptList Entity-list. (NotNull)
     * @return The array of updated count.
     */
    public int[] batchUpdateNonstrict(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return delegateUpdateListNonstrict(deptList);
    }

    /**
     * Update batch. All columns are update target. {NOT modified only} <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param deptList Entity-list. (NotNull)
     * @return Updated count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use batchUpdate().
     */
    public int updateList(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return batchUpdate(deptList).length;
    }

    /**
     * Batch delete the list. <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param deptList Entity-list. (NotNull)
     * @return The array of deleted count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] batchDelete(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return delegateDeleteList(deptList);
    }

    /**
     * Batch delete the list non-strictly. <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param deptList Entity-list. (NotNull)
     * @return The array of deleted count.
     */
    public int[] batchDeleteNonstrict(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return delegateDeleteListNonstrict(deptList);
    }

    /**
     * Delete list by Batch. This method use 'Batch Update' of java.sql.PreparedStatement. <br />
     * 
     * @param deptList Entity-list. (NotNull)
     * @return Deleted count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use batchDelete().
     */
    public int deleteList(List<Dept> deptList) {
        assertObjectNotNull("deptList", deptList);
        return batchDelete(deptList).length;
    }

    // ===================================================================================
    //                                                                      Various Insert
    //                                                                      ==============
    // ===================================================================================
    //                                                                      Various Update
    //                                                                      ==============

    // ===================================================================================
    //                                                                           Hierarchy
    //                                                                           =========
    /**
     * Create the basic request of hierarchy of Dept..
     * 
     * @param sourceList The list of source. (NotNull)
     * @param <SOURCE> The type of source.
     * @return Hierarchy request of Dept. (NotNull)
     */
    public <SOURCE> HierarchyBasicRequest<Dept, DeptDbm.DeptRelationTrace> createHierarchyBasicRequest(List<SOURCE> sourceList) {
        final HierarchyBasicRequest<Dept, DeptDbm.DeptRelationTrace> request = new HierarchyBasicRequest<Dept, DeptDbm.DeptRelationTrace>(Dept.class);
        request.registerSourceList(sourceList);
        return request;
    }

    /**
     * Arrange hierarchy.
     * 
     * @param request Hierarchy request of Dept. (NotNull)
     * @return The list of Dept. (NotNull)
     */
    public List<Dept> arrangeHierarchy(HierarchyRequest<Dept> request) {
        return new HierarchyArranger<Dept>().arrangeHierarchy(request);
    }

    // ===================================================================================
    //                                                                          CBSetupper
    //                                                                          ==========
    /**
     * The interface of condition-bean setupper.
     */
    public static interface CBSetupper extends ConditionBeanSetupper<DeptCB> {

        /**
         * Set up condition.
         * 
         * @param cb Condition-bean. (NotNull)
         */
        public void setup(DeptCB cb);
    }

    // ===================================================================================
    //                                                                              Helper
    //                                                                              ======
    protected Dept downcast(Entity entity) {
        return helpDowncastInternally(entity, Dept.class);
    }
}
