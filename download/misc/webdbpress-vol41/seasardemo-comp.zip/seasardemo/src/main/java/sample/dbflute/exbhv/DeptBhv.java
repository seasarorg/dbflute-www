package sample.dbflute.exbhv;


/**
 * The behavior of DEPT.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class DeptBhv extends sample.dbflute.bsbhv.BsDeptBhv {
}
