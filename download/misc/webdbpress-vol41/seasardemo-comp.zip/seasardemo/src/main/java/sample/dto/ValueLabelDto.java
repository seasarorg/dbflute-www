package sample.dto;

import java.io.Serializable;

public class ValueLabelDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public Object value;
	
	public String label;
	
}
