package sample.dbflute.cbean.nss;


import sample.dbflute.cbean.cq.EmpCQ;


/**
 * The nest select setupper of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class EmpNss {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Base query. */
    protected EmpCQ _query;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param query Base query. (NotNull)
     */
    public EmpNss(EmpCQ query) {
        _query = query;
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    /**
     * Has condition query?
     * 
     * @return Determination.
     */
    public boolean hasConditionQuery() {
        return _query != null;
    }

    // ===================================================================================
    //                                                                             With...
    //                                                                             =======

    /** Is select dept? */
    protected boolean _isSelectDept;

    /**
     * Is select dept?
     * 
     * @return Determination.
     */
    public boolean isSelectDept() {
        return _isSelectDept;
    }

    /**
     * Set up select with dept.
     */
    public void withDept() {
        assertConditionQuery();
        _query.queryDept();
        _isSelectDept = true;
    }

    // ===================================================================================
    //                                                                              Helper
    //                                                                              ======
    protected void assertConditionQuery() {
        if (!hasConditionQuery()) {
            String msg = "The query should not be null.";
            throw new IllegalStateException(msg);
        }
    }
}
