package sample.dbflute.bsbhv;


import java.util.List;

import sample.dbflute.allcommon.*;
import sample.dbflute.allcommon.bhv.setup.ConditionBeanSetupper;
import sample.dbflute.allcommon.bhv.setup.ValueLabelSetupper;
import sample.dbflute.allcommon.dbmeta.hierarchy.HierarchyArranger;
import sample.dbflute.allcommon.dbmeta.hierarchy.HierarchyBasicRequest;
import sample.dbflute.allcommon.dbmeta.hierarchy.HierarchyRequest;
import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.cbean.ListResultBean;
import sample.dbflute.allcommon.cbean.PagingBean;
import sample.dbflute.allcommon.cbean.PagingResultBean;
import sample.dbflute.allcommon.dbmeta.DBMeta;
  
import sample.dbflute.exdao.*;
import sample.dbflute.exentity.*;
import sample.dbflute.bsentity.dbmeta.*;
import sample.dbflute.cbean.*;



/**
 * The behavior of EMP.
 * 
 * <pre>
 * [primary-key]
 *     ID
 * 
 * [column-property]
 *     ID, NAME, HIRE_DATE, DEPT_ID, VERSION_NO
 * 
 * [foreign-property]
 *     dept
 * 
 * [referer-property]
 *     
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     VersionNo
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public abstract class BsEmpBhv extends sample.dbflute.allcommon.bhv.AbstractBehaviorWritable {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Dao instance. */
    protected EmpDao _dao;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    public BsEmpBhv() {
    }

    // ===================================================================================
    //                                                                          Table name
    //                                                                          ==========
    /**
     * The implementation.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return "EMP";
    }

    // ===================================================================================
    //                                                                              DBMeta
    //                                                                              ======
    /**
     * The implementation.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return EmpDbm.getInstance();
    }

    /**
     * Get my dbmeta.
     * 
     * @return DBMeta. (NotNull)
     */
    public EmpDbm getMyDBMeta() {
        return EmpDbm.getInstance();
    }

    // ===================================================================================
    //                                                                        Dao Accessor
    //                                                                        ============
    /**
     * Get my dao.
     * 
     * @return My dao.
     */
    public EmpDao getMyDao() {
        return _dao;
    }

    /**
     * Set my dao.
     * 
     * @param dao My dao. (NotNull)
     */
    public void setMyDao(EmpDao dao) {
        assertObjectNotNull("dao", dao);
        _dao = dao;
    }

    /**
     * The implementation.
     * 
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable getDaoReadable() {
        return getMyDao();
    }

    /**
     * The implementation.
     * 
     * @return Dao-writable. (NotNull)
     */
    public DaoWritable getDaoWritable() {
        return getMyDao();
    }

    // ===================================================================================
    //                                                                        New Instance
    //                                                                        ============
    /**
     * New entity.
     * 
     * @return Entity. (NotNull)
     */
    public Entity newEntity() {
        return newMyEntity();
    }

    /**
     * New condition-bean.
     * 
     * @return Condition-bean. (NotNull)
     */
    public ConditionBean newConditionBean() {
        return newMyConditionBean();
    }

    /**
     * New my entity.
     * 
     * @return My entity. (NotNull)
     */
    public Emp newMyEntity() {
        return new Emp();
    }

    /**
     * New my condition-bean.
     * 
     * @return My condition-bean. (NotNull)
     */
    public EmpCB newMyConditionBean() {
        return new EmpCB();
    }

    // ===================================================================================
    //                                                                     Delegate Method
    //                                                                     ===============
    // -----------------------------------------------------
    //                                                Select
    //                                                ------
    /**
     * Get count as all. {delegate method}
     * 
     * @return All count. (NotNull)
     */
    public int delegateGetCountAll() {
        return getMyDao().getCountAll();
    }

    /**
     * Get list as all. {delegate method}
     * 
     * @return All list. (NotNull)
     */
    public List<Emp> delegateGetListAll() {
        return getMyDao().getListAll();
    }

    //
    // Get entity. {delegate method}
    // 
    // @param Primary-keys (NotNull)
    // @return Entity. (NotNull)
    //
    public Emp delegateGetEntity(java.lang.Integer id) {
        return getMyDao().getEntity(id);
    }

    /**
     * Select count by condition-bean. {delegate method}
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     */
    public int delegateSelectCount(EmpCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectCount(cb);
    }

    /**
     * Select entity by condition-bean. {delegate method}
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. If the select result is zero, it returns null. (Nullable)
     */
    public Emp delegateSelectEntity(EmpCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectEntity(cb);
    }

    /**
     * Select list by condition-bean. {delegate method}
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list. If the select result is zero, it returns empty list. (NotNull)
     */
    public List<Emp> delegateSelectList(EmpCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectList(cb);
    }


    // -----------------------------------------------------
    //                                                Update
    //                                                ------
    /**
     * Insert one entity. {delegate method}
     * 
     * @param entity Entity. (NotNull)
     * @return Inserted count.
     */
    public int delegateInsert(Emp entity) {
        if (!processBeforeInsert(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().insert(entity);
    }

    /**
     * Update one entity. {delegate method & modified only}
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int delegateUpdate(Emp entity) {
        if (!processBeforeUpdate(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().updateModifiedOnly(entity);
    }

    /**
     * Update one entity non-strictly. {delegate method & modified only}
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int delegateUpdateNonstrict(Emp entity) {
        if (!processBeforeUpdate(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().updateNonstrictModifiedOnly(entity);
    }

    /**
     * Delete one entity. {delegate method}
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delegateDelete(Emp entity) {
        if (!processBeforeDelete(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().delete(entity);
    }

    /**
     * Delete one entity non-strictly. {delegate method}
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delegateDeleteNonstrict(Emp entity) {
        if (!processBeforeDelete(entity)) { return 1;/*as Normal End*/ }
        return getMyDao().deleteNonstrict(entity);
    }


    /**
     * Insert several entities. {delegate method}
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of inserted count.
     */
    public int[] delegateInsertList(List<Emp> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeInsertInternally(entityList);
        return getMyDao().insertList(entityList);
    }

    /**
     * Update several entities. {delegate method} <br />
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of updated count.
     */
    public int[] delegateUpdateList(List<Emp> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeUpdateInternally(entityList);
        return getMyDao().updateList(entityList);
    }

    /**
     * Update several entities non-strictly. {delegate method} <br />
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of updated count.
     */
    public int[] delegateUpdateListNonstrict(List<Emp> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeUpdateInternally(entityList);
        return getMyDao().updateListNonstrict(entityList);
    }

    /**
     * Delete several entities. {delegate method}
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of deleted count.
     */
    public int[] delegateDeleteList(List<Emp> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeDeleteInternally(entityList);
        return getMyDao().deleteList(entityList);
    }

    /**
     * Delete several entities non-strictly. {delegate method}
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return The array of deleted count.
     */
    public int[] delegateDeleteListNonstrict(List<Emp> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeDeleteInternally(entityList);
        return getMyDao().deleteListNonstrict(entityList);
    }

    // ===================================================================================
    //                                                                  Basic Select Count
    //                                                                  ==================
    /**
     * Select count by condition-bean.
     * <pre>
     * If the argument 'condition-bean' is effective about fetch-scope,
     * this method invoke select count ignoring the fetch-scope.
     * </pre>
     * @param cb Condition-bean. This condition-bean should not be set up about fetch-scope. (NotNull)
     * @return Selected count.
     */
    public int selectCount(EmpCB cb) {
        assertConditionBeanNotNull(cb);
        return delegateSelectCount(cb);
    }

    // ===================================================================================
    //                                                                 Basic Select Entity
    //                                                                 ===================
    /**
     * Select entity by condition-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. (Nullalble)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Emp selectEntity(final EmpCB cb) {
        return helpSelectEntityInternally(cb, new InternalSelectEntityCallback<Emp, EmpCB>() {
            public List<Emp> callbackSelectList(EmpCB cb) { return selectList(cb); } });
    }

    /**
     * Select entity by condition-bean with deleted check.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Emp selectEntityWithDeletedCheck(final EmpCB cb) {
        return helpSelectEntityWithDeletedCheckInternally(cb, new InternalSelectEntityWithDeletedCheckCallback<Emp, EmpCB>() {
            public List<Emp> callbackSelectList(EmpCB cb) { return selectList(cb); } });
    }

    /*
     * Select entity with deleted check. {by primary-key}
     * 
     * @param primaryKey
     * @return Selected entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Emp selectByPKValueWithDeletedCheck(java.lang.Integer id) {
        Emp entity = new Emp();
        entity.setId(id);
        final EmpCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(entity));
        return selectEntityWithDeletedCheck(cb);
    }


    // ===================================================================================
    //                                                                   Basic Select List
    //                                                                   =================
    /**
     * Select list as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list-result-bean. (NotNull)
     */
    public ListResultBean<Emp> selectList(EmpCB cb) {
        assertConditionBeanNotNull(cb);
        return new ResultBeanBuilder<Emp>(this).buildListResultBean(cb, delegateSelectList(cb));
    }

    /**
     * Select page as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected paging-result-bean. (NotNull)
     */
    public PagingResultBean<Emp> selectPage(final EmpCB cb) {
        assertConditionBeanNotNull(cb);
        return selectPage(cb, new SelectPageSimpleInvoker<Emp>(this));
    }

    /**
     * Select page.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Selected paging-result-bean. (NotNull)
     */
    public PagingResultBean<Emp> selectPage(final EmpCB cb, SelectPageInvoker<Emp> invoker) {
        assertConditionBeanNotNull(cb);
        final SelectPageCallback<Emp> pageCallback = new SelectPageCallback<Emp>() {
            public PagingBean getPagingBean() { return cb; }
            public int selectCountIgnoreFetchScope() { return selectCount(cb); }
            public List<Emp> selectListWithFetchScope() { return selectList(cb); }
        };
        return invoker.invokeSelectPage(pageCallback);
    }

    // ===================================================================================
    //                                                                      Various Select
    //                                                                      ==============
    /**
     * Select value-label list.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param valueLabelSetupper Value-label-setupper. (NotNull)
     * @return Value-label list. (NotNull)
     */
    public List<java.util.Map<String, Object>> selectValueLabelList(EmpCB cb, ValueLabelSetupper<Emp> valueLabelSetupper) {
        return createValueLabelList(selectList(cb), valueLabelSetupper);
    }

    // ===================================================================================
    //                                                                        Load Referer
    //                                                                        ============
  
    // ===================================================================================
    //                                                                    Pull Out Foreign
    //                                                                    ================

    /**
     * Pull out the list of foreign table 'Dept'.
     * 
     * @param empList The list of emp. (NotNull)
     * @return The list of foreign table. (NotNull)
     */
    public List<Dept> pulloutDept(List<Emp> empList) {
        return helpPulloutInternally(empList, new InternalPulloutCallback<Emp, Dept>() {
            public Dept callbackGetForeignEntity(Emp entity) { return entity.getDept(); } });
    }

    // ===================================================================================
    //                                                                 Basic Entity Update
    //                                                                 ===================
    /**
     * Insert.
     * 
     * @param emp Entity. (NotNull)
     */
    public void insert(Emp emp) {
        assertEntityNotNull(emp);
        delegateInsert(emp);
    }

    protected void doCreate(Entity emp) {
        insert((Emp)emp);
    }

    /**
     * Update. {modified only} <br />
     * If it updates count zero, throws exception. <br />
     * If concurrency control of this table is valid, this update have it. <br />
     * So then the entity of argument should have the value of concurrency column.
     * 
     * @param emp Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void update(final Emp emp) {
        helpUpdateInternally(emp, new InternalUpdateCallback<Emp>() {
            public int callbackDelegateUpdate(Emp entity) { return delegateUpdate(entity); } });
    }

    protected void doModify(Entity entity) {
        update((Emp)entity);
    }

    /**
     * Update non-strictly. {modified only} <br />
     * This update ignores concurrency control. <br />
     * So if the entity of argument have the value of concurrency column, it is ignored.
     * 
     * @param emp Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void updateNonstrict(final Emp emp) {
        helpUpdateNonstrictInternally(emp, new InternalUpdateNonstrictCallback<Emp>() {
            public int callbackDelegateUpdateNonstrict(Emp entity) { return delegateUpdateNonstrict(entity); } });
    }

    protected void doModifyNonstrict(Entity entity) {
        updateNonstrict((Emp)entity);
    }

    /**
     * Update after select. {modified only}
     * <pre>
     * The merit of this method is only Deleted-Check before updating!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param emp Entity. This must contain primary-key value at least. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     * @deprecated Thie method is old style and has wrong performance. Please use update().
     */
    public void updateAfterSelect(Emp emp) {
        assertEntityNotNullAndHasPrimaryKeyValue(emp);
        final EmpCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(emp));
        final Emp currentEntity = selectEntityWithDeletedCheck(cb);
        mergeEntity(emp, currentEntity);
        update(currentEntity);
    }

    protected void doModifyAfterSelect(Entity entity) {
        updateAfterSelect((Emp)entity);
    }

    /**
     * Insert or update. {update: modified only}
     * 
     * @param emp Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void insertOrUpdate(final Emp emp) {
        helpInsertOrUpdateInternally(emp, new InternalInsertOrUpdateCallback<Emp, EmpCB>() {
            public void callbackInsert(Emp entity) { insert(entity); }
            public void callbackUpdate(Emp entity) { update(entity); }
            public EmpCB callbackNewMyConditionBean() { return newMyConditionBean(); }
            public int callbackSelectCount(EmpCB cb) { return selectCount(cb); }
        });
    }

    protected void doCreateOrUpdate(Entity emp) {
        insertOrUpdate((Emp)emp);
    }

    /**
     * Insert or update non-strictly. {update: modified only}
     * 
     * @param emp Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     * @deprecated Sorry! Please use insertOrUpdateNonstrict(). This method name is wrong name.
     */
    public void insertOrUpdateNonStrict(Emp emp) {
        insertOrUpdateNonstrict(emp);
    }

    /**
     * Insert or update non-strictly. {update: modified only}
     * 
     * @param emp Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void insertOrUpdateNonstrict(Emp emp) {
        helpInsertOrUpdateInternally(emp, new InternalInsertOrUpdateNonstrictCallback<Emp>() {
            public void callbackInsert(Emp entity) { insert(entity); }
            public void callbackUpdateNonstrict(Emp entity) { updateNonstrict(entity); }
        });
    }

    protected void doCreateOrUpdateNonstrict(Entity entity) {
        insertOrUpdateNonstrict((Emp)entity);
    }

    /**
     * Insert or update after select. {update: modified properties only}
     * <pre>
     * The merit of this method is only Deleted-Check before updating!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param emp Entity. This should contain primary-key value at least(Except use identity). (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @deprecated Thie method is old style and has wrong performance. Please use insertOrUpdate().
     */
    public void insertOrUpdateAfterSelect(Emp emp) {
        assertEntityNotNull(emp);
        if (!emp.hasPrimaryKeyValue()) {
            insert(emp);
            return;
        }
        Emp currentEntity = null;
        try {
            final EmpCB cb = newMyConditionBean();
            cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(emp));
            currentEntity = selectEntityWithDeletedCheck(cb);
        } catch (sample.dbflute.allcommon.exception.EntityAlreadyDeletedException e) {
            insert(emp);
            return;
        }
        assertEntityNotNullAndHasPrimaryKeyValue(emp);
        mergeEntity(emp, currentEntity);
        update(currentEntity);
    }

    protected void doCreateOrModifyAfterSelect(Entity entity) {
        insertOrUpdateAfterSelect((Emp)entity);
    }


    /**
     * The implementation.
     * 
     * @param sourceEntity Source entity. (NotNull)
     * @param destinationEntity Destination entity. (NotNull)
     * @deprecated Thie method is old style and has wrong performance.
     */
    protected void mergeEntity(Entity sourceEntity, Entity destinationEntity) {
        assertEntityNotNull(sourceEntity);
        assertEntityNotNull(destinationEntity);
        final Emp sourceMyEntity = (Emp)sourceEntity;
        final Emp destinationMyEntity = (Emp)destinationEntity;
        destinationMyEntity.clearModifiedPropertyNames();
        final java.util.Set<String> names = sourceMyEntity.getModifiedPropertyNames();

        if (names.contains("id")) { destinationMyEntity.setId(sourceMyEntity.getId()); }
        if (names.contains("name")) { destinationMyEntity.setName(sourceMyEntity.getName()); }
        if (names.contains("hireDate")) { destinationMyEntity.setHireDate(sourceMyEntity.getHireDate()); }
        if (names.contains("deptId")) { destinationMyEntity.setDeptId(sourceMyEntity.getDeptId()); }
        if (names.contains("versionNo")) { destinationMyEntity.setVersionNo(sourceMyEntity.getVersionNo()); }

    }

    /**
     * Delete.
     * 
     * @param emp Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void delete(Emp emp) {
        helpDeleteInternally(emp, new InternalDeleteCallback<Emp>() {
            public int callbackDelegateDelete(Emp entity) { return delegateDelete(entity); } });
    }

    protected void doRemove(Entity emp) {
        delete((Emp)emp);
    }

    /**
     * Delete after select.
     * <pre>
     * The merit of this method is only Deleted-Check before deleting!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param emp Entity. This must contain primary-key value at least. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     * @deprecated Thie method is old style and has wrong performance. Please use delete().
     */
    public void deleteAfterSelect(Emp emp) {
        assertEntityNotNullAndHasPrimaryKeyValue(emp);
        final EmpCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(emp));
        selectEntityWithDeletedCheck(cb);
        delete(emp);
    }

    /**
     * @param emp Entity. This must contain primary-key value at least. (NotNull)
     * @deprecated Thie method is old style and has wrong performance. Please use delete().
     */
    protected void doRemoveAfterSelect(Entity entity) {
        deleteAfterSelect((Emp)entity);
    }

    /**
     * Delete non-strictly. <br />
     * This delete ignores concurrency control.
     * 
     * @param emp Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void deleteNonstrict(Emp emp) {
        helpDeleteNonstrictInternally(emp, new InternalDeleteNonstrictCallback<Emp>() {
            public int callbackDelegateDeleteNonstrict(Emp entity) { return delegateDeleteNonstrict(entity); } });
    }

    /**
     * Delete non-strictly ignoring deleted. <br />
     * This delete ignores concurrency control.
     * 
     * @param emp Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void deleteNonstrictIgnoreDeleted(Emp emp) {
        helpDeleteNonstrictIgnoreDeletedInternally(emp, new InternalDeleteNonstrictIgnoreDeletedCallback<Emp>() {
            public int callbackDelegateDeleteNonstrict(Emp entity) { return delegateDeleteNonstrict(entity); } });
    }


    // ===================================================================================
    //                                                                  Basic Batch Update
    //                                                                  ==================
    /**
     * Batch insert the list. This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param empList Entity-list. (NotNull)
     * @return The array of inserted count.
     */
    public int[] batchInsert(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return delegateInsertList(empList);
    }

    /**
     * Insert list. <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param empList Entity-list. (NotNull)
     * @return Inserted count.
     * @deprecated Sorry! This method name is very confusing. Please use batchInsert().
     */
    public int insertList(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return batchInsert(empList).length;
    }

    /**
     * Batch update the list. All columns are update target. {NOT modified only} <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param empList Entity-list. (NotNull)
     * @return The array of updated count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] batchUpdate(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return delegateUpdateList(empList);
    }

    /**
     * Batch update the list non-strictly. All columns are update target. {NOT modified only} <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param empList Entity-list. (NotNull)
     * @return The array of updated count.
     */
    public int[] batchUpdateNonstrict(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return delegateUpdateListNonstrict(empList);
    }

    /**
     * Update batch. All columns are update target. {NOT modified only} <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param empList Entity-list. (NotNull)
     * @return Updated count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use batchUpdate().
     */
    public int updateList(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return batchUpdate(empList).length;
    }

    /**
     * Batch delete the list. <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param empList Entity-list. (NotNull)
     * @return The array of deleted count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] batchDelete(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return delegateDeleteList(empList);
    }

    /**
     * Batch delete the list non-strictly. <br />
     * This method use 'Batch Update' of java.sql.PreparedStatement.
     * 
     * @param empList Entity-list. (NotNull)
     * @return The array of deleted count.
     */
    public int[] batchDeleteNonstrict(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return delegateDeleteListNonstrict(empList);
    }

    /**
     * Delete list by Batch. This method use 'Batch Update' of java.sql.PreparedStatement. <br />
     * 
     * @param empList Entity-list. (NotNull)
     * @return Deleted count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use batchDelete().
     */
    public int deleteList(List<Emp> empList) {
        assertObjectNotNull("empList", empList);
        return batchDelete(empList).length;
    }

    // ===================================================================================
    //                                                                      Various Insert
    //                                                                      ==============
    // ===================================================================================
    //                                                                      Various Update
    //                                                                      ==============

    // ===================================================================================
    //                                                                           Hierarchy
    //                                                                           =========
    /**
     * Create the basic request of hierarchy of Emp..
     * 
     * @param sourceList The list of source. (NotNull)
     * @param <SOURCE> The type of source.
     * @return Hierarchy request of Emp. (NotNull)
     */
    public <SOURCE> HierarchyBasicRequest<Emp, EmpDbm.EmpRelationTrace> createHierarchyBasicRequest(List<SOURCE> sourceList) {
        final HierarchyBasicRequest<Emp, EmpDbm.EmpRelationTrace> request = new HierarchyBasicRequest<Emp, EmpDbm.EmpRelationTrace>(Emp.class);
        request.registerSourceList(sourceList);
        return request;
    }

    /**
     * Arrange hierarchy.
     * 
     * @param request Hierarchy request of Emp. (NotNull)
     * @return The list of Emp. (NotNull)
     */
    public List<Emp> arrangeHierarchy(HierarchyRequest<Emp> request) {
        return new HierarchyArranger<Emp>().arrangeHierarchy(request);
    }

    // ===================================================================================
    //                                                                          CBSetupper
    //                                                                          ==========
    /**
     * The interface of condition-bean setupper.
     */
    public static interface CBSetupper extends ConditionBeanSetupper<EmpCB> {

        /**
         * Set up condition.
         * 
         * @param cb Condition-bean. (NotNull)
         */
        public void setup(EmpCB cb);
    }

    // ===================================================================================
    //                                                                              Helper
    //                                                                              ======
    protected Emp downcast(Entity entity) {
        return helpDowncastInternally(entity, Emp.class);
    }
}
