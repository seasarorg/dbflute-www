package sample.dbflute.cbean.cq.bs;


import sample.dbflute.allcommon.cbean.*;
import sample.dbflute.allcommon.cbean.cvalue.ConditionValue;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;
import sample.dbflute.cbean.cq.ciq.*;

/**
 * The condition-query of DEPT.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class BsDeptCQ extends AbstractBsDeptCQ {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Corresponding inline query. */
    protected DeptCIQ _inlineQuery;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public BsDeptCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // ===================================================================================
    //                                                                              Inline
    //                                                                              ======
    /**
     * Get inline query.
     * 
     * @return Inline query. (NotNull)
     */
    public DeptCIQ inline() {
        if (_inlineQuery == null) {
            _inlineQuery = new DeptCIQ(getChildQuery(), getSqlClause(), getAliasName(), getNestLevel(), this);
        }
        return _inlineQuery;
    }

    // ===================================================================================
    //                                                                     Include-as-Mine
    //                                                                     ===============
  
    /**
     * Include select-column of id as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Id() {
        registerIncludedSelectColumn("Id", getRealColumnName("ID"));
    }

    /**
     * Include select-column of id as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Id(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("ID"));
    }
  
    /**
     * Include select-column of name as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Name() {
        registerIncludedSelectColumn("Name", getRealColumnName("NAME"));
    }

    /**
     * Include select-column of name as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Name(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("NAME"));
    }
  
    /**
     * Include select-column of versionNo as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_VersionNo() {
        registerIncludedSelectColumn("VersionNo", getRealColumnName("VERSION_NO"));
    }

    /**
     * Include select-column of versionNo as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_VersionNo(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("VERSION_NO"));
    }
  
    // ===================================================================================
    //                                                                               Query
    //                                                                               =====
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [DEPT]
    // * * * * * * * * */
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [ID]
    // - - - - - - - - -/

    /** The attribute of id. */
    protected ConditionValue _id;

    /**
     * Get the value of id.
     * 
     * @return The value of id.
     */
    public ConditionValue getId() {
        if (_id == null) {
            _id = new ConditionValue();
        }
        return _id;
    }

    protected ConditionValue getCValueId() {
        return getId();
    }

                            
    /** The sub-query of Id_InScopeSubQuery_EmpList using inScopeSubQuery. */
    protected java.util.Map<String, sample.dbflute.cbean.cq.EmpCQ> _id_InScopeSubQuery_EmpListMap;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmpList using inScopeSubQuery.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmpList using inScopeSubQuery. (Nullable)
     */
    public java.util.Map<String, sample.dbflute.cbean.cq.EmpCQ> getId_InScopeSubQuery_EmpList() {
        return _id_InScopeSubQuery_EmpListMap;
    }

    public String keepId_InScopeSubQuery_EmpList(sample.dbflute.cbean.cq.EmpCQ subQuery) {
        if (_id_InScopeSubQuery_EmpListMap == null) { _id_InScopeSubQuery_EmpListMap = new java.util.LinkedHashMap<String, sample.dbflute.cbean.cq.EmpCQ>(); }
        final String key = "subQueryMapKey" + (_id_InScopeSubQuery_EmpListMap.size() + 1);
        _id_InScopeSubQuery_EmpListMap.put(key, subQuery);
        return "id_InScopeSubQuery_EmpList." + key;
    }
                                      
    /** The sub-query of Id_ExistsSubQuery_EmpList using existsSubQuery. */
    protected java.util.Map<String, sample.dbflute.cbean.cq.EmpCQ> _id_ExistsSubQuery_EmpListMap;

    /**
     * Get the sub-query of Id_ExistsSubQuery_EmpList using existsSubQuery.
     * 
     * @return The sub-query of Id_ExistsSubQuery_EmpList using existsSubQuery. (Nullable)
     */
    public java.util.Map<String, sample.dbflute.cbean.cq.EmpCQ> getId_ExistsSubQuery_EmpList() {
        return _id_ExistsSubQuery_EmpListMap;
    }

    public String keepId_ExistsSubQuery_EmpList(sample.dbflute.cbean.cq.EmpCQ subQuery) {
        if (_id_ExistsSubQuery_EmpListMap == null) { _id_ExistsSubQuery_EmpListMap = new java.util.LinkedHashMap<String, sample.dbflute.cbean.cq.EmpCQ>(); }
        final String key = "subQueryMapKey" + (_id_ExistsSubQuery_EmpListMap.size() + 1);
        _id_ExistsSubQuery_EmpListMap.put(key, subQuery);
        return "id_ExistsSubQuery_EmpList." + key;
    }
                                            
    /**
     * Add order-by of id as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Id_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("ID"), null, true);return this;
    }

    /**
     * Add order-by of id as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Id_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("ID"), null, false);return this;
    }
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [NAME]
    // - - - - - - - - -/

    /** The attribute of name. */
    protected ConditionValue _name;

    /**
     * Get the value of name.
     * 
     * @return The value of name.
     */
    public ConditionValue getName() {
        if (_name == null) {
            _name = new ConditionValue();
        }
        return _name;
    }

    protected ConditionValue getCValueName() {
        return getName();
    }

                                                  
    /**
     * Add order-by of name as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Name_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("NAME"), null, true);return this;
    }

    /**
     * Add order-by of name as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Name_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("NAME"), null, false);return this;
    }
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [VERSION_NO]
    // - - - - - - - - -/

    /** The attribute of versionNo. */
    protected ConditionValue _versionNo;

    /**
     * Get the value of versionNo.
     * 
     * @return The value of versionNo.
     */
    public ConditionValue getVersionNo() {
        if (_versionNo == null) {
            _versionNo = new ConditionValue();
        }
        return _versionNo;
    }

    protected ConditionValue getCValueVersionNo() {
        return getVersionNo();
    }

                                                  
    /**
     * Add order-by of versionNo as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_VersionNo_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("VERSION_NO"), null, true);return this;
    }

    /**
     * Add order-by of versionNo as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_VersionNo_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("VERSION_NO"), null, false);return this;
    }
  
    // ===================================================================================
    //                                                                         Union Query
    //                                                                         ===========
    protected void reflectRelationOnUnionQuery(ConditionQuery baseQueryAsSuper, ConditionQuery unionQueryAsSuper) {

    }

    // ===================================================================================
    //                                                                       Foreign Query
    //                                                                       =============


}
