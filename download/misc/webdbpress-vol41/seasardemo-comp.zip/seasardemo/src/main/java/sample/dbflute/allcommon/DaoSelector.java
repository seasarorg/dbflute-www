package sample.dbflute.allcommon;

import sample.dbflute.allcommon.bhv.BehaviorReadable;

/**
 * The interface of dao-selector.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface DaoSelector {

    /**
     * Select dao.
     * 
     * @param <DAO_TYPE> The type of behavior.
     * @param daoType Dao type. (NotNull)
     * @return Dao. (NotNull)
     */
    public <DAO_TYPE extends DaoReadable> DAO_TYPE select(Class<DAO_TYPE> daoType);

    /**
     * Select dao-readable by name.
     * 
     * @param tableFlexibleName Table flexible name. (NotNull)
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable byName(String tableFlexibleName);



    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * Deprecated
    /**
     * Get dao.
     * 
     * @param <DAO_TYPE> The type of dao.
     * @param daoType Dao type. (NotNull)
     * @return Dao. (NotNull)
     * @deprecated Please Use select()
     */
    public <DAO_TYPE extends DaoReadable> DAO_TYPE getDao(Class<DAO_TYPE> daoType);

    /**
     * Get dao-readable.
     * 
     * @param tableMultiName Table multi-name. (NotNull)
     * @return Dao-readable. (NotNull)
     * @deprecated Please Use byName()
     */
    public DaoReadable byNameAsDaoReadable(String tableMultiName);

    /**
     * Get behavior.
     * 
     * @param <BEHAVIOR_TYPE> The type of behavior.
     * @param behaviorType Behavior type. (NotNull)
     * @return Behavior. (NotNull)
     * @deprecated Please Use BehaviorSelect#select()
     */
    public <BEHAVIOR_TYPE extends BehaviorReadable> BEHAVIOR_TYPE getBehavior(Class<BEHAVIOR_TYPE> behaviorType);

    /**
     * Get behavior-readable.
     * 
     * @param tableMultiName Table multi-name. (NotNull)
     * @return Behavior-readable. (NotNull)
     * @deprecated Please Use BehaviorSelect#byName()
     */
    public BehaviorReadable byNameAsBehaviorReadable(String tableMultiName);
}
