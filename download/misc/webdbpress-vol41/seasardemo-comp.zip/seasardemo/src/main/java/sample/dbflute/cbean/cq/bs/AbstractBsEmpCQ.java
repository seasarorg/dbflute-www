package sample.dbflute.cbean.cq.bs;



import sample.dbflute.allcommon.cbean.*;
import sample.dbflute.allcommon.cbean.ckey.*;
import sample.dbflute.allcommon.cbean.cvalue.ConditionValue;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;

/**
 * The condition-query of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public abstract class AbstractBsEmpCQ extends AbstractConditionQuery {

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public AbstractBsEmpCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // ===================================================================================
    //                                                                          Table Name
    //                                                                          ==========
    /**
     * The implementation.
     * 
     * @return Table db-name. (NotNull)
     */
    final public String getTableDbName() {
        return "EMP";
    }

    // ===================================================================================
    //                                                                               Query
    //                                                                               =====
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [EMP]
    // * * * * * * * * */
              
    /**
     * Set the value of id using equal. { = }
     * 
     * @param id The value of id as equal.
     */
    public void setId_Equal(java.lang.Integer id) {
        registerId(ConditionKey.CK_EQUAL, id);
    }
            
    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param id The value of id as notEqual.
     */
    public void setId_NotEqual(java.lang.Integer id) {
        registerId(ConditionKey.CK_NOT_EQUAL, id);
    }
                    
    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param id The value of id as greaterThan.
     */
    public void setId_GreaterThan(java.lang.Integer id) {
        registerId(ConditionKey.CK_GREATER_THAN, id);
    }
            
    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param id The value of id as lessThan.
     */
    public void setId_LessThan(java.lang.Integer id) {
        registerId(ConditionKey.CK_LESS_THAN, id);
    }
            
    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param id The value of id as greaterEqual.
     */
    public void setId_GreaterEqual(java.lang.Integer id) {
        registerId(ConditionKey.CK_GREATER_EQUAL, id);
    }
            
    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param id The value of id as lessEqual.
     */
    public void setId_LessEqual(java.lang.Integer id) {
        registerId(ConditionKey.CK_LESS_EQUAL, id);
    }
                  
    /**
     * Set the value of id using inScope. { in (a, b) }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param idList The value of id as inScope.
     */
    public void setId_InScope(java.util.Collection<java.lang.Integer> idList) {
        registerId(ConditionKey.CK_IN_SCOPE, convertToList(idList));
    }
            
    /**
     * Set the value of id using notInScope. { not in (a, b) }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param idList The value of id as notInScope.
     */
    public void setId_NotInScope(java.util.Collection<java.lang.Integer> idList) {
        registerId(ConditionKey.CK_NOT_IN_SCOPE, convertToList(idList));
    }
                                                
    /**
     * Register condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     */
    protected void registerId(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueId(), "ID", "Id", "id");
    }

    /**
     * Register inline condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     */
    protected void registerInlineId(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueId(), "ID", "Id", "id");
    }

    abstract protected ConditionValue getCValueId();
      
    /**
     * Set the value of name using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param name The value of name as equal.
     */
    public void setName_Equal(String name) {
        registerName(ConditionKey.CK_EQUAL, filterRemoveEmptyString(name));
    }
                  
    /**
     * Set the value of name using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param name The value of name as notEqual.
     */
    public void setName_NotEqual(String name) {
        registerName(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(name));
    }
                    
    /**
     * Set the value of name using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param name The value of name as greaterThan.
     */
    public void setName_GreaterThan(String name) {
        registerName(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(name));
    }
            
    /**
     * Set the value of name using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param name The value of name as lessThan.
     */
    public void setName_LessThan(String name) {
        registerName(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(name));
    }
            
    /**
     * Set the value of name using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param name The value of name as greaterEqual.
     */
    public void setName_GreaterEqual(String name) {
        registerName(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(name));
    }
            
    /**
     * Set the value of name using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param name The value of name as lessEqual.
     */
    public void setName_LessEqual(String name) {
        registerName(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(name));
    }
            
    /**
     * Set the value of name using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param name The value of name as prefixSearch.
     */
    public void setName_PrefixSearch(String name) {
        registerName(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(name));
    }
            
    /**
     * Set the value of name using likeSearch. { like '%xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * You can invoke this method several times and the conditions are set up.
     * 
     * @param name The value of name as likeSearch.
     * @param likeSearchOption The option of like-search. (NotNull)
     */
    public void setName_LikeSearch(String name, sample.dbflute.allcommon.cbean.coption.LikeSearchOption likeSearchOption) {
        registerLikeSearchQuery(ConditionKey.CK_LIKE_SEARCH, filterRemoveEmptyString(name), getCValueName(), "NAME", "Name", "name", likeSearchOption);
    }
            
    /**
     * Set the value of name using inScope. { in ('a', 'b') }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param nameList The value of name as inScope.
     */
    public void setName_InScope(java.util.Collection<String> nameList) {
        registerName(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(convertToList(nameList)));
    }

    /**
     * Set the value of name using inScope. { in ('a', 'b') }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param name The value of name as inScope.
     * @param inScopeOption The option of in-scope. (NotNull)
     */
    public void setName_InScope(String name, sample.dbflute.allcommon.cbean.coption.InScopeOption inScopeOption) {
        registerInScopeQuery(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyString(name), getCValueName(), "NAME", "Name", "name", inScopeOption);
    }
            
    /**
     * Set the value of name using notInScope. { not in ('a', 'b') }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param nameList The value of name as notInScope.
     */
    public void setName_NotInScope(java.util.Collection<String> nameList) {
        registerName(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(convertToList(nameList)));
    }
                                                
    /**
     * Set the value of name using isNull. { is null }
     */
    public void setName_IsNull() {
        registerName(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of name using isNotNull. { is not null }
     */
    public void setName_IsNotNull() {
        registerName(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of name.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of name. (Nullable)
     */
    protected void registerName(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueName(), "NAME", "Name", "name");
    }

    /**
     * Register inline condition of name.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of name. (Nullable)
     */
    protected void registerInlineName(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueName(), "NAME", "Name", "name");
    }

    abstract protected ConditionValue getCValueName();
                  
    /**
     * Set the value of hireDate using equal. { = }
     * 
     * @param hireDate The value of hireDate as equal.
     */
    public void setHireDate_Equal(java.util.Date hireDate) {
        registerHireDate(ConditionKey.CK_EQUAL, hireDate);
    }
      
    /**
     * Set the value of hireDate using notEqual. { != }
     * 
     * @param hireDate The value of hireDate as notEqual.
     */
    public void setHireDate_NotEqual(java.util.Date hireDate) {
        registerHireDate(ConditionKey.CK_NOT_EQUAL, hireDate);
    }
            
    /**
     * Set the value of hireDate using greaterThan. { &gt; }
     * 
     * @param hireDate The value of hireDate as greaterThan.
     */
    public void setHireDate_GreaterThan(java.util.Date hireDate) {
        registerHireDate(ConditionKey.CK_GREATER_THAN, hireDate);
    }
            
    /**
     * Set the value of hireDate using lessThan. { &lt; }
     * 
     * @param hireDate The value of hireDate as lessThan.
     */
    public void setHireDate_LessThan(java.util.Date hireDate) {
        registerHireDate(ConditionKey.CK_LESS_THAN, hireDate);
    }
            
    /**
     * Set the value of hireDate using greaterEqual. { &gt;= }
     * 
     * @param hireDate The value of hireDate as greaterEqual.
     */
    public void setHireDate_GreaterEqual(java.util.Date hireDate) {
        registerHireDate(ConditionKey.CK_GREATER_EQUAL, hireDate);
    }
            
    /**
     * Set the value of hireDate using lessEqual. { &lt;= }
     * 
     * @param hireDate The value of hireDate as lessEqual.
     */
    public void setHireDate_LessEqual(java.util.Date hireDate) {
        registerHireDate(ConditionKey.CK_LESS_EQUAL, hireDate);
    }
            
    /**
     * Set the value of hireDate using from-to. { $fromDate <= COLUMN_NAME <= $toDate }
     * 
     * @param fromDate The from-date of hireDate. (Nullable)
     * @param toDate The to-date of hireDate. (Nullable)
     * @param fromToOption The option of from-to. (NotNull)
     */
    public void setHireDate_FromTo(java.util.Date fromDate, java.util.Date toDate, sample.dbflute.allcommon.cbean.coption.FromToOption fromToOption) {
        registerFromToQuery(fromDate, toDate, getCValueHireDate(), "HIRE_DATE", "HireDate", "hireDate", fromToOption);
    }

    /**
     * Set the value of hireDate using from-to as date. { $fromDate <= COLUMN_NAME < $toDate + 1 }
     * 
     * @param fromDate The from-date of hireDate. (Nullable)
     * @param toDate The to-date of hireDate. (Nullable)
     */
    public void setHireDate_DateFromTo(java.util.Date fromDate, java.util.Date toDate) {
        setHireDate_FromTo(fromDate, toDate, new sample.dbflute.allcommon.cbean.coption.DateFromToOption());
    }
                      
    /**
     * Set the value of hireDate using isNull. { is null }
     */
    public void setHireDate_IsNull() {
        registerHireDate(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of hireDate using isNotNull. { is not null }
     */
    public void setHireDate_IsNotNull() {
        registerHireDate(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of hireDate.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of hireDate. (Nullable)
     */
    protected void registerHireDate(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueHireDate(), "HIRE_DATE", "HireDate", "hireDate");
    }

    /**
     * Register inline condition of hireDate.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of hireDate. (Nullable)
     */
    protected void registerInlineHireDate(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueHireDate(), "HIRE_DATE", "HireDate", "hireDate");
    }

    abstract protected ConditionValue getCValueHireDate();
              
    /**
     * Set the value of deptId using equal. { = }
     * 
     * @param deptId The value of deptId as equal.
     */
    public void setDeptId_Equal(java.lang.Integer deptId) {
        registerDeptId(ConditionKey.CK_EQUAL, deptId);
    }
            
    /**
     * Set the value of deptId using notEqual. { != }
     * 
     * @param deptId The value of deptId as notEqual.
     */
    public void setDeptId_NotEqual(java.lang.Integer deptId) {
        registerDeptId(ConditionKey.CK_NOT_EQUAL, deptId);
    }
                    
    /**
     * Set the value of deptId using greaterThan. { &gt; }
     * 
     * @param deptId The value of deptId as greaterThan.
     */
    public void setDeptId_GreaterThan(java.lang.Integer deptId) {
        registerDeptId(ConditionKey.CK_GREATER_THAN, deptId);
    }
            
    /**
     * Set the value of deptId using lessThan. { &lt; }
     * 
     * @param deptId The value of deptId as lessThan.
     */
    public void setDeptId_LessThan(java.lang.Integer deptId) {
        registerDeptId(ConditionKey.CK_LESS_THAN, deptId);
    }
            
    /**
     * Set the value of deptId using greaterEqual. { &gt;= }
     * 
     * @param deptId The value of deptId as greaterEqual.
     */
    public void setDeptId_GreaterEqual(java.lang.Integer deptId) {
        registerDeptId(ConditionKey.CK_GREATER_EQUAL, deptId);
    }
            
    /**
     * Set the value of deptId using lessEqual. { &lt;= }
     * 
     * @param deptId The value of deptId as lessEqual.
     */
    public void setDeptId_LessEqual(java.lang.Integer deptId) {
        registerDeptId(ConditionKey.CK_LESS_EQUAL, deptId);
    }
                  
    /**
     * Set the value of deptId using inScope. { in (a, b) }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param deptIdList The value of deptId as inScope.
     */
    public void setDeptId_InScope(java.util.Collection<java.lang.Integer> deptIdList) {
        registerDeptId(ConditionKey.CK_IN_SCOPE, convertToList(deptIdList));
    }
            
    /**
     * Set the value of deptId using notInScope. { not in (a, b) }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param deptIdList The value of deptId as notInScope.
     */
    public void setDeptId_NotInScope(java.util.Collection<java.lang.Integer> deptIdList) {
        registerDeptId(ConditionKey.CK_NOT_IN_SCOPE, convertToList(deptIdList));
    }
            
    /**
     * Set the sub-query of DeptId_InScopeSubQuery_Dept using inScopeSubQuery.
     * { in (select xxx.ID from DEPT where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param deptCBquery The sub-query of DeptId_InScopeSubQuery_Dept using inScopeSubQuery. (NotNull)
     */
    public void setDeptId_InScopeSubQuery_Dept(sample.dbflute.cbean.cq.DeptCQ deptCBquery) {
        assertObjectNotNull("deptCBquery", deptCBquery);
        final String subQueryPropertyName = keepDeptId_InScopeSubQuery_Dept(deptCBquery);// for saving query-value.
        registerInScopeSubQuery(deptCBquery, "DEPT_ID", "ID", subQueryPropertyName);
    }

    abstract public String keepDeptId_InScopeSubQuery_Dept(sample.dbflute.cbean.cq.DeptCQ subQuery);
                                      
    /**
     * Set the value of deptId using isNull. { is null }
     */
    public void setDeptId_IsNull() {
        registerDeptId(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of deptId using isNotNull. { is not null }
     */
    public void setDeptId_IsNotNull() {
        registerDeptId(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of deptId.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptId. (Nullable)
     */
    protected void registerDeptId(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueDeptId(), "DEPT_ID", "DeptId", "deptId");
    }

    /**
     * Register inline condition of deptId.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptId. (Nullable)
     */
    protected void registerInlineDeptId(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueDeptId(), "DEPT_ID", "DeptId", "deptId");
    }

    abstract protected ConditionValue getCValueDeptId();
              
    /**
     * Set the value of versionNo using equal. { = }
     * 
     * @param versionNo The value of versionNo as equal.
     */
    public void setVersionNo_Equal(java.math.BigDecimal versionNo) {
        registerVersionNo(ConditionKey.CK_EQUAL, versionNo);
    }
            
    /**
     * Set the value of versionNo using notEqual. { != }
     * 
     * @param versionNo The value of versionNo as notEqual.
     */
    public void setVersionNo_NotEqual(java.math.BigDecimal versionNo) {
        registerVersionNo(ConditionKey.CK_NOT_EQUAL, versionNo);
    }
                    
    /**
     * Set the value of versionNo using greaterThan. { &gt; }
     * 
     * @param versionNo The value of versionNo as greaterThan.
     */
    public void setVersionNo_GreaterThan(java.math.BigDecimal versionNo) {
        registerVersionNo(ConditionKey.CK_GREATER_THAN, versionNo);
    }
            
    /**
     * Set the value of versionNo using lessThan. { &lt; }
     * 
     * @param versionNo The value of versionNo as lessThan.
     */
    public void setVersionNo_LessThan(java.math.BigDecimal versionNo) {
        registerVersionNo(ConditionKey.CK_LESS_THAN, versionNo);
    }
            
    /**
     * Set the value of versionNo using greaterEqual. { &gt;= }
     * 
     * @param versionNo The value of versionNo as greaterEqual.
     */
    public void setVersionNo_GreaterEqual(java.math.BigDecimal versionNo) {
        registerVersionNo(ConditionKey.CK_GREATER_EQUAL, versionNo);
    }
            
    /**
     * Set the value of versionNo using lessEqual. { &lt;= }
     * 
     * @param versionNo The value of versionNo as lessEqual.
     */
    public void setVersionNo_LessEqual(java.math.BigDecimal versionNo) {
        registerVersionNo(ConditionKey.CK_LESS_EQUAL, versionNo);
    }
                  
    /**
     * Set the value of versionNo using inScope. { in (a, b) }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param versionNoList The value of versionNo as inScope.
     */
    public void setVersionNo_InScope(java.util.Collection<java.math.BigDecimal> versionNoList) {
        registerVersionNo(ConditionKey.CK_IN_SCOPE, convertToList(versionNoList));
    }
            
    /**
     * Set the value of versionNo using notInScope. { not in (a, b) }
     * If the element in the collection is null or empty-string, the condition-element is ignored.
     * 
     * @param versionNoList The value of versionNo as notInScope.
     */
    public void setVersionNo_NotInScope(java.util.Collection<java.math.BigDecimal> versionNoList) {
        registerVersionNo(ConditionKey.CK_NOT_IN_SCOPE, convertToList(versionNoList));
    }
                                            
    /**
     * Set the value of versionNo using isNull. { is null }
     */
    public void setVersionNo_IsNull() {
        registerVersionNo(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of versionNo using isNotNull. { is not null }
     */
    public void setVersionNo_IsNotNull() {
        registerVersionNo(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of versionNo.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionNo. (Nullable)
     */
    protected void registerVersionNo(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueVersionNo(), "VERSION_NO", "VersionNo", "versionNo");
    }

    /**
     * Register inline condition of versionNo.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionNo. (Nullable)
     */
    protected void registerInlineVersionNo(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueVersionNo(), "VERSION_NO", "VersionNo", "versionNo");
    }

    abstract protected ConditionValue getCValueVersionNo();
  
    // ===================================================================================
    //                                                                      Basic Override
    //                                                                      ==============
    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Clause string. (NotNull)
     */
    public String toString() {
        return getSqlClause().getClause();
    }
}
