package sample.dbflute.allcommon.bhv.setup;

import sample.dbflute.allcommon.Entity;

/**
 * The interface of entity list setupper.
 * 
 * @param <ENTITY> The type of entity.
 * @author DBFlute(AutoGenerator)
 */
public interface EntityListSetupper<ENTITY extends Entity> {

    /**
     * Set up entity list.
     * 
     * @param entityList Entity list. (NotNull)
     */
    public void setup(java.util.List<ENTITY> entityList);
}
