package sample.dbflute.bsentity;



import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.dbmeta.DBMeta;
import sample.dbflute.allcommon.dbmeta.DBMetaInstanceHandler;

/**
 * The entity of DEPT(TABLE). <br />
 * 
 * <pre>
 * [primary-key]
 *     ID
 * 
 * [column-property]
 *     ID, NAME, VERSION_NO
 * 
 * [foreign-property]
 *     
 * 
 * [referer-property]
 *     empList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     VersionNo
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public abstract class BsDept implements Entity, java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /** TABLE-Annotation for S2Dao. The value is DEPT. */
    public static final String TABLE = "DEPT";

    
    /** VERSION_NO-Annotation */
    public static final String VERSION_NO_PROPERTY = "versionNo";


    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Entity modified properties. (for S2Dao) */
    protected EntityModifiedProperties _modifiedProperties = newEntityModifiedProperties();

    /** The value of id. PK : INTEGER : NotNull : Default=[] */
    protected java.lang.Integer _id;

    /** The value of name. VARCHAR(20) : Default=[] */
    protected String _name;

    /** The value of versionNo. INTEGER : Default=[] */
    protected java.lang.Integer _versionNo;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    public BsDept() {
    }


    // ===================================================================================
    //                                                                              DBMeta
    //                                                                              ======
    /**
     * The implementation.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return DBMetaInstanceHandler.findDBMeta(getTableDbName());
    }

    // ===================================================================================
    //                                                                          Table Name
    //                                                                          ==========
    /**
     * The implementation.
     * 
     * @return Table db-name of DEPT(TABLE). (NotNull)
     */
    public String getTableDbName() {
        return "DEPT";
    }

    /**
     * The implementation.
     * 
     * @return Table property name(JavaBeansRule) of DEPT(TABLE). (NotNull)
     */
    public String getTablePropertyName() {
        return "dept";
    }

    /**
     * The implementation.
     * 
     * @return Table prop-name(JavaBeansRule) of DEPT(TABLE). (NotNull)
     * @deprecated Please use getTablePropertyName()
     */
    public String getTablePropName() {
        return "dept";
    }

    /**
     * The implementation.
     * 
     * @return Table cap-prop-name of DEPT(TABLE). (NotNull)
     */
    public String getTableCapPropName() {
        return "Dept";
    }

    /**
     * The implementation.
     * 
     * @return Table uncap-prop-name of DEPT(TABLE). (NotNull)
     */
    public String getTableUncapPropName() {
        return "dept";
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========

    /** Column Annotation for S2Dao. PK : INTEGER : NotNull : Default=[] */
    public static final String id_COLUMN = "ID";

    /**
     * Get the value of id. <br />
     * {PK : INTEGER : NotNull : Default=[]}
     * 
     * @return The value of id. (Nullable)
     */
    public java.lang.Integer getId() {
        return _id;
    }

    /**
     * Set the value of id. <br />
     * {PK : INTEGER : NotNull : Default=[]}
     * 
     * @param id The value of id. (Nullable)
     */
    public void setId(java.lang.Integer id) {
        _modifiedProperties.addPropertyName("id");
        this._id = id;
    }

    /** Column Annotation for S2Dao. VARCHAR(20) : Default=[] */
    public static final String name_COLUMN = "NAME";

    /**
     * Get the value of name. <br />
     * {VARCHAR(20) : Default=[]}
     * 
     * @return The value of name. (Nullable)
     */
    public String getName() {
        return _name;
    }

    /**
     * Set the value of name. <br />
     * {VARCHAR(20) : Default=[]}
     * 
     * @param name The value of name. (Nullable)
     */
    public void setName(String name) {
        _modifiedProperties.addPropertyName("name");
        this._name = name;
    }

    /** Column Annotation for S2Dao. INTEGER : Default=[] */
    public static final String versionNo_COLUMN = "VERSION_NO";

    /**
     * Get the value of versionNo. <br />
     * {INTEGER : Default=[]}
     * 
     * @return The value of versionNo. (Nullable)
     */
    public java.lang.Integer getVersionNo() {
        return _versionNo;
    }

    /**
     * Set the value of versionNo. <br />
     * {INTEGER : Default=[]}
     * 
     * @param versionNo The value of versionNo. (Nullable)
     */
    public void setVersionNo(java.lang.Integer versionNo) {
        _modifiedProperties.addPropertyName("versionNo");
        this._versionNo = versionNo;
    }


    // ===================================================================================
    //                                                                     Classify Method
    //                                                                     ===============
      
    // ===================================================================================
    //                                                        Classification Determination
    //                                                        ============================
      

    // ===================================================================================
    //                                                               Classification Getter
    //                                                               =====================
      

    // ===================================================================================
    //                                                                       Foreign Table
    //                                                                       =============

    // ===================================================================================
    //                                                                       Referer Table
    //                                                                       =============

  
    // /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    //   RefererTable    = [EMP(TABLE)]
    //   RefererProperty = [empList]
    // * * * * * * * * */

      
    /** The list of referer table. */
    protected java.util.List<sample.dbflute.exentity.Emp> _childrenEmpList;

    /**
     * Get the list of referer table. {without lazyload} <br />
     * If it's not loaded yet, initializes the list instance of referer as empty list. <br />
     * This list of result is for Read-Only basically.
     * 
     * @return The list of referer table. (Nullable)
     */
    public java.util.List<sample.dbflute.exentity.Emp> getEmpList() {
        if (_childrenEmpList == null) { _childrenEmpList = new java.util.ArrayList<sample.dbflute.exentity.Emp>(); }
        return _childrenEmpList;
    }

    /**
     * Set the list of referer table.
     * 
     * @param empList The list of referer table. (Nullable)
     */
    public void setEmpList(java.util.List<sample.dbflute.exentity.Emp> empList) {
        this._childrenEmpList = empList;
    }

    /**
     * Has referer elements of EmpList.
     * 
     * @return Determination.
     */
    public boolean hasRefererElementsEmpList() {
        return _childrenEmpList != null && !_childrenEmpList.isEmpty();
    }


    // ===================================================================================
    //                                                                       Determination
    //                                                                       =============
    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasPrimaryKeyValue() {
        if (_id == null) {
            return false;
        }
        return true;
    }

    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasVersionNoValue() {
        return !(getVersionNo() + "").equals("null");// For primitive type
    }

    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasUpdateDateValue() {
        return false;
    }

    // ===================================================================================
    //                                                                 Modified Properties
    //                                                                 ===================
    /**
     * Get modified property names. (S2Dao uses this for updateModifiedProperties())
     * 
     * @return Modified property names. (NotNull)
     */
    public java.util.Set<String> getModifiedPropertyNames() {
        return _modifiedProperties.getPropertyNames();
    }

    /**
     * New entity modified properties. You can override this at the sub-class if you need it.
     * 
     * @return Entity modified properties. (NotNull)
     */
    protected EntityModifiedProperties newEntityModifiedProperties() {
        return new EntityModifiedProperties();
    }

    /**
     * Clear modified property names.
     */
    public void clearModifiedPropertyNames() {
        _modifiedProperties.clear();
    }

    /**
     * Has modification?
     * 
     * @return Determination.
     */
    public boolean hasModification() {
        return !_modifiedProperties.isEmpty();
    }

    // ===================================================================================
    //                                                                      Basic Override
    //                                                                      ==============

    /**
     * The override.
     * If the primary-key of the other is same as this one, returns true.
     * 
     * @param other Other entity.
     * @return Comparing result.
     */
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (!(other instanceof BsDept)) {
            return false;
        }
        final BsDept otherEntity = (BsDept)other;

        if (getId() == null || !getId().equals(otherEntity.getId())) {
            return false;
        }

        return true;
    }

    /**
     * The override.
     * Calculates hash-code from primary-key.
     * 
     * @return Hash-code from primary-keys.
     */
    public int hashCode() {
        int result = 0;

        if (this.getId() != null) {
            result = result + getId().hashCode();
        }

        return result;
    }

    /**
     * The override.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String toString() {
        final String delimiter = ",";
        final StringBuffer sb = new StringBuffer();

        sb.append(delimiter).append(getId());
        sb.append(delimiter).append(getName());
        sb.append(delimiter).append(getVersionNo());

        sb.delete(0, delimiter.length());
        sb.insert(0, "{").append("}");
        return sb.toString();
    }
}
