package sample.dbflute.allcommon.helper.token.file;

/**
 * @author DBFlute(AutoGenerator)
 */
public interface FileTokenizingCallback {
    public void handleRowResource(FileTokenizingRowResource fileTokenizingRowResource);
}
