package sample.dbflute.exbhv;


/**
 * The behavior of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class EmpBhv extends sample.dbflute.bsbhv.BsEmpBhv {
}
