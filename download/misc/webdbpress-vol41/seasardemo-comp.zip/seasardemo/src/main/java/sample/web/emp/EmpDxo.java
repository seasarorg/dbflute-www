package sample.web.emp;

import java.util.List;

import org.seasar.extension.dxo.annotation.ConversionRule;

import sample.dbflute.exentity.Emp;

public interface EmpDxo {	
	
	static final String TO_DOMAIN = "name : empName";

	static final String TO_PRESENTATION 
		= "empName : name, deptName : dept.name";
		
	@ConversionRule(TO_DOMAIN)
	Emp convert(EmpUpdateConfirmPage page);

	@ConversionRule(TO_PRESENTATION)
	EmpDto[] convert(List<Emp> emps);

	@ConversionRule(TO_PRESENTATION)
	void convert(Emp src, EmpUpdatePage dest);

}
