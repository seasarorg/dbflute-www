package sample.dbflute.allcommon.dbmeta;


import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.helper.MapListString;
import sample.dbflute.allcommon.helper.MapStringBuilder;
import sample.dbflute.allcommon.dbmeta.info.ColumnInfo;
import sample.dbflute.allcommon.dbmeta.info.ForeignInfo;
import sample.dbflute.allcommon.dbmeta.info.RefererInfo;
import sample.dbflute.allcommon.dbmeta.info.RelationInfo;
import sample.dbflute.allcommon.dbmeta.info.UniqueInfo;

/**
 * The interface of dbmeta.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface DBMeta {

    // ===================================================================================
    //                                                                          Definition
    //                                                                          ==========
    /** Map-string map-mark. */
    public static final String MAP_STRING_MAP_MARK = "map:";

    /** Map-string list-mark. */
    public static final String MAP_STRING_LIST_MARK = "list:";

    /** Map-string start-brace. */
    public static final String MAP_STRING_START_BRACE = "@{";

    /** Map-string end-brace. */
    public static final String MAP_STRING_END_BRACE = "@}";

    /** Map-string delimiter. */
    public static final String MAP_STRING_DELIMITER = "@;";

    /** Map-string equal. */
    public static final String MAP_STRING_EQUAL = "@=";

    // ===================================================================================
    //                                                                          Table Name
    //                                                                          ==========
    /**
     * Get table db-name.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName();

    /**
     * Get table prop-name(JavaBeansRule).
     * 
     * @return Table property-name(JavaBeansRule). (NotNull)
     */
    public String getTablePropertyName();

    /**
     * Get table cap-prop-name. (Not JavaBeansRule)
     * 
     * @return Table cap-prop-name. (NotNull)
     */
    public String getTableCapPropName();

    /**
     * Get table uncap-prop-name. (Not JavaBeansRule)
     * 
     * @return Table uncap-prop-name. (NotNull)
     */
    public String getTableUncapPropName();

    // ===================================================================================
    //                                                                       Name Handling
    //                                                                       =============
    /**
     * Has object of flexible name? {Target objects are TABLE and COLUMN}
     * 
     * @param flexibleName Flexible name. (NotNull and NotEmpty)
     * @return Determination.
     */
    public boolean hasFlexibleName(String flexibleName);


    /**
     * Find db name by flexible name. {Target objects are TABLE and COLUMN}
     * 
     * @param flexibleName Flexible ame. (NotNull and NotEmpty)
     * @return Db name. (NotNull and NotEmpty)
     */
    public String findDbName(String flexibleName);

    /**
     * Find property name(JavaBeansRule) by flexible name. {Target objects are TABLE and COLUMN}
     * 
     * @param flexibleName Flexible name. (NotNull and NotEmpty)
     * @return Db name. (NotNull and NotEmpty)
     */
    public String findPropertyName(String flexibleName);


    // ===================================================================================
    //                                                                            Name Map
    //                                                                            ========
    /**
     * Get the key-to-lower map of db name(lower) and property name.
     * 
     * @return The key-to-lower map of db name(lower) and property name. (NotNull)
     */
    public java.util.Map<String, String> getDbNamePropertyNameKeyToLowerMap();

    /**
     * Get the key-to-lower map of property name(lower) and db name.
     * 
     * @return The key-to-lower map of property name(lower) and db name. (NotNull)
     */
    public java.util.Map<String, String> getPropertyNameDbNameKeyToLowerMap();


    // ===================================================================================
    //                                                                           Type Name
    //                                                                           =========
    /**
     * Get the type-name of entity.
     * 
     * @return The type-name of entity. (NotNull)
     */ 
    public String getEntityTypeName();

    /**
     * Get the type-name of condition-bean.
     * 
     * @return The type-name of condition-bean. (Nullable: If the condition-bean does not exist)
     */ 
    public String getConditionBeanTypeName();

    /**
     * Get the type-name of dao.
     * 
     * @return The type-name of dao. (Nullable: If the dao does not exist)
     */ 
    public String getDaoTypeName();

    /**
     * Get the type-name of behavior.
     * 
     * @return The type-name of behavior. (Nullable: If the behavior does not exist)
     */ 
    public String getBehaviorTypeName();

    // ===================================================================================
    //                                                                         Object Type
    //                                                                         ===========
    /**
     * Get the type of entity.
     * 
     * @return The type of entity. (NotNull)
     */ 
    public Class getEntityType();

    // ===================================================================================
    //                                                                     Object Instance
    //                                                                     ===============
    /**
     * New the instance of entity.
     * 
     * @return The instance of entity. (NotNull)
     */ 
    public Entity newEntity();

    // ===================================================================================
    //                                                                         Column Info
    //                                                                         ===========
    /**
     * The implementation.
     * 
     * @return The list of column db-name. (NotNull and NotEmpty)
     */
    public java.util.List<ColumnInfo> getColumnInfoList();


    /**
     * Has column?
     * 
     * @param columnFlexibleName Column flexible name. (NotNull)
     * @return Determination.
     */
    public boolean hasColumn(String columnFlexibleName);

    /**
     * Find column info by column flexible name.
     * <pre>
     * If the table name is 'BOOK_ID', you can find the dbmeta by ...(as follows)
     *     'BOOK_ID', 'BOok_iD', 'book_id'
     *     , 'BookId', 'bookid', 'bOoKiD'
     * </pre>
     * @param columnFlexibleName Column flexible name. (NotNull)
     * @return Column info. (NotNull)
     */ 
    public ColumnInfo findColumnInfo(String columnFlexibleName);

    // ===================================================================================
    //                                                                         Unique Info
    //                                                                         ===========
    /**
     * Get primary unique info.
     * 
     * @return Primary unique info. (NotNull)
     */
    public UniqueInfo getPrimaryUniqueInfo();

    /**
     * Has primary-key?
     * 
     * @return Determination.
     */
    public boolean hasPrimaryKey();

    /**
     * Has two or more primary-keys?
     * 
     * @return Determination.
     */
    public boolean hasTwoOrMorePrimaryKeys();

    // ===================================================================================
    //                                                                       Relation Info
    //                                                                       =============
    // -----------------------------------------------------
    //                                      Relation Element
    //                                      ----------------
    /**
     * Find relation info.
     * 
     * @param relationPropertyName Relation property name. (Both OK - InitCap or not). (NotNull)
     * @return Relation info. (NotNull)
     */ 
    public RelationInfo findRelationInfo(String relationPropertyName);

    // -----------------------------------------------------
    //                                       Foreign Element
    //                                       ---------------
    /**
     * Has foreign?
     * 
     * @param foreignPropName Foreign property name. (Both OK - InitCap or not). (NotNull)
     * @return Determination. (NotNull)
     */ 
    public boolean hasForeign(String foreignPropName);

    /**
     * Find foreign dbmeta.
     * 
     * @param foreignPropName Foreign property name. (Both OK - InitCap or not). (NotNull)
     * @return Foreign DBMeta. (NotNull)
     */ 
    public DBMeta findForeignDBMeta(String foreignPropName);

    /**
     * Find foreign info.
     * 
     * @param foreignPropName Foreign property name. (Both OK - InitCap or not). (NotNull)
     * @return Foreign info. (NotNull)
     */ 
    public ForeignInfo findForeignInfo(String foreignPropName);

    // -----------------------------------------------------
    //                                       Referer Element
    //                                       ---------------
    /**
     * Has referer?
     * 
     * @param refererPropertyName Referer property name. (Both OK - InitCap or not). (NotNull)
     * @return Determination. (NotNull)
     */ 
    public boolean hasReferer(String refererPropertyName);

    /**
     * Find referer dbmeta.
     * 
     * @param refererPropertyName Referer property name. (Both OK - InitCap or not). (NotNull)
     * @return Referer DBMeta. (NotNull)
     */ 
    public DBMeta findRefererDBMeta(String refererPropertyName);

    /**
     * Find referer information.
     * 
     * @param refererPropertyName Referer property name. (Both OK - InitCap or not). (NotNull)
     * @return Referer information. (NotNull)
     */ 
    public RefererInfo findRefererInfo(String refererPropertyName);

    // -----------------------------------------------------
    //                                        Relation Trace
    //                                        --------------
    /**
     * Relation trace.
     */
    public static interface RelationTrace {

        /**
         * Get the trace of relation.
         * 
         * @return The trace of relation as the list of relation info. (NotNull)
         */
        public java.util.List<RelationInfo> getTraceRelation();

        /**
         * Get the trace of column.
         * 
         * @return The trace of column as column info. (Nullable)
         */
        public ColumnInfo getTraceColumn();
    }

    public static interface RelationTraceFixHandler {
        public void handleFixedTrace(RelationTrace relationTrace);
    }


    // ===================================================================================
    //                                                                       Sequence Info
    //                                                                       =============
    /**
     * Has sequence?
     * 
     * @return Determination.
     */
    public boolean hasSequence();

    // ===================================================================================
    //                                                                Optimistic Lock Info
    //                                                                ====================
    /**
     * Has version no?
     * 
     * @return Determination.
     */
    public boolean hasVersionNo();

    /**
     * Has update date?
     * 
     * @return Determination.
     */
    public boolean hasUpdateDate();

    // ===================================================================================
    //                                                                       Common Column
    //                                                                       =============
    /**
     * Has common column?
     * 
     * @return Determination.
     */
    public boolean hasCommonColumn();

    // ===================================================================================
    //                                                                     Entity Handling
    //                                                                     ===============
    // -----------------------------------------------------
    //                                                Accept
    //                                                ------
    /**
     * Accept primary-key map.
     * 
     * The column that column-value map-string doesn't have the value of is reflected as null.
     * The column that column-value map-string doesn't have the key of is NOT updated nothing.
     * 
     * @param entity Target entity. (NotNull)
     * @param primaryKeyMap Primary-key map. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMap(Entity entity, java.util.Map<String, ? extends Object> primaryKeyMap);

    /**
     * Accept primary-key map-string.
     * 
     * The column that column-value map-string doesn't have the value of is reflected as null.
     * The column that column-value map-string doesn't have the key of is NOT updated nothing.
     * 
     * @param entity Target entity. (NotNull)
     * @param primaryKeyMapString Primary-key map-string. (NotNull)
     */
    public void acceptPrimaryKeyMapString(Entity entity, String primaryKeyMapString);

    /**
     * Accept column-value map.
     * 
     * The column that column-value map-string doesn't have the value of is reflected as null.
     * The column that column-value map-string doesn't have the key of is NOT updated nothing.
     * 
     * @param entity Target entity. (NotNull)
     * @param columnValueMap Column-value map. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMap(Entity entity, java.util.Map<String, ? extends Object> columnValueMap);

    /**
     * Accept column-value map-string.
     * 
     * The column that column-value map-string doesn't have the value of is reflected as null.
     * The column that column-value map-string doesn't have the key of is NOT updated nothing.
     * 
     * @param entity Target entity. (NotNull)
     * @param columnValueMapString Column-value map-string. (NotNull)
     */
    public void acceptColumnValueMapString(Entity entity, String columnValueMapString);

    // -----------------------------------------------------
    //                                               Extract
    //                                               -------
    /**
     * Extract primary-key map-string. Delimiter is at-mark and semicolon.
     * <p>
     * <pre>
     * ex) Uses that this method have.
     *   final String primaryKeyMapString = LdBookDbm.extractPrimaryKeyMapString(entity);
     *   final LdBook entity = dao.selectEntity(new LdBookCB().acceptPrimaryKeyMapString(primaryKeyMapString));
     *   ... // as primary key for condition.
     * </pre>
     * 
     * @param entity Target entity. (NotNull)
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString(Entity entity);

    /**
     * Extract primary-key map-string.
     * 
     * @param entity Target entity. (NotNull)
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString(Entity entity, String startBrace, String endBrace, String delimiter, String equal);

    /**
     * Extract column-value map-string. Delimiter is at-mark and semicolon.
     * 
     * @param entity Target entity. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString(Entity entity);

    /**
     * Extract column-value map-string.
     * 
     * @param entity Target entity. (NotNull)
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString(Entity entity, String startBrace, String endBrace, String delimiter, String equal);

    /**
     * Extract common-column-value map-string.
     * 
     * @param entity Target entity. (NotNull)
     * @return Common-column-value map-string. (NotNull)
     */
    public String extractCommonColumnValueMapString(Entity entity);

    /**
     * Extract common-column-value map-string.
     * 
     * @param entity Target entity. (NotNull)
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Common-column-value map-string. (NotNull)
     */
    public String extractCommonColumnValueMapString(Entity entity, String startBrace, String endBrace, String delimiter, String equal);

    // -----------------------------------------------------
    //                                               Convert
    //                                               -------
    /**
     * Convert entity to column value as list.
     * 
     * @param entity Target entity. (NotNull)
     * @return The list of column value. (NotNull)
     */
    public java.util.List<Object> convertToColumnValueList(Entity entity);

    /**
     * Convert entity to column value as map.
     * 
     * @param entity Target entity. (NotNull)
     * @return The map of column value. (NotNull)
     */
    public java.util.Map<String, Object> convertToColumnValueMap(Entity entity);

    /**
     * Convert entity to column string-value as list.
     * 
     * @param entity Target entity. (NotNull)
     * @return The list of column string-value. (NotNull)
     */
    public java.util.List<String> convertToColumnStringValueList(Entity entity);

    /**
     * Convert entity to column string-value as map.
     * 
     * @param entity Target entity. (NotNull)
     * @return The map of column string-value. (NotNull)
     */
    public java.util.Map<String, String> convertToColumnStringValueMap(Entity entity);

    // ===================================================================================
    //                                                                        JDBC Support
    //                                                                        ============
    /**
     * Insert entity using specified connection.
     * 
     * @param conn Connection. (NotNull)
     * @param entity Entity. (NotNull)
     * @return Prepared insert clause. (NotNull and NotEmpty)
     */
    public int insertEntity(java.sql.Connection conn, Entity entity);

    /**
     * Insert entity using specified connection.
     * 
     * @param conn Connection. (NotNull)
     * @param entity Entity. (NotNull)
     * @param preparedInsertClauseOption Prepared insert clause option. (NotNull)
     * @return Prepared insert clause. (NotNull and NotEmpty)
     */
    public int insertEntity(java.sql.Connection conn, Entity entity, PreparedInsertClauseOption preparedInsertClauseOption);

    /**
     * Get prepared insert clause.
     * 
     * @return Prepared insert clause. (NotNull and NotEmpty)
     */
    public String getPreparedInsertClause();

    /**
     * Get prepared insert clause.
     * 
     * @param preparedInsertClauseOption Prepared insert clause option. (NotNull)
     * @return Prepared insert clause. (NotNull and NotEmpty)
     */
    public String getPreparedInsertClause(PreparedInsertClauseOption preparedInsertClauseOption);

    /**
     * The option of prepared insert clause.
     */
    public static class PreparedInsertClauseOption {

        /** Table prefix. */
        protected String _tablePrefix;

        /**
         * Get table prefix.
         * 
         * @return Table prefix. (Nullable)
         */
        public String getTablePrefix() {
            return this._tablePrefix;
        }

        /**
         * Set table prefix.
         * 
         * @param tablePrefix Table prefix. (Nullable)
         */
        public void setTablePrefix(String tablePrefix) {
            this._tablePrefix = tablePrefix;
        }
    }

    // ===================================================================================
    //                                                                          Map String
    //                                                                          ==========
    /**
     * Create map list string that is prepared. (for INTERNAL)
     * 
     * @return Map list string that is prepared. (NotNull)
     */
    public MapListString createMapListString();

    /**
     * Create map string builder that is prepared. (for INTERNAL)
     * 
     * @return Map string builder that is prepared. (NotNull)
     */
    public MapStringBuilder createMapStringBuilder();
}
