package sample.dbflute.allcommon.interceptor;

import sample.dbflute.allcommon.EntityDefinedCommonColumn;

/**
 * CommonColumn-Setup-before-Update Interceptor.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class CommonColumnSetupBeforeUpdateInterceptor extends CommonColumnSetupAbstractInterceptor {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /** Log-instance. */
    private static final org.apache.commons.logging.Log _log = org.apache.commons.logging.LogFactory.getLog(CommonColumnSetupBeforeUpdateInterceptor.class);

    /**
     * Set up the entity.
     * 
     * @param entity Entity. (Nullable)
     */
    protected void setupEntity(EntityDefinedCommonColumn entity) {
        if (_log.isDebugEnabled()) {
            _log.debug("  before setup : " + entity.getDBMeta().extractCommonColumnValueMapString(entity));
        }

        if (_log.isDebugEnabled()) {
            _log.debug("  after setup  : " + entity.getDBMeta().extractCommonColumnValueMapString(entity));
        }
    }
}