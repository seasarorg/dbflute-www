package sample.dbflute.bsdao;


import sample.dbflute.exentity.Emp;

/**
 * The dao interface of EMP.
 * 
 * <pre>
 * [primary-key]
 *     ID
 * 
 * [column-property]
 *     ID, NAME, HIRE_DATE, DEPT_ID, VERSION_NO
 * 
 * [foreign-property]
 *     dept
 * 
 * [referer-property]
 *     
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     VersionNo
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface BsEmpDao extends sample.dbflute.allcommon.DaoWritable {

    /** BEAN-Annotation. */
    public Class BEAN = sample.dbflute.exentity.Emp.class;

    /** SQL-Annotation for getCountAll(). */
    public static final String getCountAll_SQL = "select count(*) from EMP";

    /**
     * Get count as all.
     * 
     * @return All count.
     */
    public int getCountAll();

    /** SQL-Annotation for getListAll(). */
    public static final String getListAll_SQL = "select ID, NAME, HIRE_DATE, DEPT_ID, VERSION_NO from EMP";

    /**
     * Get list as all.
     * 
     * @return All list. (NotNull)
     */
    public java.util.List<Emp> getListAll();

    /** SQL-Annotation for getEntity(). */
    public static final String getEntity_SQL = "select ID, NAME, HIRE_DATE, DEPT_ID, VERSION_NO from EMP where EMP.ID = /*id*/null";

    /** Args-Annotation for getEntity(). */
    public static final String getEntity_ARGS = "id";

    /* (non-javadoc)
     * Get entity by primary key.
     * 
     * @param primaryKey Primary key. (NotNull)
     */
    public Emp getEntity(java.lang.Integer id);

    /**
     * Select count by condition-bean.
     * <pre>
     * Ignore fetchFirst() and fetchScope() and fetchPage().
     * But the fetch status of the condition-bean remains as it is.
     * This select method generates SQL based on condition-bean.
     * 
     * Example)
     *   final EmpCB cb = new EmpCB();
     *   cb.query().setXxx_GreaterEqual(new BigDecimal(14));
     *   final int count = dao.selectCount(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     */
    public int selectCount(sample.dbflute.cbean.EmpCB cb);

    /**
     * Select entity 'Emp' by condition-bean.
     * <pre>
     * This select method generates SQL based on condition-bean.
     * 
     * Example)
     *   final EmpCB cb = new EmpCB();
     *   cb.query().setXxxCode_Equal("abc");// It is assumed that this is the primary key...
     *   cb.lockForUpdate();
     *   final Emp entity = dao.selectEntity(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. If the select result is zero, it returns null. (Nullable)
     */
    public Emp selectEntity(sample.dbflute.cbean.EmpCB cb);

    /**
     * Select list by condition-bean.
     * <pre>
     * This select method generates SQL based on condition-bean.
     * 
     * Example)
     *   final EmpCB cb = new EmpCB();
     *   cb.setupSelect_Xxx(); // Including the foreign table in select clause
     *   cb.query().setXxxName_PrefixSearch("abc");
     *   cb.query().setXxxStartDate_IsNotNull();
     *   cb.addOrderBy_PK_Asc().fetchFirst(20);
     *   final List resultList = dao.selectList(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list. If the select result is zero, it returns empty list. (NotNull)
     */
    public java.util.List<Emp> selectList(sample.dbflute.cbean.EmpCB cb);


    /**
     * Insert one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Inserted count.
     */
    public int insert(Emp entity);

    /**
     * Update one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     * @deprecated Please use updateModifiedOnly()
     */
    public int update(Emp entity);

    /**
     * Update one entity. {modified only}
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int updateModifiedOnly(Emp entity);

    /**
     * Update one entity non-strictly. {modified only}
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int updateNonstrictModifiedOnly(Emp entity);

    /**
     * Delete one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delete(Emp entity);

    /**
     * Delete one entity. {non-strict}
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int deleteNonstrict(Emp entity);


    /**
     * Insert several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return The array of inserted count.
     */
    public int[] insertList(java.util.List<Emp> entityList);

    /**
     * Update several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return The array of updated count.
     */
    public int[] updateList(java.util.List<Emp> entityList);

    /**
     * Update several entities non-strictly.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return The array of updated count.
     */
    public int[] updateListNonstrict(java.util.List<Emp> entityList);

    /**
     * Delete several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return The array of deleted count.
     */
    public int[] deleteList(java.util.List<Emp> entityList);

    /**
     * Delete several entities non-strictly.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return The array of deleted count.
     */
    public int[] deleteListNonstrict(java.util.List<Emp> entityList);

}
