package sample.web.emp;

import java.util.Date;

public class EmpSearchPage extends AbstractEmpPage {

	// ##### プロパティ #####
	public String condEmpName;

	public Date condFromHireDate;

	public Date condToHireDate;

	
	// ##### ロジック #####	
	public Class doSearch() {
		return EmpListPage.class;
	}

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		return null;
	}

}
