package sample.dbflute.allcommon.s2dao;

import org.seasar.extension.jdbc.ResultSetFactory;
import org.seasar.framework.util.PreparedStatementUtil;

import sample.dbflute.allcommon.cbean.FetchNarrowingBean;
import sample.dbflute.allcommon.cbean.FetchNarrowingBeanContext;

import sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext;

/**
 * Fetch page result set factory.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class FetchNarrowingResultSetFactory implements ResultSetFactory {

    // ===================================================================================
    //                                                                          Definition
    //                                                                          ==========
    /** The determination of internal debug. */
    private static final boolean _internalDebug = false;

    /** Log instance. */
    private static final org.apache.commons.logging.Log _log = org.apache.commons.logging.LogFactory.getLog(FetchNarrowingResultSetFactory.class);

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    public FetchNarrowingResultSetFactory() {
    }

    // ===================================================================================
    //                                                                                Main
    //                                                                                ====
    /**
     * @param statement Statement. (NotNull)
     * @return Result set for procedure executing of s2dao. (NotNull)
     */
    public java.sql.ResultSet getResultSet(java.sql.Statement statement) {
        // return org.seasar.framework.util.StatementUtil.getResultSet(statement);
        return doGetResultSet(statement);// This behavior is same as StatementUtil.getResultSet().
    }

    protected java.sql.ResultSet doGetResultSet(java.sql.Statement statement) throws org.seasar.framework.exception.SQLRuntimeException {
        try {
            return statement.getResultSet();
        } catch (java.sql.SQLException ex) {
            throw new org.seasar.framework.exception.SQLRuntimeException(ex);
        }
    }

    /**
     * Create result set.
     * 
     * @param ps Prepared statement. (NotNull)
     * @return Result set. (NotNull)
     */
    public java.sql.ResultSet createResultSet(java.sql.PreparedStatement ps) {
        long before = 0;
        if (_internalDebug && _log.isDebugEnabled()) {
            before = System.currentTimeMillis();
        }
        final java.sql.ResultSet resultSet = PreparedStatementUtil.executeQuery(ps);
        if (_internalDebug && _log.isDebugEnabled()) {
            final long after = System.currentTimeMillis();
            _log.debug("Pure Query Cost: [" + getPerformanceView(after - before) + "]");
        }

        if (!FetchNarrowingBeanContext.isExistFetchNarrowingBeanOnThread()) {
            return resultSet;
        }
        final FetchNarrowingBean cb = FetchNarrowingBeanContext.getFetchNarrowingBeanOnThread();
        if (!isUseFetchNarrowingResultSetWrapper(cb)) {
            return resultSet;
        }
        final FetchNarrowingResultSetWrapper wrapper = new FetchNarrowingResultSetWrapper(resultSet, cb);
        if (OutsideSqlContext.isExistOutsideSqlContextOnThread()) {
            final OutsideSqlContext outsideSqlContext = OutsideSqlContext.getOutsideSqlContextOnThread();
            wrapper.setOffsetByCursorForcedly(outsideSqlContext.isOffsetByCursorForcedly());
            wrapper.setLimitByCursorForcedly(outsideSqlContext.isLimitByCursorForcedly());
        }
        return wrapper;
    }

    protected boolean isUseFetchNarrowingResultSetWrapper(FetchNarrowingBean cb) {
        if (cb.getSafetyMaxResultSize() <= 0 && !cb.isFetchNarrowingEffective()) {
            return false;// It is not necessary to control.
        }
        if (cb.getSafetyMaxResultSize() <= 0 && !cb.isFetchNarrowingSkipStartIndexEffective() && !cb.isFetchNarrowingLoopCountEffective()) {
            return false;// It is not necessary to control. The sql already have been controlled.
        }
        return true;
    }

    /**
     * Get performance view.
     * 
     * @param mil The value of millisecound.
     * @return Performance view. (ex. 1m23s456ms) (NotNull)
     */
    protected String getPerformanceView(long mil) {
        if (mil < 0) {
            return String.valueOf(mil);
        }

        long sec = mil / 1000;
        long min = sec / 60;
        sec = sec % 60;
        mil = mil % 1000;

        StringBuffer sb = new StringBuffer();
        if (min >= 10) { // Minute
            sb.append(min).append("m");
        } else if (min < 10 && min >= 0) {
            sb.append("0").append(min).append("m");
        }
        if (sec >= 10) { // Second
            sb.append(sec).append("s");
        } else if (sec < 10 && sec >= 0) {
            sb.append("0").append(sec).append("s");
        }
        if (mil >= 100) { // Millisecond
            sb.append(mil).append("ms");
        } else if (mil < 100 && mil >= 10) {
            sb.append("0").append(mil).append("ms");
        } else if (mil < 10 && mil >= 0) {
            sb.append("00").append(mil).append("ms");
        }

        return sb.toString();
    }
}
