package sample.dbflute.allcommon.bhv;


import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.dbmeta.DBMeta;
import sample.dbflute.allcommon.helper.MapStringBuilder;
import sample.dbflute.allcommon.helper.MapStringBuilderImpl;

import sample.dbflute.allcommon.bhv.batch.TokenFileReflectionOption;
import sample.dbflute.allcommon.bhv.batch.TokenFileReflectionResult;
import sample.dbflute.allcommon.bhv.batch.TokenFileReflectionFailure;

import sample.dbflute.allcommon.helper.token.file.FileToken;
import sample.dbflute.allcommon.helper.token.file.FileTokenizingCallback;
import sample.dbflute.allcommon.helper.token.file.FileTokenizingRowResource;
import sample.dbflute.allcommon.helper.token.file.FileTokenizingHeaderInfo;
import sample.dbflute.allcommon.helper.token.file.FileTokenizingOption;
import sample.dbflute.allcommon.helper.token.file.impl.FileTokenImpl;

/**
 * The abstract class of behavior-writable.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class AbstractBehaviorWritable extends AbstractBehaviorReadable implements BehaviorWritable {


    // =====================================================================================
    //                                                                       Delegate Method
    //                                                                       ===============
    // -----------------------------------------------------
    //                                                Insert
    //                                                ------
    /**
     * The implementation.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Inserted count.
     */
    protected int callCreate(Entity entity) {
        if (!processBeforeInsert(entity)) { return 1;/*as Normal End*/ }
        return getDaoWritable().create(entity);
    }

    /**
     * Process before insert.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Execution Determination. (true: execute / false: non)
     */
    protected boolean processBeforeInsert(Entity entity) {
        if (!determineExecuteInsert(entity)) { return false; }
        assertEntityNotNull(entity);// If this table use identity, the entity does not have primary-key.
        frameworkFilterEntityOfInsert(entity);
        filterEntityOfInsert(entity);
        assertEntityOfInsert(entity);
        return true;
    }

    // -----------------------------------------------------
    //                                                Update
    //                                                ------
    /**
     * The implementation.
     * {modified only}
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Updated count.
     */
    protected int callModify(Entity entity) {
        if (!processBeforeUpdate(entity)) { return 1;/*as Normal End*/ }
        return getDaoWritable().modifyModifiedOnly(entity);
    }

    /**
     * Process before update.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Execution Determination. (true: execute / false: non)
     */
    protected boolean processBeforeUpdate(Entity entity) {
        if (!determineExecuteUpdate(entity)) { return false; }
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        frameworkFilterEntityOfUpdate(entity);
        filterEntityOfUpdate(entity);
        assertEntityOfUpdate(entity);
        return true;
    }

    // -----------------------------------------------------
    //                                                Delete
    //                                                ------
    /**
     * The implementation.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Deleted count.
     */
    protected int callRemove(Entity entity) {
        if (!processBeforeDelete(entity)) { return 1;/*as Normal End*/ }
        return getDaoWritable().remove(entity);
    }

    /**
     * Process before delete.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Execution Determination. (true: execute / false: non)
     */
    protected boolean processBeforeDelete(Entity entity) {
        if (!determineExecuteDelete(entity)) { return false; }
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        frameworkFilterEntityOfDelete(entity);
        filterEntityOfDelete(entity);
        assertEntityOfDelete(entity);
        return true;
    }

    // -----------------------------------------------------
    //                                    Pre-Process Insert
    //                                    ------------------
    /**
     * Determine execution of insert.
     * 
     * @param entity Entity. (NotNull)
     * @return Execution Determination. (true: execute / false: non)
     */
    protected boolean determineExecuteInsert(Entity entity) {
        return true;
    }

    /**
     * Framework filter the entity of insert.
     * 
     * @param targetEntity Target entity that the type is entity-interface. (NotNull)
     */
    protected void frameworkFilterEntityOfInsert(Entity targetEntity) {
        injectSequenceToPrimaryKeyIfNeeds(targetEntity);
    }

    /**
     * Filter the entity of insert.
     * 
     * @param targetEntity Target entity that the type is entity-interface. (NotNull)
     */
    protected void filterEntityOfInsert(Entity targetEntity) {
    }

    /**
     * Assert the entity of insert.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void assertEntityOfInsert(Entity entity) {
    }

    // -----------------------------------------------------
    //                                    Pre-Process Update
    //                                    ------------------
    /**
     * Determine execution of update.
     * 
     * @param entity Entity. (NotNull)
     * @return Execution Determination. (true: execute / false: non)
     */
    protected boolean determineExecuteUpdate(Entity entity) {
        return true;
    }

    /**
     * Framework filter the entity of update.
     * 
     * @param targetEntity Target entity that the type is entity-interface. (NotNull)
     */
    protected void frameworkFilterEntityOfUpdate(Entity targetEntity) {
    }

    /**
     * Filter the entity of update.
     * 
     * @param targetEntity Target entity that the type is entity-interface. (NotNull)
     */
    protected void filterEntityOfUpdate(Entity targetEntity) {
    }

    /**
     * Assert the entity of update.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void assertEntityOfUpdate(Entity entity) {
    }

    // -----------------------------------------------------
    //                                    Pre-Process Delete
    //                                    ------------------
    /**
     * Determine execution of delete.
     * 
     * @param entity Entity. (NotNull)
     * @return Execution Determination. (true: execute / false: non)
     */
    protected boolean determineExecuteDelete(Entity entity) {
        return true;
    }

    /**
     * Framework filter the entity of delete.
     * 
     * @param targetEntity Target entity that the type is entity-interface. (NotNull)
     */
    protected void frameworkFilterEntityOfDelete(Entity targetEntity) {
    }

    /**
     * Filter the entity of delete.
     * 
     * @param targetEntity Target entity that the type is entity-interface. (NotNull)
     */
    protected void filterEntityOfDelete(Entity targetEntity) {
    }

    /**
     * Assert the entity of delete
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void assertEntityOfDelete(Entity entity) {
    }


    /**
     * The implementation.
     * 
     * @param entityList Entity-list that the type is entity-interface. (NotNull)
     * @return Inserted count.
     */
    public int[] callCreateList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeInsertInternally(entityList);
        return getDaoWritable().createList(entityList);
    }

    /**
     * The implementation.
     * 
     * @param entityList Entity-list that the type is entity-interface. (NotNull)
     * @return Updated count.
     */
    public int[] callModifyList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeUpdateInternally(entityList);
        return getDaoWritable().modifyList(entityList);
    }

    /**
     * The implementation.
     * 
     * @param entityList Entity-list that the type is entity-interface. (NotNull)
     * @return Deleted count.
     */
    public int[] callRemoveList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        helpFilterBeforeDeleteInternally(entityList);
        return getDaoWritable().removeList(entityList);
    }

    protected void assertEntityHasVersionNoValue(Entity entity) {
        if (!getDBMeta().hasVersionNo()) {
            return;
        }
        if (entity.hasVersionNoValue()) {
            return;
        }
        String msg = "Not found the value of 'version no' on the entity!" + getLineSeparator();
        msg = msg + "/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *" + getLineSeparator();
        msg = msg + "Please confirm the existence of the value of 'version no' on the entity." + getLineSeparator();
        msg = msg + "You called the method in which the check for optimistic lock is indispensable. " + getLineSeparator();
        msg = msg + "So 'version no' is required on the entity. " + getLineSeparator();
        msg = msg + "In addition, please confirm the necessity of optimistic lock. It might possibly be unnecessary." + getLineSeparator();
        msg = msg + "- - - - - - - - - -" + getLineSeparator();
        msg = msg + "entity to string = " + entity + getLineSeparator();
        msg = msg + "entity to map    = " + entity.getDBMeta().convertToColumnValueMap(entity) + getLineSeparator();
        msg = msg + "* * * * * * * * * */" + getLineSeparator();
        throw new IllegalStateException(msg);
    }

    protected void assertEntityHasUpdateDateValue(Entity entity) {
        if (!getDBMeta().hasUpdateDate()) {
            return;
        }
        if (entity.hasUpdateDateValue()) {
            return;
        }
        String msg = "Not found the value of 'update date' on the entity!" + getLineSeparator();
        msg = msg + "/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *" + getLineSeparator();
        msg = msg + "Please confirm the existence of the value of 'update date' on the entity." + getLineSeparator();
        msg = msg + "You called the method in which the check for optimistic lock is indispensable. " + getLineSeparator();
        msg = msg + "So 'update date' is required on the entity. " + getLineSeparator();
        msg = msg + "In addition, please confirm the necessity of optimistic lock. It might possibly be unnecessary." + getLineSeparator();
        msg = msg + "- - - - - - - - - -" + getLineSeparator();
        msg = msg + "entity to string = " + entity + getLineSeparator();
        msg = msg + "entity to map    = " + entity.getDBMeta().convertToColumnValueMap(entity) + getLineSeparator();
        msg = msg + "* * * * * * * * * */" + getLineSeparator();
        throw new IllegalStateException(msg);
    }

    // ===================================================================================
    //                                                     Delegate Method Internal Helper
    //                                                     ===============================
    protected void helpFilterBeforeInsertInternally(java.util.List<? extends Entity> entityList) {
        for (final java.util.Iterator ite = entityList.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            if (!determineExecuteInsert(entity)) { continue; }
            processBeforeInsert(entity);
        }
    }

    protected void helpFilterBeforeUpdateInternally(java.util.List<? extends Entity> entityList) {
        for (final java.util.Iterator ite = entityList.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            if (!determineExecuteUpdate(entity)) { continue; }
            processBeforeUpdate(entity);
        }
    }

    protected void helpFilterBeforeDeleteInternally(java.util.List<? extends Entity> entityList) {
        for (final java.util.Iterator ite = entityList.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            if (!determineExecuteDelete(entity)) { continue; }
            processBeforeDelete(entity);
        }
    }

    // ===================================================================================
    //                                                                 Basic Entity Update
    //                                                                 ===================
    /**
     * Create.
     * 
     * @param entity Entity. (NotNull)
     */
    public void create(Entity entity) {
        doCreate(entity);
    }

    abstract protected void doCreate(Entity entity);

    /**
     * Modify.
     * 
     * @param entity Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void modify(Entity entity) {
        doModify(entity);
    }

    abstract protected void doModify(Entity entity);

    /**
     * Modify non strict.
     * 
     * @param entity Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void modifyNonstrict(Entity entity) {
        doModifyNonstrict(entity);
    }

    abstract protected void doModifyNonstrict(Entity entity);

    /**
     * The implementation.
     * 
     * @param entity Entity having primary-key value. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @deprecated Thie method is old style and has wrong performance. Please use modify().
     */
    public void modifyAfterSelect(Entity entity) {
        doModifyAfterSelect(entity);
    }

    /**
     * @param entity Entity having primary-key value. (NotNull)
     * @deprecated Thie method is old style and has wrong performance. Please use modify().
     */
    abstract protected void doModifyAfterSelect(Entity entity);

    /**
     * The implementation.
     * 
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     */
    public void createOrModify(sample.dbflute.allcommon.Entity entity) {
        assertEntityNotNull(entity);
        doCreateOrUpdate(entity);
    }

    abstract protected void doCreateOrUpdate(Entity entity);

    /**
     * The implementation.
     * 
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     */
    public void createOrModifyNonstrict(sample.dbflute.allcommon.Entity entity) {
        assertEntityNotNull(entity);
        doCreateOrUpdateNonstrict(entity);
    }

    abstract protected void doCreateOrUpdateNonstrict(Entity entity);

    /**
     * Create or modify after select. <br />
     * {modify: modified only}
     * 
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     * @deprecated Thie method is old style and has wrong performance. Please use createOrModify().
     */
    public void createOrModifyAfterSelect(sample.dbflute.allcommon.Entity entity) {
        assertEntityNotNull(entity);
        doCreateOrModifyAfterSelect(entity);
    }

    /**
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     * @deprecated Thie method is old style and has wrong performance. Please use createOrModify().
     */
    abstract protected void doCreateOrModifyAfterSelect(Entity entity);

    /**
     * Merge entity.
     * Copy the column data of sourceEntity that the setter has been invoked to destinationEntity.
     * 
     * @param sourceEntity Source entity. (NotNull)
     * @param destinationEntity Destination entity. (NotNull)
     * @deprecated Thie method is old style and has wrong performance.
     */
    abstract protected void mergeEntity(Entity sourceEntity, Entity destinationEntity);

    /**
     * Remove.
     * 
     * @param entity Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public void remove(sample.dbflute.allcommon.Entity entity) {
        assertEntityNotNull(entity);
        callRemove(entity);
    }

    abstract protected void doRemove(Entity entity);

    /**
     * Remove after select.
     * 
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @deprecated Thie method is old style and has wrong performance. Please use remove().
     */
    public void removeAfterSelect(Entity entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        doRemoveAfterSelect(entity);
    }

    /**
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @deprecated Thie method is old style and has wrong performance. Please use remove().
     */
    abstract protected void doRemoveAfterSelect(Entity entity);

    // ===================================================================================
    //                                                 Basic Entity Update Internal Helper
    //                                                 ===================================
    // -----------------------------------------------------
    //                                                Update
    //                                                ------
    protected <ENTITY_TYPE extends Entity> void helpUpdateInternally(ENTITY_TYPE entity, InternalUpdateCallback<ENTITY_TYPE> callback) {
        assertEntityNotNull(entity);
        assertEntityHasVersionNoValue(entity);
        assertEntityHasUpdateDateValue(entity);
        final int updatedCount = callback.callbackDelegateUpdate(entity);
        if (updatedCount == 0) {
            throw new sample.dbflute.allcommon.exception.EntityAlreadyDeletedException(entity.toString());
        } else if (updatedCount > 1) {
            String msg = "updatedCount=" + updatedCount + ": " + entity.toString();
            throw new sample.dbflute.allcommon.exception.EntityDuplicatedException(msg);
        }
    }

    protected static interface InternalUpdateCallback<ENTITY_TYPE extends Entity> {
        public int callbackDelegateUpdate(ENTITY_TYPE entity);
    }

    protected <ENTITY_TYPE extends Entity> void helpUpdateNonstrictInternally(ENTITY_TYPE entity, InternalUpdateNonstrictCallback<ENTITY_TYPE> callback) {
        assertEntityNotNull(entity);
        final int updatedCount = callback.callbackDelegateUpdateNonstrict(entity);
        if (updatedCount == 0) {
            throw new sample.dbflute.allcommon.exception.EntityAlreadyDeletedException(entity.toString());
        } else if (updatedCount > 1) {
            String msg = "updatedCount=" + updatedCount + ": " + entity.toString();
            throw new sample.dbflute.allcommon.exception.EntityDuplicatedException(msg);
        }
    }

    protected static interface InternalUpdateNonstrictCallback<ENTITY_TYPE extends Entity> {
        public int callbackDelegateUpdateNonstrict(ENTITY_TYPE entity);
    }

    // -----------------------------------------------------
    //                                        InsertOrUpdate
    //                                        --------------
    protected <ENTITY_TYPE extends Entity, CB_TYPE extends ConditionBean>
            void helpInsertOrUpdateInternally(ENTITY_TYPE entity, InternalInsertOrUpdateCallback<ENTITY_TYPE, CB_TYPE> callback) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            callback.callbackInsert(entity);
        } else {
            RuntimeException exception = null;
            try {
                callback.callbackUpdate(entity);
            } catch (sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException e) {
                if (e.getRows() == 0) {
                    exception = e;
                }
            } catch (sample.dbflute.allcommon.exception.EntityAlreadyDeletedException e) {
                exception = e;
            }
            if (exception != null) {
                final CB_TYPE cb = callback.callbackNewMyConditionBean();
                cb.acceptPrimaryKeyMapString(getDBMeta().extractPrimaryKeyMapString(entity));
                if (callback.callbackSelectCount(cb) == 0) {
                    callback.callbackInsert(entity);
                } else {
                    throw exception;
                }
            }
        }
    }

    protected static interface InternalInsertOrUpdateCallback<ENTITY_TYPE extends Entity, CB_TYPE extends ConditionBean> {
        public void callbackInsert(ENTITY_TYPE entity);
        public void callbackUpdate(ENTITY_TYPE entity);
        public CB_TYPE callbackNewMyConditionBean();
        public int callbackSelectCount(CB_TYPE cb);
    }

    protected <ENTITY_TYPE extends Entity> void helpInsertOrUpdateInternally(ENTITY_TYPE entity, InternalInsertOrUpdateNonstrictCallback<ENTITY_TYPE> callback) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            callback.callbackInsert(entity);
        } else {
            try {
                callback.callbackUpdateNonstrict(entity);
            } catch (sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException e) {
                callback.callbackInsert(entity);
            } catch (sample.dbflute.allcommon.exception.EntityAlreadyDeletedException e) {
                callback.callbackInsert(entity);
            }
        }
    }

    protected static interface InternalInsertOrUpdateNonstrictCallback<ENTITY_TYPE extends Entity> {
        public void callbackInsert(ENTITY_TYPE entity);
        public void callbackUpdateNonstrict(ENTITY_TYPE entity);
    }

    // -----------------------------------------------------
    //                                                Delete
    //                                                ------
    protected <ENTITY_TYPE extends Entity> void helpDeleteInternally(ENTITY_TYPE entity, InternalDeleteCallback<ENTITY_TYPE> callback) {
        assertEntityNotNull(entity);
        assertEntityHasVersionNoValue(entity);
        assertEntityHasUpdateDateValue(entity);
        final int deletedCount = callback.callbackDelegateDelete(entity);
        if (deletedCount == 0) {
            throw new sample.dbflute.allcommon.exception.EntityAlreadyDeletedException(entity.toString());
        } else if (deletedCount > 1) {
            String msg = "deletedCount=" + deletedCount + ": " + entity.toString();
            throw new sample.dbflute.allcommon.exception.EntityDuplicatedException(msg);
        }
    }

    protected static interface InternalDeleteCallback<ENTITY_TYPE extends Entity> {
        public int callbackDelegateDelete(ENTITY_TYPE entity);
    }

    protected <ENTITY_TYPE extends Entity> void helpDeleteNonstrictInternally(ENTITY_TYPE entity, InternalDeleteNonstrictCallback<ENTITY_TYPE> callback) {
        assertEntityNotNull(entity);
        final int deletedCount = callback.callbackDelegateDeleteNonstrict(entity);
        if (deletedCount == 0) {
            throw new sample.dbflute.allcommon.exception.EntityAlreadyDeletedException(entity.toString());
        } else if (deletedCount > 1) {
            String msg = "deletedCount=" + deletedCount + ": " + entity.toString();
            throw new sample.dbflute.allcommon.exception.EntityDuplicatedException(msg);
        }
    }

    protected static interface InternalDeleteNonstrictCallback<ENTITY_TYPE extends Entity> {
        public int callbackDelegateDeleteNonstrict(ENTITY_TYPE entity);
    }

    protected <ENTITY_TYPE extends Entity> void helpDeleteNonstrictIgnoreDeletedInternally(ENTITY_TYPE entity, InternalDeleteNonstrictIgnoreDeletedCallback<ENTITY_TYPE> callback) {
        assertEntityNotNull(entity);
        final int deletedCount = callback.callbackDelegateDeleteNonstrict(entity);
        if (deletedCount == 0) {
            return;
        } else if (deletedCount > 1) {
            String msg = "deletedCount=" + deletedCount + ": " + entity.toString();
            throw new sample.dbflute.allcommon.exception.EntityDuplicatedException(msg);
        }
    }

    protected static interface InternalDeleteNonstrictIgnoreDeletedCallback<ENTITY_TYPE extends Entity> {
        public int callbackDelegateDeleteNonstrict(ENTITY_TYPE entity);
    }


    // ===================================================================================
    //                                                                   Basic Lump Update
    //                                                                   =================
    /**
     * Lump create the list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return The array of created count.
     */
    public int[] lumpCreate(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return callCreateList(entityList);
    }

    /**
     * Create list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Created count.
     * @deprecated Sorry! This method name is very confusing. Please use lumpCreate().
     */
    public int createList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return lumpCreate(entityList).length;
    }

    /**
     * Lump Modify the list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Modified count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] lumpModify(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return callModifyList(entityList);
    }

    /**
     * Modify list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Modified count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use lumpModify().
     */
    public int modifyList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return lumpModify(entityList).length;
    }

    /**
     * Lump remove the list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Removed count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] lumpRemove(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return callRemoveList(entityList);
    }

    /**
     * Remove list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Removed count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use lumpRemove().
     */
    public int removeList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return lumpRemove(entityList).length;
    }

    /**
     * Inject sequence to primary key if it needs.
     * 
     * @param entity Entity. (NotNull)
     */
    protected void injectSequenceToPrimaryKeyIfNeeds(Entity entity) {
        final DBMeta dbmeta = entity.getDBMeta();
        if (!dbmeta.hasSequence() || dbmeta.hasTwoOrMorePrimaryKeys() || entity.hasPrimaryKeyValue()) {
            return;
        }
        final java.math.BigDecimal sequenceValue = readNextVal();
        final String columnDbName = dbmeta.getPrimaryUniqueInfo().getFirstColumn().getColumnDbName();
        final java.util.Map<String, String> map = new java.util.HashMap<String, String>();
        map.put(columnDbName, sequenceValue.toString());
        dbmeta.acceptPrimaryKeyMap(entity, map);
    }

    // =====================================================================================
    //                                                                            Token File
    //                                                                            ==========
    /**
     * Reflect(insert or update) token-file to this table.
     * 
     * @param filename Name of the file. (NotNull and NotEmpty)
     * @param tokenFileReflectionOption token-file-reflection-option. (NotNull and Required{delimiter and encoding})
     * @return Token-file-reflection-result. (NotNull)
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public TokenFileReflectionResult reflectTokenFile(String filename, TokenFileReflectionOption tokenFileReflectionOption) throws java.io.FileNotFoundException, java.io.IOException {
        assertStringNotNullAndNotTrimmedEmpty("filename", filename);
        assertFileTokenReflectionOption(tokenFileReflectionOption);

        final TokenFileReflectionResult result = buildTokenFileReflectionResult();
        final FileTokenizingCallback fileTokenizingCallback = buildFileTokenReflectionFileTokenizingCallback(tokenFileReflectionOption, result);
        final FileTokenizingOption fileTokenizingOption = buildFileTokenReflectionFileTokenizingOption(tokenFileReflectionOption);
        final FileToken fileToken = new FileTokenImpl();
        fileToken.tokenize(filename, fileTokenizingCallback, fileTokenizingOption);
        return result;
    }

    /**
     * Reflect(insert or update) token-file to this table.
     * 
     * @param inputStream Input stream. (NotNull and NotClosed)
     * @param tokenFileReflectionOption token-file-reflection-option. (NotNull and Required{delimiter and encoding})
     * @return Token-file-reflection-result. (NotNull)
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public TokenFileReflectionResult reflectTokenFile(java.io.InputStream inputStream, TokenFileReflectionOption tokenFileReflectionOption) throws java.io.FileNotFoundException, java.io.IOException {
        assertObjectNotNull("inputStream", inputStream);
        assertFileTokenReflectionOption(tokenFileReflectionOption);

        final TokenFileReflectionResult result = buildTokenFileReflectionResult();
        final FileTokenizingCallback fileTokenizingCallback = buildFileTokenReflectionFileTokenizingCallback(tokenFileReflectionOption, result);
        final FileTokenizingOption fileTokenizingOption = buildFileTokenReflectionFileTokenizingOption(tokenFileReflectionOption);
        final FileToken fileToken = new FileTokenImpl();
        fileToken.tokenize(inputStream, fileTokenizingCallback, fileTokenizingOption);
        return result;
    }

    protected void assertFileTokenReflectionOption(TokenFileReflectionOption tokenFileReflectionOption) {
        assertObjectNotNull("tokenFileReflectionOption", tokenFileReflectionOption);

        final String encoding = tokenFileReflectionOption.getEncoding();
        final String delimiter = tokenFileReflectionOption.getDelimiter();
        assertStringNotNullAndNotTrimmedEmpty("encoding", encoding);
        assertObjectNotNull("delimiter", delimiter);
    }

    protected TokenFileReflectionResult buildTokenFileReflectionResult() {
        final TokenFileReflectionResult result = new TokenFileReflectionResult();
        final java.util.List<TokenFileReflectionFailure> failureList = new java.util.ArrayList<TokenFileReflectionFailure>();
        result.setFailureList(failureList);
        return result;
    }

    protected FileTokenizingCallback buildFileTokenReflectionFileTokenizingCallback(TokenFileReflectionOption tokenFileReflectionOption, final TokenFileReflectionResult result) throws java.io.FileNotFoundException, java.io.IOException {
        assertObjectNotNull("tokenFileReflectionOption", tokenFileReflectionOption);

        final String encoding = tokenFileReflectionOption.getEncoding();
        final String delimiter = tokenFileReflectionOption.getDelimiter();
        final boolean interruptIfError = tokenFileReflectionOption.isInterruptIfError();
        assertStringNotNullAndNotTrimmedEmpty("encoding", encoding);
        assertObjectNotNull("delimiter", delimiter);
        final java.util.List<TokenFileReflectionFailure> failureList = result.getFailureList();
        assertObjectNotNull("failureList", failureList);

        final FileTokenizingCallback fileTokenizingCallback = new FileTokenizingCallback() {
            public void handleRowResource(FileTokenizingRowResource fileTokenizingRowResource) {
                final FileTokenizingHeaderInfo fileTokenizingHeaderInfo = fileTokenizingRowResource.getFileTokenizingHeaderInfo();
                final java.util.List<String> columnNameList = fileTokenizingHeaderInfo.getColumnNameList();
                final java.util.List<String> valueList = fileTokenizingRowResource.getValueList();

                // Set up columnNameList of result object.
                if (result.getColumnNameList() == null) {
                    result.setColumnNameList(columnNameList);
                }

                Entity entity = null;
                try {
                    // Create entity by the list of value composed of String.
                    entity = createEntityByStringValueList(columnNameList, valueList);

                    // Create or modify as non-strict.
                    doCreateOrUpdateNonstrict(entity);

                    // Increment successCount of result object.
                    result.incrementSuccessCount();
                } catch (RuntimeException e) {
                    if (interruptIfError) {
                        throw e;
                    }
                    final TokenFileReflectionFailure failure = new TokenFileReflectionFailure();
                    failure.setColumnNameList(columnNameList);
                    failure.setValueList(valueList);
                    failure.setRowString(fileTokenizingRowResource.getRowString());
                    failure.setRowNumber(fileTokenizingRowResource.getRowNumber());
                    failure.setLineNumber(fileTokenizingRowResource.getLineNumber());
                    if (entity != null) {
                        failure.setEntity(entity);
                    }
                    failure.setException(e);
                    failureList.add(failure);
                }
            }
        };
        return fileTokenizingCallback;
    }

    protected Entity createEntityByStringValueList(java.util.List<String> columnNameList, java.util.List<String> valueList) {
        final MapStringBuilder builder = new MapStringBuilderImpl();
        builder.setMsMapMark(MAP_STRING_MAP_MARK);
        builder.setMsStartBrace(MAP_STRING_START_BRACE);
        builder.setMsEndBrace(MAP_STRING_END_BRACE);
        builder.setMsDelimiter(MAP_STRING_DELIMITER);
        builder.setMsEqual(MAP_STRING_EQUAL);
        builder.setColumnNameList(columnNameList);
        final String mapString = builder.buildFromList(valueList);

        final Entity entity = getDBMeta().newEntity();
        getDBMeta().acceptColumnValueMapString(entity, mapString);
        return entity;
    }

    protected FileTokenizingOption buildFileTokenReflectionFileTokenizingOption(TokenFileReflectionOption tokenFileReflectionOption) throws java.io.FileNotFoundException, java.io.IOException {
        assertObjectNotNull("tokenFileReflectionOption", tokenFileReflectionOption);

        final String encoding = tokenFileReflectionOption.getEncoding();
        final String delimiter = tokenFileReflectionOption.getDelimiter();
        assertStringNotNullAndNotTrimmedEmpty("encoding", encoding);
        assertObjectNotNull("delimiter", delimiter);

        final FileTokenizingOption fileTokenizingOption = new FileTokenizingOption();
        fileTokenizingOption.setEncoding(encoding);
        fileTokenizingOption.setDelimiter(delimiter);
        if (tokenFileReflectionOption.isHandleEmptyAsNull()) {
            fileTokenizingOption.handleEmptyAsNull();
        }
        return fileTokenizingOption;
    }
}
