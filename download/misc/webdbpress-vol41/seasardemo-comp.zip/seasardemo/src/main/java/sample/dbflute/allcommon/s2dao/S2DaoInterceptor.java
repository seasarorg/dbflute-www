package sample.dbflute.allcommon.s2dao;

import java.util.Arrays;
import java.util.List;

import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.cbean.ConditionBeanContext;
import sample.dbflute.allcommon.cbean.FetchNarrowingBeanContext;
import sample.dbflute.allcommon.cbean.FetchNarrowingBean;
import sample.dbflute.allcommon.util.TraceViewUtil;

/**
 * My-DaoInterceptor.
 * Customises original class 'S2DaoInterceptor'.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class S2DaoInterceptor extends org.seasar.framework.aop.interceptors.AbstractInterceptor {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /** Log instance. */
    private static final org.apache.commons.logging.Log _log = org.apache.commons.logging.LogFactory.getLog(S2DaoInterceptor.class);

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Dao meta data factory. */
    private org.seasar.dao.DaoMetaDataFactory daoMetaDataFactory_;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param daoMetaDataFactory Dao meta data factory.
     */
    public S2DaoInterceptor(org.seasar.dao.DaoMetaDataFactory daoMetaDataFactory) {
        daoMetaDataFactory_ = daoMetaDataFactory;
    }

    // ===================================================================================
    //                                                                                Main
    //                                                                                ====
    /**
     * Invoke.
     * 
     * @param invocation Method invocation.
     * @return Result of the method.
     * @throws Throwable
     */
    public Object invoke(org.aopalliance.intercept.MethodInvocation invocation) throws Throwable {
        final java.lang.reflect.Method method = invocation.getMethod();
        if (!org.seasar.framework.util.MethodUtil.isAbstract(method)) {
            return invocation.proceed();
        }

        if (_log.isDebugEnabled()) {
            traceMethod(invocation);
        }

        long before = 0;
        if (_log.isDebugEnabled()) {
            before = System.currentTimeMillis();
        }

        final org.seasar.dao.SqlCommand cmd;
        {
            long beforeCmd = 0;
            if (_log.isDebugEnabled()) {
                beforeCmd = System.currentTimeMillis();
            }

            final Class targetClass = getTargetClass(invocation);
            final org.seasar.dao.DaoMetaData dmd = daoMetaDataFactory_.getDaoMetaData(targetClass);
            cmd = dmd.getSqlCommand(method.getName());

            if (_log.isDebugEnabled()) {
                final long afterCmd = System.currentTimeMillis();
                if (beforeCmd != afterCmd) {
                    traceSqlCommand(invocation, cmd, beforeCmd, afterCmd);
                }
            }
        }

        final ConditionBean cb = preprocessConditionBean(invocation, cmd);
        Object ret = null;

        try {
            try {
                ret = cmd.execute(invocation.getArguments());
            } catch (org.seasar.dao.NotSingleRowUpdatedRuntimeException notSingleRow) {
                throw new sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException(notSingleRow);
            }
        } catch (Exception e) {
            _log.debug("SqlCommand threw the exception: " + e.getClass() + " msg=" + e.getMessage());
            _log.debug("    method   --> " + invocation.getMethod());
            _log.debug("    argument --> " + TraceViewUtil.convertObjectArrayToStringView(invocation.getArguments()));
            if (e instanceof org.seasar.framework.exception.SQLRuntimeException) {
                final Throwable causeException = ((org.seasar.framework.exception.SQLRuntimeException)e).getCause();
                if (causeException instanceof org.seasar.framework.exception.SSQLException) {
                    final String sql = ((org.seasar.framework.exception.SSQLException)causeException).getSql();
                    _log.debug("    sql      --> " + sql);
                }
            }
            throw e;
        } finally {
            postprocessConditionBean(invocation, cb);
        }
        final Class retType = method.getReturnType();
        assertRetType(retType, ret);

        if (_log.isDebugEnabled()) {
            final long after = System.currentTimeMillis();
            traceReturn(invocation, retType, ret, before, after);
        }

        if (retType.isPrimitive()) {
            return org.seasar.framework.util.NumberConversionUtil.convertPrimitiveWrapper(retType, ret);
        } else if (Number.class.isAssignableFrom(retType)) {
            return org.seasar.framework.util.NumberConversionUtil.convertNumber(retType, ret);
        } else {
            return ret;
        }
    }

    // -----------------------------------------------------
    //                                          Trace Method
    //                                          ------------
    protected void traceMethod(org.aopalliance.intercept.MethodInvocation invocation) {
        final java.lang.reflect.Method method = invocation.getMethod();
        final String name = method.getDeclaringClass().getSimpleName();
        final String invokeNameWithoutKakko = removeBasePrefixIfNeeds(name)  + "." + method.getName();
        final String equalBorder = buildFitBorder("", "=", invokeNameWithoutKakko, false);
        final String daoInvokeName = invokeNameWithoutKakko + "()";

        _log.debug("/=====================================================" + equalBorder + "==");
        _log.debug("                                                      " + daoInvokeName);
        _log.debug("                                                      " + equalBorder + "=/");

        tracePath();
    }

    protected void tracePath() {
        final StackTraceElement[] stackTrace = new Exception().getStackTrace();
        final InvokeNameExtractingResult behaviorResult = extractBehaviorInvokeName(stackTrace);
        final int bhvNextIndex = behaviorResult.getNextStartIndex();
        final InvokeNameExtractingResult clientResult = extractClientInvokeName(stackTrace, bhvNextIndex);
        final int clientFirstIndex = clientResult.getFoundFirstIndex();
        final InvokeNameExtractingResult byPassResult = extractByPassInvokeName(stackTrace, bhvNextIndex, clientFirstIndex - bhvNextIndex);

        final String clientInvokeName = clientResult.getInvokeName();
        final String byPassInvokeName = byPassResult.getInvokeName();
        final String behaviorInvokeName = behaviorResult.getInvokeName();
        if (clientInvokeName.trim().length() == 0 && byPassInvokeName.trim().length() == 0 && behaviorInvokeName.trim().length() == 0) {
            return;
        }
        final String path = clientInvokeName + byPassInvokeName + behaviorInvokeName + "...";
        // *I will delete this at the future.
        // final String hyphenBorder = buildFitBorder("/", "-", path, true);
        // _log.debug(hyphenBorder);
        _log.debug(path);
        // _log.debug("- - - - - - - - - -/");
    }

    protected String buildFitBorder(String prefix, String element, String lengthTargetString, boolean space) {
        final int length = space ? lengthTargetString.length() / 2 : lengthTargetString.length();
        final StringBuffer sb = new StringBuffer();
        sb.append(prefix);
        for (int i = 0; i < length; i++) {
            sb.append(element);
            if (space) {
                sb.append(" ");
            }
        }
        if (space) {
            sb.append(element);
        }
        return sb.toString();
    }

    protected InvokeNameExtractingResult extractClientInvokeName(StackTraceElement[] stackTrace, final int startIndex) {
        final List<String> suffixList = Arrays.asList(new String[]{"Page", "Action"});
        final InvokeNameExtractingCallback callback = new InvokeNameExtractingCallback() {
            public boolean isTargetElement(String className, String methodName) {
                return isClassNameEndsWith(className, suffixList);
            }
            public String filterSimpleClassName(String simpleClassName) {
                return simpleClassName;
            }
            public boolean isUseAdditionalInfo() {
                return true;
            }
            public int getStartIndex() {
                return startIndex;
            }
            public int getLoopSize() {
                return 20;
            }
        };
        return extractInvokeName(callback, stackTrace);
    }

    protected InvokeNameExtractingResult extractByPassInvokeName(StackTraceElement[] stackTrace, final int startIndex, final int loopSize) {
        final List<String> suffixList = Arrays.asList(new String[]{"Service", "ServiceImpl", "Facade", "FacadeImpl"});
        final InvokeNameExtractingCallback callback = new InvokeNameExtractingCallback() {
            public boolean isTargetElement(String className, String methodName) {
                return isClassNameEndsWith(className, suffixList);
            }
            public String filterSimpleClassName(String simpleClassName) {
                return simpleClassName;
            }
            public boolean isUseAdditionalInfo() {
                return true;
            }
            public int getStartIndex() {
                return startIndex;
            }
            public int getLoopSize() {
                return loopSize >= 0 ? loopSize : 20;
            }
        };
        return extractInvokeName(callback, stackTrace);
    }

    protected InvokeNameExtractingResult extractBehaviorInvokeName(StackTraceElement[] stackTrace) {
        final List<String> suffixList = Arrays.asList(new String[]{"Bhv", "Bhv$", "BehaviorReadable", "BehaviorWritable"});
        final InvokeNameExtractingCallback callback = new InvokeNameExtractingCallback() {
            public boolean isTargetElement(String className, String methodName) {
                return isClassNameEndsWith(className, suffixList);
            }
            public String filterSimpleClassName(String simpleClassName) {
                return removeBasePrefixIfNeeds(simpleClassName);
            }
            public boolean isUseAdditionalInfo() {
                return false;
            }
            public int getStartIndex() {
                return 0;
            }
            public int getLoopSize() {
                return 20;
            }
        };
        return extractInvokeName(callback, stackTrace);
    }

    protected boolean isClassNameEndsWith(String className, List<String> suffixList) {
        for (String suffix : suffixList) {
            if (className.endsWith(suffix)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param callback Callback. (NotNull)
     * @param stackTrace Stack trace. (NotNull)
     * @return Invoke name. (NotNull: If not found, returns empty string.)
     */
    protected InvokeNameExtractingResult extractInvokeName(InvokeNameExtractingCallback callback, StackTraceElement[] stackTrace) {
        String targetSimpleClassName = null;
        String targetMethodName = null;
        int lineNumber = 0;
        int foundIndex = -1;// The minus one means 'not found'.
        int foundFirstIndex = -1;// The minus one means 'not found'.
        boolean onTarget = false;
        for (int i=callback.getStartIndex(); i < stackTrace.length; i++) {
            final StackTraceElement element = stackTrace[i];
            if (i > callback.getStartIndex() + callback.getLoopSize()) {
                break;
            }
            final String className = element.getClassName();
            if (className.startsWith("sun.") || className.startsWith("java.")) {
                if (onTarget) {
                    break;
                }
                continue;
            }
            final String methodName = element.getMethodName();
            if (callback.isTargetElement(className, methodName)) {
                if (methodName.equals("invoke")) {
                    continue;
                }
                targetSimpleClassName = className.substring(className.lastIndexOf(".") + 1);
                targetMethodName = methodName;
                if (callback.isUseAdditionalInfo()) {
                    lineNumber = element.getLineNumber();
                }
                foundIndex = i;
                if (foundFirstIndex == -1) {
                    foundFirstIndex = i;
                }
                onTarget = true;
                continue;
            }
            if (onTarget) {
                break;
            }
        }
        final InvokeNameExtractingResult result = new InvokeNameExtractingResult();
        if (targetSimpleClassName == null) {
            result.setInvokeName("");
            return result;
        }
        if (lineNumber > 0) {
            result.setInvokeName(callback.filterSimpleClassName(targetSimpleClassName) + "." + targetMethodName + "():" + lineNumber + " --> ");
        } else {
            result.setInvokeName(callback.filterSimpleClassName(targetSimpleClassName) + "." + targetMethodName + "() --> ");
        }
        result.setFoundIndex(foundIndex);
        result.setFoundFirstIndex(foundFirstIndex);
        return result;
    }

    protected static interface InvokeNameExtractingCallback {
        public boolean isTargetElement(String className, String methodName);
        public String filterSimpleClassName(String simpleClassName);
        public boolean isUseAdditionalInfo();
        public int getStartIndex();
        public int getLoopSize();
    }

    protected static class InvokeNameExtractingResult {
        protected String _invokeName;
        protected int _foundIndex;
        protected int _foundFirstIndex;

        public int getNextStartIndex() {
            return _foundIndex + 1;
        }

        public String getInvokeName() {
            return _invokeName;
        }
        public void setInvokeName(String invokeName) {
            this._invokeName = invokeName;
        }
        public int getFoundIndex() {
            return _foundIndex;
        }
        public void setFoundIndex(int foundIndex) {
            this._foundIndex = foundIndex;
        }
        public int getFoundFirstIndex() {
            return _foundFirstIndex;
        }
        public void setFoundFirstIndex(int foundFirstIndex) {
            this._foundFirstIndex = foundFirstIndex;
        }
    }

    protected String removeBasePrefixIfNeeds(String name) {
        if (!name.startsWith("Bs")) {
            return name;
        }
        final int prefixLength = "Bs".length();
        if (!Character.isUpperCase(name.substring(prefixLength).charAt(0))) {
            return name;
        }
        if (name.length() <= prefixLength) {
            return name;
        }
        return "" + name.substring(prefixLength);
    }

    // -----------------------------------------------------
    //                                      Trace SqlCommand
    //                                      ----------------
    protected void traceSqlCommand(org.aopalliance.intercept.MethodInvocation invocation, org.seasar.dao.SqlCommand cmd, long beforeCmd, long afterCmd) {
        _log.debug("SqlCommand Initialization Cost: [" + TraceViewUtil.convertToPerformanceView(afterCmd - beforeCmd) + "]");
    }

    protected void assertRetType(Class retType, Object ret) {
        if (java.util.List.class.isAssignableFrom(retType)) {
            if (ret != null && !(ret instanceof java.util.List)) {
                String msg = "The retType is difference from actual return: ";
                msg = msg + "retType=" + retType + " ret.getClass()=" + ret.getClass() + " ref=" + ret;
                throw new IllegalStateException(msg);
            }
        } else if (Entity.class.isAssignableFrom(retType)) {
            if (ret != null && !(ret instanceof Entity)) {
                String msg = "The retType is difference from actual return: ";
                msg = msg + "retType=" + retType + " ret.getClass()=" + ret.getClass() + " ref=" + ret;
                throw new IllegalStateException(msg);
            }
        }
    }

    // -----------------------------------------------------
    //                                          Trace Return
    //                                          ------------
    protected void traceReturn(org.aopalliance.intercept.MethodInvocation invocation, Class retType, Object ret, long before, long after) throws Throwable {
        try {
            final String daoResultPrefix = "===========/ [" + TraceViewUtil.convertToPerformanceView(after - before) + " - ";
            if (java.util.List.class.isAssignableFrom(retType)) {
                if (ret == null) {
                    _log.debug(daoResultPrefix + "Selected list: null]");
                } else {
                    final java.util.List ls = (java.util.List) ret;
                    if (ls.isEmpty()) {
                        _log.debug(daoResultPrefix + "Selected list: 0]");
                    } else {
                        _log.debug(daoResultPrefix + "Selected list: " + ls.size() + " first=" + ls.get(0) + "]");
                    }
                }
            } else if (Entity.class.isAssignableFrom(retType)) {
                if (ret == null) {
                    _log.debug(daoResultPrefix + "Selected entity: null" + "]");
                } else {
                    final Entity entity = (Entity) ret;
                    _log.debug(daoResultPrefix + "Selected entity: " + entity + "]");
                }
            } else {
                if (isSelectCountIgnoreFetchScopeMethod(invocation)) {
                    _log.debug(daoResultPrefix + "Selected count: " + ret + "]");
                } else {
                    _log.debug(daoResultPrefix + "Result: " + ret + "]");
                }
            }
            _log.debug(" ");
        } catch (Exception e) {
            String msg = "Result object debug threw the exception: methodName=";
            msg = msg + invocation.getMethod().getName() + " retType=" + retType;
            msg = msg + " ret=" + ret;
            _log.warn(msg, e);
            throw e;
        }
    }

    // ===================================================================================
    //                                                                    Pre Post Process
    //                                                                    ================
    /**
     * Preprocess condition-bean.
     * <p>
     * If this method is condition bean select target, make dynamic sql.
     * Else nothing.
     * 
     * @param invocation Method invocation. (NotNull)
     * @param cmd Sql command. (NotNull)
     * @return Condition-bean. (Nullable)
     */
    protected ConditionBean preprocessConditionBean(org.aopalliance.intercept.MethodInvocation invocation, org.seasar.dao.SqlCommand cmd) {
        clearThreadLocal();

        final Class<sample.dbflute.allcommon.annotation.OutsideSql> outsideSqlType = sample.dbflute.allcommon.annotation.OutsideSql.class;
        final sample.dbflute.allcommon.annotation.OutsideSql outsideSql = invocation.getMethod().getAnnotation(outsideSqlType);
        if (outsideSql != null && (outsideSql.dynamicAnalysis() || outsideSql.offsetByCursor() || outsideSql.offsetByCursor() || outsideSql.limitByCursor())) {
            final sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext outsideSqlContext = new sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext();
            outsideSqlContext.setDynamicAnalysis(outsideSql.dynamicAnalysis());
            outsideSqlContext.setOffsetByCursorForcedly(outsideSql.offsetByCursor());
            outsideSqlContext.setLimitByCursorForcedly(outsideSql.limitByCursor());
            sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext.setOutsideSqlContextOnThread(outsideSqlContext);
        }

        final ConditionBean cb;
        {
            final Object[] args = invocation.getArguments();
            if (args == null || !(args.length >= 1)) {
                return null;
            }

            final Object arg0 = args[0];
            if (arg0 == null) {
                return null;
            }

            if (!ConditionBeanContext.isTheTypeConditionBean(arg0.getClass())) {// The argument is not condition-bean...
                if (FetchNarrowingBeanContext.isTheTypeFetchNarrowingBean(arg0.getClass()) && !isSelectCountIgnoreFetchScopeMethod(invocation)) {
                    // Fetch-narrowing-bean and Not select count!
                    FetchNarrowingBeanContext.setFetchNarrowingBeanOnThread((FetchNarrowingBean)arg0);
                }
                return null;
            }

            cb = (ConditionBean)arg0;
        }

        if (!(cmd instanceof S2DaoSelectDynamicCommand)) {// The argument is condition-bean, but this method use outer-sql-file...
            FetchNarrowingBeanContext.setFetchNarrowingBeanOnThread(cb);
            return null;
        }

        if (isSelectCountIgnoreFetchScopeMethod(invocation)) {
            cb.xsetupSelectCountIgnoreFetchScope();
        } else {
            FetchNarrowingBeanContext.setFetchNarrowingBeanOnThread(cb);
        }

        ConditionBeanContext.setConditionBeanOnThread(cb);
        return cb;
    }

    /**
     * Postprocess condition-bean.
     * 
     * @param invocation Method invocation. (NotNull)
     * @param cb Condition-bean. (Nullable)
     */
    public void postprocessConditionBean(org.aopalliance.intercept.MethodInvocation invocation, ConditionBean cb) {
        clearThreadLocal();

        if (cb != null && isSelectCountIgnoreFetchScopeMethod(invocation)) {
            cb.xafterCareSelectCountIgnoreFetchScope();
        }
    }

    protected void clearThreadLocal() {
        if (sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext.isExistOutsideSqlContextOnThread()) {
            sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext.clearOutsideSqlContextOnThread();
        }
        if (FetchNarrowingBeanContext.isExistFetchNarrowingBeanOnThread()) {
            FetchNarrowingBeanContext.clearFetchNarrowingBeanOnThread();
        }
        if (ConditionBeanContext.isExistConditionBeanOnThread()) {
            ConditionBeanContext.clearConditionBeanOnThread();
        }
    }

    // ===================================================================================
    //                                                                       Determination
    //                                                                       =============
    /**
     * Is select count ignore-fetch-scope method?
     * 
     * @param invocation Method invocation. (NotNull)
     * @return Determination.
     */
    protected boolean isSelectCountIgnoreFetchScopeMethod(org.aopalliance.intercept.MethodInvocation invocation) {
        final String name = invocation.getMethod().getName();
        if (name.startsWith("readCount")
                || name.startsWith("selectCount")
                || name.startsWith("readCountIgnoreFetchScope")
                || name.startsWith("selectCountIgnoreFetchScope")) {
            return true;
        } else {
            return false;
        }
    }

}