package sample.dbflute.allcommon.cbean.grouping;

/**
 * The interface of grouping switch point determiner.
 * 
 * @param <ENTITY> The type of entity.
 * @author DBFlute(AutoGenerator)
 */
public interface GroupingRowEndDeterminer<ENTITY> {

    public boolean determine(int columnIndex, int columnCount, GroupingRowResource<ENTITY> rowResource, ENTITY nextEntity);
}
