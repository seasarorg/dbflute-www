package sample.dbflute.allcommon.helper.character;

/**
 * The interface of Japanese character.
 *
 * @author DBFlute(AutoGenerator)
 */
public interface JapaneseCharacter {

    public String toDoubleByteKatakana(String target);
}
