package sample.dbflute.bsentity.dbmeta;


import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.dbmeta.AbstractDBMeta;
import sample.dbflute.exentity.Dept;
import sample.dbflute.allcommon.dbmeta.info.ColumnInfo;
import sample.dbflute.allcommon.dbmeta.info.RelationInfo;
import sample.dbflute.allcommon.dbmeta.info.UniqueInfo;

/**
 * The dbmeta of DEPT. (Singleton)
 * 
 * <pre>
 * [primary-key]
 *     ID
 * 
 * [column-property]
 *     ID, NAME, VERSION_NO
 * 
 * [foreign-property]
 *     
 * 
 * [refferer-property]
 *     empList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     VersionNo
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class DeptDbm extends AbstractDBMeta {

    // ===================================================================================
    //                                                                          Definition
    //                                                                          ==========
    /** The type of entity. */
    protected static final Class ENTITY_TYPE = Dept.class;

    /** Singleton instance. */
    private static final DeptDbm _instance = new DeptDbm();

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    private DeptDbm() {
    }

    // ===================================================================================
    //                                                                           Singleton
    //                                                                           =========
    /**
     * Get instance.
     * 
     * @return Singleton instance. (NotNull)
     */
    public static DeptDbm getInstance() {
        return _instance;
    }

    // ===================================================================================
    //                                                                     Name Definition
    //                                                                     ===============
    // -----------------------------------------------------
    //                                                 Table
    //                                                 -----
    /** Table db name. */
    public static final String TABLE_DB_NAME = "DEPT";

    /** Table prop name(JavaBeansRule). */
    public static final String TABLE_PROPERTY_NAME = "dept";

    /** Table cap-prop name. */
    public static final String TABLE_CAP_PROP_NAME = "Dept";

    /** Table uncap-prop name. */
    public static final String TABLE_UNCAP_PROP_NAME = "dept";

    // -----------------------------------------------------
    //                                        Column DB-Name
    //                                        --------------
    /** Db-name of ID. PK : INTEGER : NotNull : Default=[] */
    public static final String DB_NAME_ID = "ID";
    /** Db-name of NAME. VARCHAR(20) : Default=[] */
    public static final String DB_NAME_NAME = "NAME";
    /** Db-name of VERSION_NO. INTEGER : Default=[] */
    public static final String DB_NAME_VERSION_NO = "VERSION_NO";


    // -----------------------------------------------------
    //                       Column Prop-Name(JavaBeansRule)
    //                       -------------------------------
    /** Prop-name(JavaBeansRule) of id. PK : INTEGER : NotNull : Default=[] */
    public static final String PROPERTY_NAME_id = "id";
    /** Prop-name(JavaBeansRule) of name. VARCHAR(20) : Default=[] */
    public static final String PROPERTY_NAME_name = "name";
    /** Prop-name(JavaBeansRule) of versionNo. INTEGER : Default=[] */
    public static final String PROPERTY_NAME_versionNo = "versionNo";

    // -----------------------------------------------------
    //                                  Column Cap-Prop-Name
    //                                  --------------------
    /** Cap-prop-name of id. PK : INTEGER : NotNull : Default=[] */
    public static final String CAP_PROP_NAME_Id = "Id";
    /** Cap-prop-name of name. VARCHAR(20) : Default=[] */
    public static final String CAP_PROP_NAME_Name = "Name";
    /** Cap-prop-name of versionNo. INTEGER : Default=[] */
    public static final String CAP_PROP_NAME_VersionNo = "VersionNo";


    // -----------------------------------------------------
    //                                Column Uncap-Prop-Name
    //                                ----------------------
    /** Uncap-prop-name of id. PK : INTEGER : NotNull : Default=[] */
    public static final String UNCAP_PROP_NAME_id = "id";
    /** Uncap-prop-name of name. VARCHAR(20) : Default=[] */
    public static final String UNCAP_PROP_NAME_name = "name";
    /** Uncap-prop-name of versionNo. INTEGER : Default=[] */
    public static final String UNCAP_PROP_NAME_versionNo = "versionNo";


    // -----------------------------------------------------
    //                                          Foreign Name
    //                                          ------------

    // -----------------------------------------------------
    //                                          Referer Name
    //                                          ------------
    /** The referer property name(JavaBeansRule) of empList. */
    public static final String REFERER_PROPERTY_NAME_empList = "empList";

    /** The map of {db-name : prop-name} key-to-lower. */
    private static java.util.Map<String, String> _dbNamePropertyNameKeyToLowerMap;
    protected static java.util.Map<String, String> createDbNamePropertyNameKeyToLowerMap() {
        if (_dbNamePropertyNameKeyToLowerMap != null) {
            return _dbNamePropertyNameKeyToLowerMap;
        }
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_DB_NAME.toLowerCase(), TABLE_PROPERTY_NAME);

        map.put(DB_NAME_ID.toLowerCase(), PROPERTY_NAME_id);
        map.put(DB_NAME_NAME.toLowerCase(), PROPERTY_NAME_name);
        map.put(DB_NAME_VERSION_NO.toLowerCase(), PROPERTY_NAME_versionNo);

        _dbNamePropertyNameKeyToLowerMap = java.util.Collections.unmodifiableMap(map);
        return _dbNamePropertyNameKeyToLowerMap;
    }

    /** The map of {prop-name : db-name} key-to-lower. */
    private static java.util.Map<String, String> _propertyNameDbNameKeyToLowerMap;
    protected static java.util.Map<String, String> createPropertyNameDbNameKeyToLowerMap() {
        if (_propertyNameDbNameKeyToLowerMap != null) {
            return _propertyNameDbNameKeyToLowerMap;
        }
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_PROPERTY_NAME.toLowerCase(), TABLE_DB_NAME);

        map.put(PROPERTY_NAME_id.toLowerCase(), DB_NAME_ID);
        map.put(PROPERTY_NAME_name.toLowerCase(), DB_NAME_NAME);
        map.put(PROPERTY_NAME_versionNo.toLowerCase(), DB_NAME_VERSION_NO);

        _propertyNameDbNameKeyToLowerMap = java.util.Collections.unmodifiableMap(map);
        return _propertyNameDbNameKeyToLowerMap;
    }


    // ===================================================================================
    //                                                                            Name Map
    //                                                                            ========
    /**
     * The implementation.
     * 
     * @return The key-to-lower map of db-name(lower) and property-name. (NotNull)
     */
    public java.util.Map<String, String> getDbNamePropertyNameKeyToLowerMap() {
        return createDbNamePropertyNameKeyToLowerMap();
    }

    /**
     * The implementation.
     * 
     * @return The key-to-lower map of property-name(lower) and db-name. (NotNull)
     */
    public java.util.Map<String, String> getPropertyNameDbNameKeyToLowerMap() {
        return createPropertyNameDbNameKeyToLowerMap();
    }


    // ===================================================================================
    //                                                                          Table Name
    //                                                                          ==========
    /**
     * The implementation.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return TABLE_DB_NAME;
    }

    /**
     * The implementation.
     * 
     * @return Table property-name(JavaBeansRule). (NotNull)
     */
    public String getTablePropertyName() {
        return TABLE_PROPERTY_NAME;
    }

    /**
     * The implementation.
     * 
     * @return Table cap-prop-name. (NotNull)
     */
    public String getTableCapPropName() {
        return TABLE_CAP_PROP_NAME;
    }

    /**
     * The implementation.
     * 
     * @return Table property-name. (NotNull)
     */
    public String getTableUncapPropName() {
        return TABLE_UNCAP_PROP_NAME;
    }

    // ===================================================================================
    //                                                                           Type Name
    //                                                                           =========
    /**
     * The implementation.
     * 
     * @return The type-name of entity. (NotNull)
     */ 
    public String getEntityTypeName() {
        return "sample.dbflute.exentity.Dept";
    }

    /**
     * The implementation.
     * 
     * @return The type-name of condition-bean. (NotNull)
     */ 
    public String getConditionBeanTypeName() {
        return "sample.dbflute.cbean.bs.DeptCB";
    }

    /**
     * The implementation.
     * 
     * @return The type-name of dao. (NotNull)
     */ 
    public String getDaoTypeName() {
        return "sample.dbflute.exdao.DeptDao";
    }

    /**
     * The implementation.
     * 
     * @return The type-name of behavior. (NotNull)
     */ 
    public String getBehaviorTypeName() {
        return "sample.dbflute.exbhv.DeptBhv";
    }

    // ===================================================================================
    //                                                                         Object Type
    //                                                                         ===========
    /**
     * The implementation.
     * 
     * @return The type of entity. (NotNull)
     */ 
    public Class getEntityType() {
        return ENTITY_TYPE;
    }

    // ===================================================================================
    //                                                                     Object Instance
    //                                                                     ===============
    /**
     * The implementation.
     * 
     * @return The type of entity. (NotNull)
     */ 
    public Entity newEntity() {
        return newMyEntity();
    }

    /**
     * New the instance of my entity.
     * 
     * @return The instance of my entity. (NotNull)
     */ 
    public Dept newMyEntity() {
        return new Dept();
    }


    // ===================================================================================
    //                                                                         Column Info
    //                                                                         ===========
    /**
     * The implementation.
     * 
     * @return The list of column db-name. (NotNull and NotEmpty)
     */
    public java.util.List<ColumnInfo> getColumnInfoList() {
        final java.util.List<ColumnInfo> columnInfoList = new java.util.ArrayList<ColumnInfo>();
        columnInfoList.add(columnId());
        columnInfoList.add(columnName());
        columnInfoList.add(columnVersionNo());
        return columnInfoList;
    }


    /**
     * @return Column information of id. (NotNull)
     */
    public ColumnInfo columnId() {
        return new ColumnInfo(this, "ID", "id", java.lang.Integer.class, true, null);
    }
    /**
     * @return Column information of name. (NotNull)
     */
    public ColumnInfo columnName() {
        return new ColumnInfo(this, "NAME", "name", String.class, false, Integer.valueOf("20"));
    }
    /**
     * @return Column information of versionNo. (NotNull)
     */
    public ColumnInfo columnVersionNo() {
        return new ColumnInfo(this, "VERSION_NO", "versionNo", java.lang.Integer.class, false, null);
    }

    // ===================================================================================
    //                                                                         Unique Info
    //                                                                         ===========
    // -----------------------------------------------------
    //                                       Primary Element
    //                                       ---------------
    /**
     * The implementation.
     * 
     * @return The primary unique info. (NotNull)
     */
    public UniqueInfo getPrimaryUniqueInfo() {
        final UniqueInfo uniqueInfo = new UniqueInfo();
        uniqueInfo.setDBMeta(this);
        uniqueInfo.addUniqueColumnList(new ColumnInfo(this, "ID", "id", java.lang.Integer.class, true, null));
        uniqueInfo.setPrimary(true);
        return uniqueInfo;
    }

    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasPrimaryKey() {
        return true;
    }

    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasTwoOrMorePrimaryKeys() {
        return false;
    }

    // ===================================================================================
    //                                                                       Relation Info
    //                                                                       =============
    // -----------------------------------------------------
    //                                       Foreign Element
    //                                       ---------------


    // -----------------------------------------------------
    //                                       Referer Element
    //                                       ---------------
    /**
     * Get referer information of empList.
     * 
     * @return Referer information. (NotNull)
     */
    public sample.dbflute.allcommon.dbmeta.info.RefererInfo refererEmpList() {
        final sample.dbflute.allcommon.dbmeta.info.RefererInfo refererInfo = new sample.dbflute.allcommon.dbmeta.info.RefererInfo();
        refererInfo.setRefererPropertyName("empList");
        refererInfo.setLocalDBMeta(DeptDbm.getInstance());
        refererInfo.setRefererDBMeta(EmpDbm.getInstance());
        final java.util.Map<ColumnInfo, ColumnInfo> map = new java.util.LinkedHashMap<ColumnInfo, ColumnInfo>();
        map.put(columnId(), EmpDbm.getInstance().columnDeptId());
        refererInfo.setLocalRefererColumnInfoMap(map);
        refererInfo.setOneToOne(false);
        return refererInfo;
    }

    // -----------------------------------------------------
    //                                        Relation Trace
    //                                        --------------
    /**
     * Create relation trace for first step.
     * 
     * @param relationTraceFixHandler The handler of fixed relation trace. (Nullable)
     * @return Relation trace. (NotNull)
     */
    public DeptRelationTrace createRelationTrace(RelationTraceFixHandler relationTraceFixHandler) {
        return new DeptRelationTrace(relationTraceFixHandler);
    }

    /**
     * Create relation trace for relation step.
     * 
     * @param relationList The list of relation. (NotNull)
     * @param relationTraceList The list of relation trace. (NotNull)
     * @return Relation trace. (NotNull)
     */
    public DeptRelationTrace createRelationTrace(java.util.List<RelationInfo> relationList, java.util.List<AbstractRelationTrace> relationTraceList) {
        return new DeptRelationTrace(relationList, relationTraceList);
    }

    /**
     * Relation trace of DEPT.
     */
    public static class DeptRelationTrace extends AbstractRelationTrace {

        /**
         * Constructor for first step.
         * 
         * @param relationTraceFixHandler The handler of fixed relation trace. (Nullable)
         */
        public DeptRelationTrace(RelationTraceFixHandler relationTraceFixHandler) {
            super(relationTraceFixHandler);
        }

        /**
         * Constructor for relation step.
         * 
         * @param relationList The list of relation. (NotNull)
         * @param relationTraceList The list of relation trace. (NotNull)
         */
        public DeptRelationTrace(java.util.List<RelationInfo> relationList, java.util.List<AbstractRelationTrace> relationTraceList) {
            super(relationList, relationTraceList);
        }
  
        public EmpDbm.EmpRelationTrace refererEmpList() {
            _relationList.add(DeptDbm.getInstance().refererEmpList());
            return EmpDbm.getInstance().createRelationTrace(_relationList, _relationTraceList);
        }

        public RelationTrace columnId() { return fixTrace(_relationList, DeptDbm.getInstance().columnId()); }
        public RelationTrace columnName() { return fixTrace(_relationList, DeptDbm.getInstance().columnName()); }
        public RelationTrace columnVersionNo() { return fixTrace(_relationList, DeptDbm.getInstance().columnVersionNo()); }
    }

    // ===================================================================================
    //                                                                       Sequence Info
    //                                                                       =============
    /**
     * Has sequence?
     * 
     * @return Determination.
     */
    public boolean hasSequence() {
        return false;
    }

    // ===================================================================================
    //                                                                Optimistic Lock Info
    //                                                                ====================
    /**
     * Has version no?
     * 
     * @return Determination.
     */
    public boolean hasVersionNo() {
        return true;
    }

    /**
     * Has update date?
     * 
     * @return Determination.
     */
    public boolean hasUpdateDate() {
        return false;
    }

    // ===================================================================================
    //                                                                       Common Column
    //                                                                       =============
    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasCommonColumn() {
        return false;
    }

    // ===================================================================================
    //                                                                     Entity Handling
    //                                                                     ===============
    // -----------------------------------------------------
    //                                                Accept
    //                                                ------
    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @param primaryKeyMap Primary key map. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMap(Entity entity, java.util.Map<String, ? extends Object> primaryKeyMap) {
        final Dept myEntity = (Dept)entity;
        MapAssertUtil.assertPrimaryKeyMapNotNullAndNotEmpty(primaryKeyMap);
        final MapStringValueAnalyzer analyzer = new MapStringValueAnalyzer(primaryKeyMap, entity.getModifiedPropertyNames());

        MapAssertUtil.assertColumnExistingInPrimaryKeyMap(primaryKeyMap, "ID");
        if (analyzer.init("ID", "id", "id")) { myEntity.setId(analyzer.analyzeNumber(java.lang.Integer.class)); };


    }

    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @param primaryKeyMapString Primary-key map-string. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMapString(Entity entity, String primaryKeyMapString) {
        MapStringUtil.acceptPrimaryKeyMapString(primaryKeyMapString, entity);
    }

    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @param columnValueMap Column-value map. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMap(Entity entity, java.util.Map<String, ? extends Object> columnValueMap) {
        final Dept myEntity = (Dept)entity;
        MapAssertUtil.assertColumnValueMapNotNullAndNotEmpty(columnValueMap);
        final MapStringValueAnalyzer analyzer = new MapStringValueAnalyzer(columnValueMap, entity.getModifiedPropertyNames());

        if (analyzer.init("ID", "id", "id")) { myEntity.setId(analyzer.analyzeNumber(java.lang.Integer.class)); };
        if (analyzer.init("NAME", "name", "name")) { myEntity.setName(analyzer.analyzeString(String.class)); };
        if (analyzer.init("VERSION_NO", "versionNo", "versionNo")) { myEntity.setVersionNo(analyzer.analyzeNumber(java.lang.Integer.class)); };

    }


    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @param columnValueMapString Column-value map-string. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMapString(Entity entity, String columnValueMapString) {
        MapStringUtil.acceptColumnValueMapString(columnValueMapString, entity);
    }


    // -----------------------------------------------------
    //                                               Extract
    //                                               -------
    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString(Entity entity) {
        return MapStringUtil.extractPrimaryKeyMapString(entity);
    }

    /**
     * Extract primary-key map-string.
     * 
     * @param entity Target entity. (NotNull)
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString(Entity entity, String startBrace, String endBrace, String delimiter, String equal) {
        final Dept myEntity = (Dept)entity;
        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();
        helpAppendingColumnValueString(sb, delimiter, equal, "ID", myEntity.getId());

        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();
    }

    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString(Entity entity) {
        return MapStringUtil.extractColumnValueMapString(entity);
    }

    /**
     * Extract column-value map-string.
     * 
     * @param entity Target entity. (NotNull)
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString(Entity entity, String startBrace, String endBrace, String delimiter, String equal) {
        final Dept myEntity = (Dept)entity;
        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();
        helpAppendingColumnValueString(sb, delimiter, equal, "ID", myEntity.getId());
        helpAppendingColumnValueString(sb, delimiter, equal, "NAME", myEntity.getName());
        helpAppendingColumnValueString(sb, delimiter, equal, "VERSION_NO", myEntity.getVersionNo());

        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();
    }

    private void helpAppendingColumnValueString(StringBuffer sb, String delimiter, String equal, String colName, Object value) {
        sb.append(delimiter).append(colName).append(equal);
        sb.append(helpGettingColumnStringValue(value));
    }


    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractCommonColumnValueMapString(Entity entity) {
        return "map:{}";
    }

    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractCommonColumnValueMapString(Entity entity, String startBrace, String endBrace, String delimiter, String equal) {
        return "map:" + startBrace + endBrace;
    }


    // -----------------------------------------------------
    //                                               Convert
    //                                               -------
    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return The list of column value. (NotNull)
     */
    public java.util.List<Object> convertToColumnValueList(Entity entity) {
        return new java.util.ArrayList<Object>(convertToColumnValueMap(entity).values());
    }

    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return The map of column value. (NotNull)
     */
    public java.util.Map<String, Object> convertToColumnValueMap(Entity entity) {
        final Dept myEntity = downcast(entity);
        final java.util.Map<String, Object> valueMap = new java.util.LinkedHashMap<String, Object>();
        valueMap.put("ID", myEntity.getId());
        valueMap.put("NAME", myEntity.getName());
        valueMap.put("VERSION_NO", myEntity.getVersionNo());
        return valueMap;
    }

    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return The list of column string-value. (NotNull)
     */
    public java.util.List<String> convertToColumnStringValueList(Entity entity) {
        return new java.util.ArrayList<String>(convertToColumnStringValueMap(entity).values());
    }

    /**
     * The implementation.
     * 
     * @param entity Target entity. (NotNull)
     * @return The map of column string-value. (NotNull)
     */
    public java.util.Map<String, String> convertToColumnStringValueMap(Entity entity) {
        final Dept myEntity = downcast(entity);
        final java.util.Map<String, String> valueMap = new java.util.LinkedHashMap<String, String>();
        valueMap.put("ID", helpGettingColumnStringValue(myEntity.getId()));
        valueMap.put("NAME", helpGettingColumnStringValue(myEntity.getName()));
        valueMap.put("VERSION_NO", helpGettingColumnStringValue(myEntity.getVersionNo()));
        return valueMap;
    }

    // ===================================================================================
    //                                                                        JDBC Support
    //                                                                        ============
    /**
     * The implementation.
     * 
     * @return Prepared insert clause. (NotNull and NotEmpty)
     */
    public String getPreparedInsertClause() {
        return getPreparedInsertClause(new PreparedInsertClauseOption());
    }

    /**
     * The implementation.
     * 
     * @param preparedInsertClauseOption Prepared insert clause option. (NotNull)
     * @return Prepared insert clause. (NotNull and NotEmpty)
     */
    public String getPreparedInsertClause(PreparedInsertClauseOption preparedInsertClauseOption) {
        if (preparedInsertClauseOption.getTablePrefix() != null) {
            final String tablePrefix = preparedInsertClauseOption.getTablePrefix();
            return "insert into " + tablePrefix + "DEPT(ID, NAME, VERSION_NO) values(? , ? , ? )";
        }
        return "insert into DEPT(ID, NAME, VERSION_NO) values(? , ? , ? )";
    }

    // ===================================================================================
    //                                                                              Helper
    //                                                                              ======
    protected Dept downcast(Entity entity) {
        assertObjectNotNull("entity", entity);
        try {
            return (Dept)entity;
        } catch (ClassCastException e) {
            String msg = "The entity should be Dept but it was: " + entity.getClass();
            throw new RuntimeException(msg, e);
        }
    }

    protected void checkDowncast(Entity entity) {
        downcast(entity);
    }
}
