package sample.dbflute.allcommon.s2dao;

/**
 * BeanMetaDataFactoryImpl for DBFlute.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class S2BeanMetaDataFactoryImpl extends org.seasar.dao.impl.BeanMetaDataFactoryImpl {

    /**
     * Get the limit nest level of relation.
     * 
     * @return The limit nest level of relation.
     */
    protected int getLimitRelationNestLevel() {
        return 2;// Extension for DBFlute
    }
}