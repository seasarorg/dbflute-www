package sample.dbflute.allcommon.cbean;

import sample.dbflute.allcommon.cbean.mapping.EntityDtoMapper;
import sample.dbflute.allcommon.cbean.grouping.GroupingOption;
import sample.dbflute.allcommon.cbean.grouping.GroupingRowEndDeterminer;
import sample.dbflute.allcommon.cbean.grouping.GroupingRowResource;
import sample.dbflute.allcommon.cbean.grouping.GroupingRowSetupper;
import sample.dbflute.allcommon.cbean.sqlclause.OrderByClause;

/**
 * The list-result-bean for ListResultBean.
 * 
 * @param <ENTITY> The type of entity for the element of selectedList()
 * @author DBFlute(AutoGenerator)
 */
public class ListResultBean<ENTITY> implements java.util.List<ENTITY>, java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    /** The value of table db-name. */
    protected String _tableDbName;

    /** The value of all record count. */
    protected int _allRecordCount;

    /** Selected list. */
    protected java.util.List<ENTITY> _selectedList = new java.util.ArrayList<ENTITY>();

    /** Order-by clause. */
    protected OrderByClause _orderByClause = new OrderByClause();

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public ListResultBean() {
    }

    // =====================================================================================
    //                                                                         Getter Setter
    //                                                                         =============
    /**
     * Get the value of tableDbName.
     * 
     * @return The value of tableDbName.
     */
    public String getTableDbName() {
        return _tableDbName;
    }

    /**
     * Set the value of tableDbName.
     * 
     * @param tableDbName The value of tableDbName.
     */
    public void setTableDbName(String tableDbName) {
        _tableDbName = tableDbName;
    }

    /**
     * Get the value of allRecordCount.
     * 
     * @return The value of allRecordCount.
     */
    public int getAllRecordCount() {
        return _allRecordCount;
    }

    /**
     * Set the value of allRecordCount.
     * 
     * @param allRecordCount The value of allRecordCount.
     */
    public void setAllRecordCount(int allRecordCount) {
        _allRecordCount = allRecordCount;
    }

    /**
     * Get the value of selectedList.
     * 
     * @return Selected list. (NotNull)
     */
    public java.util.List<ENTITY> getSelectedList() {
        return _selectedList;
    }

    /**
     * Set the value of selectedList.
     * 
     * @param selectedList Selected list. (NotNull)
     */
    public void setSelectedList(java.util.List<ENTITY> selectedList) {
        _selectedList = selectedList;
    }

    /**
     * Get the value of orderByClause.
     * 
     * @return The value of orderByClause. (NotNull)
     */
    public OrderByClause getOrderByClause() {
        return _orderByClause;
    }

    /**
     * Set the value of orderByClause.
     * 
     * @param orderByClause The value of orderByClause. (NotNull)
     */
    public void setOrderByClause(OrderByClause orderByClause) {
        _orderByClause = orderByClause;
    }

    // =====================================================================================
    //                                                                              Grouping
    //                                                                              ========
    public <ROW> java.util.List<ROW> groupingList(GroupingRowSetupper<ROW, ENTITY> groupingRowSetupper, GroupingOption<ENTITY> groupingOption) {
        final java.util.List<ROW> groupingList = new java.util.ArrayList<ROW>();
        GroupingRowEndDeterminer<ENTITY> rowEndDeterminer = groupingOption.getGroupingRowEndDeterminer();
        if (rowEndDeterminer == null) {
            rowEndDeterminer = new GroupingRowEndDeterminer<ENTITY>() {
                public boolean determine(int columnIndex, int columnCount, GroupingRowResource<ENTITY> rowResource, ENTITY nextEntity) {
                    return columnIndex == (columnCount-1);
                }
            };// as Default
        }
        GroupingRowResource<ENTITY> rowResource = new GroupingRowResource<ENTITY>();
        int columnCount = groupingOption.getColumnCount();
        int columnIndex = 0;
        int rowIndex = 0;
        for (ENTITY entity : _selectedList) {
            // Set up row resource.
            rowResource.addGroupingRowList(entity);

            if (_selectedList.size() == (rowIndex + 1)) {// Last Loop!
                // Callback!
                final ROW groupingRowObject = groupingRowSetupper.setup(rowResource);

                // Register!
                groupingList.add(groupingRowObject);
                break;
            }

            ENTITY nextElement = null;
            if (_selectedList.size() > (rowIndex + 1)) {;
                nextElement = _selectedList.get(rowIndex);
            }

            // Do at row end.
            if (rowEndDeterminer.determine(columnIndex, columnCount, rowResource, nextElement)) {
                // Callback!
                final ROW groupingRowObject = groupingRowSetupper.setup(rowResource);

                // Register!
                groupingList.add(groupingRowObject);

                // Initialize!
                rowResource = new GroupingRowResource<ENTITY>();
                columnIndex = 0;
                ++rowIndex;
                continue;
            }
            ++columnIndex;
            ++rowIndex;
        }
        return groupingList;
    }

    // =====================================================================================
    //                                                                               Mapping
    //                                                                               =======
    public <DTO> ListResultBean<DTO> mappingList(EntityDtoMapper<ENTITY, DTO> entityDtoMapper) {
        final ListResultBean<DTO> mappingList = new ListResultBean<DTO>();
        for (ENTITY entity : _selectedList) {
            mappingList.add(entityDtoMapper.map(entity));
        }
        mappingList.setTableDbName(getTableDbName());
        mappingList.setAllRecordCount(getAllRecordCount());
        mappingList.setOrderByClause(getOrderByClause());
        return mappingList;
    }

    // =====================================================================================
    //                                                                         Determination
    //                                                                         =============
    /**
     * Has this result selected?
     * <pre>
     * If isSetterInvokedSelectedList is true, returns true.
     * </pre>
     * 
     * @return Determination.
     */
    public boolean isSelectedResult() {
        return _tableDbName != null;
    }

    // =====================================================================================
    //                                                                        Basic Override
    //                                                                        ==============
    /**
     * The override.
     * 
     * @return Hash-code from primary-keys.
     */
    public int hashCode() {
        if (_selectedList == null) {
            return super.hashCode();
        }
        return _selectedList.hashCode();
    }

    /**
     * The override.
     * 
     * @param other Other entity. (Nullable)
     * @return Comparing result. If other is null, returns false.
     */
    public boolean equals(Object other) {
        if (_selectedList == null) {
            return false;
        }
        if (other == null) {
            return false;
        }
        if (!(other instanceof java.util.List)) {
            return false;
        }
        return _selectedList.equals(other);
    }

    /**
     * The override.
     * 
     * @return View-string of all-columns value.
     */
    public String toString() {
        final StringBuffer sb = new StringBuffer();

        sb.append(" tableDbName=").append(_tableDbName);
        sb.append(" allRecordCount=").append(_allRecordCount);
        sb.append(" selectedList.size()=").append(_selectedList.size());
        sb.append(" orderByClause=").append(_orderByClause);

        return sb.toString();
    }

    // =====================================================================================
    //                                                                         List Elements
    //                                                                         =============
    public boolean add(ENTITY o) {
        return _selectedList.add(o);
    }

    public boolean addAll(java.util.Collection<? extends ENTITY> c) {
        return _selectedList.addAll(c);
    }

    public void clear() {
        _selectedList.clear();
    }

    public boolean contains(Object o) {
        return _selectedList.contains(o);
    }

    public boolean containsAll(java.util.Collection<?> c) {
        return _selectedList.containsAll(c);
    }

    public boolean isEmpty() {
        return _selectedList.isEmpty();
    }

    public java.util.Iterator<ENTITY> iterator() {
        return _selectedList.iterator();
    }

    public boolean remove(Object o) {
        return _selectedList.remove(o);
    }

    public boolean removeAll(java.util.Collection<?> c) {
        return _selectedList.removeAll(c);
    }

    public boolean retainAll(java.util.Collection<?> c) {
        return _selectedList.retainAll(c);
    }

    public int size() {
        return _selectedList.size();
    }

    public Object[] toArray() {
        return _selectedList.toArray();
    }

    public <TYPE> TYPE[] toArray(TYPE[] a) {
        return _selectedList.toArray(a);
    }

    public void add(int index, ENTITY element) {
        _selectedList.add(index, element);
    }

    public boolean addAll(int index, java.util.Collection<? extends ENTITY> c) {
        return _selectedList.addAll(index, c);
    }

    public ENTITY get(int index) {
        return _selectedList.get(index);
    }

    public int indexOf(Object o) {
        return _selectedList.indexOf(o);
    }

    public int lastIndexOf(Object o) {
        return _selectedList.lastIndexOf(o);
    }

    public java.util.ListIterator<ENTITY> listIterator() {
        return _selectedList.listIterator();
    }

    public java.util.ListIterator<ENTITY> listIterator(int index) {
        return _selectedList.listIterator(index);
    }

    public ENTITY remove(int index) {
        return _selectedList.remove(index);
    }

    public ENTITY set(int index, ENTITY element) {
        return _selectedList.set(index, element);
    }

    public java.util.List<ENTITY> subList(int fromIndex, int toIndex) {
        return _selectedList.subList(fromIndex, toIndex);
    }

}
