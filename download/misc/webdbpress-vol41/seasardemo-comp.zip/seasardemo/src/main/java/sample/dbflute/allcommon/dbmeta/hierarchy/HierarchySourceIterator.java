package sample.dbflute.allcommon.dbmeta.hierarchy;


/**
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface HierarchySourceIterator {

    public boolean hasNext();

    public HierarchySourceRow next();

    public HierarchySourceRow current();
}