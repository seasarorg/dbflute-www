package sample.dbflute.allcommon.bhv.load;

import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.bhv.setup.ConditionBeanSetupper;
import sample.dbflute.allcommon.bhv.setup.EntityListSetupper;
import sample.dbflute.allcommon.cbean.ConditionBean;

/**
 * The class of load referer option.
 * 
 * @param <REFERER_CONDITION_BEAN> The type of referer condition-bean.
 * @param <REFERER_ENTITY> The type of referer entity.
 * @author DBFlute(AutoGenerator)
 */
public class LoadRefererOption<REFERER_CONDITION_BEAN extends ConditionBean, REFERER_ENTITY extends Entity> {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    protected ConditionBeanSetupper<REFERER_CONDITION_BEAN> _conditionBeanSetupper;

    protected EntityListSetupper<REFERER_ENTITY> _entityListSetupper;

    protected REFERER_CONDITION_BEAN _refererConditionBean;

    protected boolean _toLastKeyCondtion;

    protected boolean _stopOrderByKey;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    public LoadRefererOption() {
    }

    public LoadRefererOption(ConditionBeanSetupper<REFERER_CONDITION_BEAN> conditionBeanSetupper) {
        this._conditionBeanSetupper = conditionBeanSetupper;
    }

    public LoadRefererOption(ConditionBeanSetupper<REFERER_CONDITION_BEAN> conditionBeanSetupper, EntityListSetupper<REFERER_ENTITY> entityListSetupper) {
        this._conditionBeanSetupper = conditionBeanSetupper;
        this._entityListSetupper = entityListSetupper;
    }

    // ===================================================================================
    //                                                                         Easy-to-Use
    //                                                                         ===========
    /**
     * Specify that the key condition is added as last condition. <br />
     * This method is valid only after you use reffererConditionBean and add your original condition to it. <br />
     * 
     * @return this. (NotNull)
     */
    public LoadRefererOption<REFERER_CONDITION_BEAN, REFERER_ENTITY> toLastKeyCondtion() {
        _toLastKeyCondtion = true;
        return this;
    }

    /**
     * Specify that it stops adding order-by of the key. <br />
     * This method is valid only after you use reffererConditionBean and add your original order-by to it. <br />
     * 
     * @return this. (NotNull)
     */
    public LoadRefererOption<REFERER_CONDITION_BEAN, REFERER_ENTITY> stopOrderByKey() {
        _stopOrderByKey = true;
        return this;
    }

    public void delegateKeyConditionExchangingFirstWhereClauseForLastOne(REFERER_CONDITION_BEAN cb) {// Internal
        if (!_toLastKeyCondtion) {
            cb.getSqlClause().exchangeFirstWhereClauseForLastOne();
        }
    }

    public void delegateConditionBeanSettingUp(REFERER_CONDITION_BEAN cb) {// Internal
        if (_conditionBeanSetupper != null) {
            _conditionBeanSetupper.setup(cb);
        }
    }

    public void delegateEntitySettingUp(java.util.List<REFERER_ENTITY> entityList) {// Internal
        if (_entityListSetupper != null) {
            _entityListSetupper.setup(entityList);
        }
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    public ConditionBeanSetupper<REFERER_CONDITION_BEAN> getConditionBeanSetupper() {
        return _conditionBeanSetupper;
    }

    public void setConditionBeanSetupper(ConditionBeanSetupper<REFERER_CONDITION_BEAN> conditionBeanSetupper) {
        this._conditionBeanSetupper = conditionBeanSetupper;
    }

    public EntityListSetupper<REFERER_ENTITY> getEntityListSetupper() {
        return _entityListSetupper;
    }

    public void setEntityListSetupper(EntityListSetupper<REFERER_ENTITY> entityListSetupper) {
        this._entityListSetupper = entityListSetupper;
    }

    /**
     * @return The condition-bean of referer.
     * @deprecated Sorry! This methid have typo! Please use getRefererConditionBean().
     */
    public REFERER_CONDITION_BEAN getReffererConditionBean() {
        return _refererConditionBean;
    }

    /**
     * @param refererConditionBean The condition-bean of referer.
     * @deprecated Sorry! This methid have typo! Please use setRefererConditionBean().
     */
    public void setReffererConditionBean(REFERER_CONDITION_BEAN refererConditionBean) {
        this._refererConditionBean = refererConditionBean;
    }

    public REFERER_CONDITION_BEAN getRefererConditionBean() {
        return _refererConditionBean;
    }

    public void setRefererConditionBean(REFERER_CONDITION_BEAN refererConditionBean) {
        this._refererConditionBean = refererConditionBean;
    }

    public boolean isToLastKeyCondtion() {
        return _toLastKeyCondtion;
    }

    public boolean isStopOrderByKey() {
        return _stopOrderByKey;
    }
}
