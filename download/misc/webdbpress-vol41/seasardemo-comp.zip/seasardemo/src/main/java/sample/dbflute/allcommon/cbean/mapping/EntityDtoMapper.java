package sample.dbflute.allcommon.cbean.mapping;

/**
 * The interface of entity converter.
 * 
 * @param <ENTITY> The type of entity.
 * @param <DTO> The type of dto.
 * @author DBFlute(AutoGenerator)
 */
public interface EntityDtoMapper<ENTITY, DTO> {

    /**
     * Map entity to data transfer object.
     * 
     * @param entity Entity. (NotNull)
     * @return Data transfer object. (NotNull)
     */
    public DTO map(ENTITY entity);
}
