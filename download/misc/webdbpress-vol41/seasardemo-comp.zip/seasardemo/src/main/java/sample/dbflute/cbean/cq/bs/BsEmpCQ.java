package sample.dbflute.cbean.cq.bs;


import sample.dbflute.allcommon.cbean.*;
import sample.dbflute.allcommon.cbean.cvalue.ConditionValue;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;
import sample.dbflute.cbean.cq.ciq.*;

/**
 * The condition-query of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class BsEmpCQ extends AbstractBsEmpCQ {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Corresponding inline query. */
    protected EmpCIQ _inlineQuery;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public BsEmpCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // ===================================================================================
    //                                                                              Inline
    //                                                                              ======
    /**
     * Get inline query.
     * 
     * @return Inline query. (NotNull)
     */
    public EmpCIQ inline() {
        if (_inlineQuery == null) {
            _inlineQuery = new EmpCIQ(getChildQuery(), getSqlClause(), getAliasName(), getNestLevel(), this);
        }
        return _inlineQuery;
    }

    // ===================================================================================
    //                                                                     Include-as-Mine
    //                                                                     ===============
  
    /**
     * Include select-column of id as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Id() {
        registerIncludedSelectColumn("Id", getRealColumnName("ID"));
    }

    /**
     * Include select-column of id as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Id(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("ID"));
    }
  
    /**
     * Include select-column of name as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Name() {
        registerIncludedSelectColumn("Name", getRealColumnName("NAME"));
    }

    /**
     * Include select-column of name as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Name(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("NAME"));
    }
  
    /**
     * Include select-column of hireDate as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_HireDate() {
        registerIncludedSelectColumn("HireDate", getRealColumnName("HIRE_DATE"));
    }

    /**
     * Include select-column of hireDate as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_HireDate(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("HIRE_DATE"));
    }
  
    /**
     * Include select-column of deptId as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_DeptId() {
        registerIncludedSelectColumn("DeptId", getRealColumnName("DEPT_ID"));
    }

    /**
     * Include select-column of deptId as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_DeptId(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("DEPT_ID"));
    }
  
    /**
     * Include select-column of versionNo as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_VersionNo() {
        registerIncludedSelectColumn("VersionNo", getRealColumnName("VERSION_NO"));
    }

    /**
     * Include select-column of versionNo as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_VersionNo(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("VERSION_NO"));
    }
  
    // ===================================================================================
    //                                                                               Query
    //                                                                               =====
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [EMP]
    // * * * * * * * * */
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [ID]
    // - - - - - - - - -/

    /** The attribute of id. */
    protected ConditionValue _id;

    /**
     * Get the value of id.
     * 
     * @return The value of id.
     */
    public ConditionValue getId() {
        if (_id == null) {
            _id = new ConditionValue();
        }
        return _id;
    }

    protected ConditionValue getCValueId() {
        return getId();
    }

                                              
    /**
     * Add order-by of id as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_Id_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("ID"), null, true);return this;
    }

    /**
     * Add order-by of id as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_Id_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("ID"), null, false);return this;
    }
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [NAME]
    // - - - - - - - - -/

    /** The attribute of name. */
    protected ConditionValue _name;

    /**
     * Get the value of name.
     * 
     * @return The value of name.
     */
    public ConditionValue getName() {
        if (_name == null) {
            _name = new ConditionValue();
        }
        return _name;
    }

    protected ConditionValue getCValueName() {
        return getName();
    }

                                                  
    /**
     * Add order-by of name as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_Name_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("NAME"), null, true);return this;
    }

    /**
     * Add order-by of name as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_Name_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("NAME"), null, false);return this;
    }
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [HIRE_DATE]
    // - - - - - - - - -/

    /** The attribute of hireDate. */
    protected ConditionValue _hireDate;

    /**
     * Get the value of hireDate.
     * 
     * @return The value of hireDate.
     */
    public ConditionValue getHireDate() {
        if (_hireDate == null) {
            _hireDate = new ConditionValue();
        }
        return _hireDate;
    }

    protected ConditionValue getCValueHireDate() {
        return getHireDate();
    }

                                
    /**
     * Add order-by of hireDate as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_HireDate_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("HIRE_DATE"), null, true);return this;
    }

    /**
     * Add order-by of hireDate as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_HireDate_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("HIRE_DATE"), null, false);return this;
    }
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [DEPT_ID]
    // - - - - - - - - -/

    /** The attribute of deptId. */
    protected ConditionValue _deptId;

    /**
     * Get the value of deptId.
     * 
     * @return The value of deptId.
     */
    public ConditionValue getDeptId() {
        if (_deptId == null) {
            _deptId = new ConditionValue();
        }
        return _deptId;
    }

    protected ConditionValue getCValueDeptId() {
        return getDeptId();
    }

              
    /** The sub-query of DeptId_InScopeSubQuery_Dept using inScopeSubQuery. */
    protected java.util.Map<String, sample.dbflute.cbean.cq.DeptCQ> _deptId_InScopeSubQuery_DeptMap;

    /**
     * Get the sub-query of DeptId_InScopeSubQuery_Dept using inScopeSubQuery.
     * 
     * @return The sub-query of DeptId_InScopeSubQuery_Dept using inScopeSubQuery. (Nullable)
     */
    public java.util.Map<String, sample.dbflute.cbean.cq.DeptCQ> getDeptId_InScopeSubQuery_Dept() {
        return _deptId_InScopeSubQuery_DeptMap;
    }

    public String keepDeptId_InScopeSubQuery_Dept(sample.dbflute.cbean.cq.DeptCQ subQuery) {
        if (_deptId_InScopeSubQuery_DeptMap == null) { _deptId_InScopeSubQuery_DeptMap = new java.util.LinkedHashMap<String, sample.dbflute.cbean.cq.DeptCQ>(); }
        final String key = "subQueryMapKey" + (_deptId_InScopeSubQuery_DeptMap.size() + 1);
        _deptId_InScopeSubQuery_DeptMap.put(key, subQuery);
        return "deptId_InScopeSubQuery_Dept." + key;
    }
                                          
    /**
     * Add order-by of deptId as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_DeptId_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("DEPT_ID"), null, true);return this;
    }

    /**
     * Add order-by of deptId as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_DeptId_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("DEPT_ID"), null, false);return this;
    }
  
    // /- - - - - - - - - - - - - - - - - - - - - - -
    //   Column = [VERSION_NO]
    // - - - - - - - - -/

    /** The attribute of versionNo. */
    protected ConditionValue _versionNo;

    /**
     * Get the value of versionNo.
     * 
     * @return The value of versionNo.
     */
    public ConditionValue getVersionNo() {
        if (_versionNo == null) {
            _versionNo = new ConditionValue();
        }
        return _versionNo;
    }

    protected ConditionValue getCValueVersionNo() {
        return getVersionNo();
    }

                                                  
    /**
     * Add order-by of versionNo as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_VersionNo_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName("VERSION_NO"), null, true);return this;
    }

    /**
     * Add order-by of versionNo as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmpCQ addOrderBy_VersionNo_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName("VERSION_NO"), null, false);return this;
    }
  
    // ===================================================================================
    //                                                                         Union Query
    //                                                                         ===========
    protected void reflectRelationOnUnionQuery(ConditionQuery baseQueryAsSuper, ConditionQuery unionQueryAsSuper) {
        final sample.dbflute.cbean.cq.EmpCQ baseQuery = (sample.dbflute.cbean.cq.EmpCQ)baseQueryAsSuper;
        final sample.dbflute.cbean.cq.EmpCQ unionQuery = (sample.dbflute.cbean.cq.EmpCQ)unionQueryAsSuper;
        if (baseQuery.hasConditionQueryDept()) {
            unionQuery.queryDept().reflectRelationOnUnionQuery(baseQuery.queryDept(), unionQuery.queryDept());
        }

    }

    // ===================================================================================
    //                                                                       Foreign Query
    //                                                                       =============
    
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [DEPT(TABLE)]
    //   ForeignProperty = [dept]
    // * * * * * * * * */

    /**
     * Query for dept.
     * 
     * @return Instance of sample.dbflute.cbean.cq.DeptCQ as dept. (NotNull)
     */
    public sample.dbflute.cbean.cq.DeptCQ queryDept() {
        return getConditionQueryDept();
    }

    /** Condition-query for dept. */
    protected sample.dbflute.cbean.cq.DeptCQ _conditionQueryDept;

    /**
     * Get condition-query for dept.
     * 
     * @return Instance of sample.dbflute.cbean.cq.DeptCQ as dept. (NotNull)
     */
    public sample.dbflute.cbean.cq.DeptCQ getConditionQueryDept() {
        if (_conditionQueryDept == null) {
            _conditionQueryDept = createQueryDept();
            setupOuterJoin_Dept();
        }
        return _conditionQueryDept;
    }

    /**
     * Setup outer join for ${foreignJavaBeansRulePropertyName}.
     */
    protected void setupOuterJoin_Dept() {
        final java.util.Map<String, String> joinOnMap = new java.util.LinkedHashMap<String, String>();
        joinOnMap.put(getRealColumnName("DEPT_ID"), getConditionQueryDept().getRealColumnName("ID"));
        getSqlClause().registerOuterJoin("DEPT", getConditionQueryDept().getRealAliasName(), joinOnMap);
    }

    /**
     * Create query for dept.
     * 
     * @return Query for dept. (NotNull)
     */
    protected sample.dbflute.cbean.cq.DeptCQ createQueryDept() {
        final int relationNo = getSqlClause().resolveRelationNo("EMP", "dept");
        String nextRelationPath = "_" + relationNo;
        if (_relationPath != null) {
            nextRelationPath = _relationPath + nextRelationPath;
        }
        final String resolvedAliasName = resolveJoinAliasName(nextRelationPath, getNextNestLevel());
        final sample.dbflute.cbean.cq.DeptCQ cq = new sample.dbflute.cbean.cq.DeptCQ(this, getSqlClause(), resolvedAliasName, getNextNestLevel());
        cq.setForeignPropertyName("dept");
        cq.setRelationPath(nextRelationPath);
        return cq;
    }

    /**
     * Has condition query?
     * 
     * @return Determination.
     */
    public boolean hasConditionQueryDept() {
        return _conditionQueryDept != null;
    }


}
