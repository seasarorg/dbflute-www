package sample.web.empwithoutdxo;

import org.seasar.framework.container.annotation.tiger.Binding;
import org.seasar.framework.container.annotation.tiger.BindingType;

import sample.dbflute.exbhv.EmpBhv;

public abstract class AbstractEmpPage {
	
	@Binding(bindingType = BindingType.MUST)
	public EmpBhv empBhv;

}
