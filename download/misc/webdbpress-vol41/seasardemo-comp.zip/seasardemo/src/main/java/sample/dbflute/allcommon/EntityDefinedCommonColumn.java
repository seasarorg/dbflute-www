package sample.dbflute.allcommon;

/**
 * The interface of entity defined common column.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface EntityDefinedCommonColumn extends Entity {

}
