package sample.web.emp;

import java.util.Date;
import java.util.List;

import org.seasar.teeda.extension.annotation.validator.Required;

import sample.dbflute.exentity.Emp;
import sample.dto.ValueLabelDto;

public class EmpUpdatePage extends AbstractEmpPage {


	// ##### プロパティ #####
	public Integer id;
	
	@Required
	public String empName;
	
	public Date hireDate;
		
	public Integer deptId;
	
	//public List<Map<String, Object>> deptIdItems;
	public List<ValueLabelDto> deptIdItems;
	
	public Integer versionNo;
	
	
	// ##### ロジック #####
	public Class doConfirm() {
		return EmpUpdateConfirmPage.class;
	}
	
	public Class initialize() {		
		return null;
	}

	public Class prerender() {
		/* プルダウンリスト（部署）のデータ準備 */
		deptIdItems = valueLabelService.findDepts();
		
		/* DBから1件分のEntityを取得（削除されていれば例外をスロー）*/
		Emp emp = empBhv.selectByPKValueWithDeletedCheck(id);
		
		/* EntityのプロパティをPageクラスのプロパティへマッピング */
		empDxo.convert(emp, this);
		
		return null;
	}		
}
