package sample.dbflute.exdao;


/**
 * The dao interface of DEPT.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface DeptDao extends sample.dbflute.bsdao.BsDeptDao {
}
