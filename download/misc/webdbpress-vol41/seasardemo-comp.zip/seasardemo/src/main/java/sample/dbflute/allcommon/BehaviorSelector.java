package sample.dbflute.allcommon;

import sample.dbflute.allcommon.bhv.BehaviorReadable;

/**
 * The interface of behavior-selector.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface BehaviorSelector {

    /**
     * Select behavior.
     * 
     * @param <BEHAVIOR_TYPE> The type of behavior.
     * @param behaviorType Behavior type. (NotNull)
     * @return Behavior. (NotNull)
     */
    public <BEHAVIOR_TYPE extends BehaviorReadable> BEHAVIOR_TYPE select(Class<BEHAVIOR_TYPE> behaviorType);

    /**
     * Select behavior-readable.
     * 
     * @param tableFlexibleName Table flexible-name. (NotNull)
     * @return Behavior-readable. (NotNull)
     */
    public BehaviorReadable byName(String tableFlexibleName);
}
