package sample.dbflute.cbean.bs;


import sample.dbflute.allcommon.cbean.AbstractConditionBean;
import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.cbean.ConditionQuery;
import sample.dbflute.cbean.cq.*;

/**
 * The condition-bean of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class BsEmpCB extends AbstractConditionBean {

    // ===================================================================================
    //                                                                          Annotation
    //                                                                          ==========
    /** TABLE-Annotation */
    public static final String TABLE = "EMP";

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Condition query. */
    protected EmpCQ _conditionQuery;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    public BsEmpCB() {
    }

    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [EMP]
    // * * * * * * * * */

    // ===================================================================================
    //                                                                          Table Name
    //                                                                          ==========
    /**
     * The implementation.
     * 
     * @return Table db-name. (NotNull)
     */
    final public String getTableDbName() {
        return "EMP";
    }

    /**
     * The implementation.
     * 
     * @return Table sql-name. (NotNull)
     */
    final public String getTableSqlName() {
        return "EMP";
    }

    // ===================================================================================
    //                                                                  Accept Primary-Key
    //                                                                  ==================
    /**
     * The implementation.
     * 
     * @param primaryKeyMap Primary key map. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMap(java.util.Map<String, ? extends Object> primaryKeyMap) {
        if (primaryKeyMap == null) {
            String msg = "The argument[primaryKeyMap] must not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (primaryKeyMap.isEmpty()) {
            String msg = "The argument[primaryKeyMap] must not be empty.";
            throw new IllegalArgumentException(msg);
        }
  
        if (!primaryKeyMap.containsKey("ID")) {
            String msg = "The primaryKeyMap must have the value of ID";
            throw new IllegalStateException(msg + ": primaryKeyMap --> " + primaryKeyMap);
        }
        {
            Object obj = primaryKeyMap.get("ID");
            if (obj instanceof java.lang.Integer) {
                query().setId_Equal((java.lang.Integer)obj);
            } else {
                  
                if (obj instanceof java.lang.Integer) {
                    query().setId_Equal((java.lang.Integer)obj);
                } else {
                    try {
                        query().setId_Equal(new java.lang.Integer((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.lang.Integer((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    // ===================================================================================
    //                                                                            Order-By
    //                                                                            ========
    /**
     * The implementation.
     * 
     * @return this. (NotNull)
     */
    public ConditionBean addOrderBy_PK_Asc() {
  
        query().addOrderBy_Id_Asc();
  
        return this;

    }

    /**
     * The implementation.
     * 
     * @return this. (NotNull)
     */
    public ConditionBean addOrderBy_PK_Desc() {
  
        query().addOrderBy_Id_Desc();
  
        return this;

    }

    // ===================================================================================
    //                                                                               Query
    //                                                                               =====
    /**
     * Query.
     * 
     * @return Instance of query. (NotNull)
     */
    public EmpCQ query() {
        return getConditionQuery();
    }

    /**
     * Get condition query. {Internal method for s2dao}
     * 
     * @return Instance of condition query. (NotNull)
     */
    public EmpCQ getConditionQuery() {
        if (_conditionQuery == null) {
            _conditionQuery = new EmpCQ(null, getSqlClause(), getTableDbName(), 0);
        }
        return _conditionQuery;
    }

    /**
     * The implementation.
     * 
     * @return Instance of query as interface. (NotNull)
     */
    public ConditionQuery getConditionQueryAsInterface() {
        return getConditionQuery();
    }

    // ===================================================================================
    //                                                                               Union
    //                                                                               =====
    /**
     * Union. <br />
     * Add union query to condition bean. <br />
     * 
     * @param unionQuery Union query. (NotNull)
     */
    public void union(EmpCQ unionQuery) {
        query().xsetUnionQuery(unionQuery);
    }

    /**
     * Union all. <br />
     * Add union all query to condition bean. <br />
     * 
     * @param unionAllQuery Union all query. (NotNull)
     */
    public void unionAll(EmpCQ unionAllQuery) {
        query().xsetUnionAllQuery(unionAllQuery);
    }

    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasUnionQueryOrUnionAllQuery() {
        return query().hasUnionQueryOrUnionAllQuery();
    }

    // ===================================================================================
    //                                                                        Setup-Select
    //                                                                        ============

    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [DEPT]
    //   ForeignProperty = [dept]
    // * * * * * * * * */

    /** Is select for dept? */
    protected boolean _isSelectDept;
    /** Nest select setupper for dept. */
    protected sample.dbflute.cbean.nss.DeptNss _nssDept;
    /**
     * Is select for dept? {For Internal}
     * 
     * @return Determination.
     */
    public boolean isSelectDept() {
        return _isSelectDept;
    }
    /**
     * Get nest select setupper for dept. {For Internal}
     * 
     * @return Nest select setupper. (NotNull)
     */
    public sample.dbflute.cbean.nss.DeptNss getNssDept() {
        if (_nssDept == null) {
            _nssDept = new sample.dbflute.cbean.nss.DeptNss(null);// for Dummy
        }
        return _nssDept;
    }
    /**
     * Set up select for dept.
     * If you invoke this, this entity is target of select.
     * 
     * @return Nest select setupper for dept. (NotNull)
     */
    public sample.dbflute.cbean.nss.DeptNss setupSelect_Dept() {
        query().queryDept();// For setting outer join.
        if (_nssDept == null || !_nssDept.hasConditionQuery()) {
            _nssDept = new sample.dbflute.cbean.nss.DeptNss(query().queryDept());
        }
        _isSelectDept = true;
        limitSelect_Off();
        return _nssDept;
    }

    // ===================================================================================
    //                                                                      Basic Override
    //                                                                      ==============
    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Clause string. (NotNull)
     */
    public String toString() {
        return getSqlClause().getClause();
    }
}
