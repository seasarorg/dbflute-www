package sample.service;

import java.util.ArrayList;
import java.util.List;

import org.seasar.framework.container.annotation.tiger.Binding;
import org.seasar.framework.container.annotation.tiger.BindingType;

import sample.dbflute.cbean.DeptCB;
import sample.dbflute.exbhv.DeptBhv;
import sample.dbflute.exentity.Dept;
import sample.dto.ValueLabelDto;

public class ValueLabelService {
	
	@Binding(bindingType = BindingType.MUST)
	public DeptBhv deptBhv;
	
//	public List<Map<String, Object>> findDepts() {
//		DeptCB cb = new DeptCB();
//		cb.query().addOrderBy_Id_Asc();
//		
//		ValueLabelSetupper<Dept> valueLabelSetupper = new ValueLabelSetupper<Dept>() {
//			public void setup(ValueLabelBox box, Dept entity) {
//				box.setValueLabel(entity.getId(), entity.getName());
//			}
//			
//		};		
//		return deptBhv.selectValueLabelList(cb, valueLabelSetupper);
//	}
	
	public List<ValueLabelDto> findDepts() {
		
		/* DBからList<Dept>を取得する */
		DeptCB cb = new DeptCB();
		cb.query().addOrderBy_Id_Asc();
		List<Dept> depts = deptBhv.selectList(cb);
		
		/* List<Dept>をList<ValueLabelDto>に変換する */
		List<ValueLabelDto> valueLabels = new ArrayList<ValueLabelDto>();
		for (Dept dept : depts) {
			ValueLabelDto dto = new ValueLabelDto();
			dto.value = dept.getId();
			dto.label = dept.getName();
			valueLabels.add(dto);
		}
		
		return valueLabels;		
	}

	public String getDeptLabel(Integer deptId) {
		return deptBhv.selectByPKValueWithDeletedCheck(deptId).getName();
	}	
}
