package sample.dbflute.allcommon.dbmeta;


import java.util.Map;
import java.util.LinkedHashMap;

/**
 * DBMeta instance handler.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class DBMetaInstanceHandler {

    /** The key-to-lower map of db-name and property-name for table. */
    protected static final Map<String, String> _tableDbNamePropertyNameKeyToLowerMap;
    static {
        Map<String, String> tmpMap = new LinkedHashMap<String, String>();

        tmpMap.put("DEPT".toLowerCase(), "dept");
        tmpMap.put("EMP".toLowerCase(), "emp");

        _tableDbNamePropertyNameKeyToLowerMap = java.util.Collections.unmodifiableMap(tmpMap);
    }

    /** The key-to-lower map of property-name and db-name for table. */
    protected static final Map<String, String> _tablePropertyNameDbNameKeyToLowerMap;
    static {
        Map<String, String> tmpMap = new LinkedHashMap<String, String>();

        tmpMap.put("dept".toLowerCase(), "DEPT");
        tmpMap.put("emp".toLowerCase(), "EMP");

        _tablePropertyNameDbNameKeyToLowerMap = java.util.Collections.unmodifiableMap(tmpMap);
    }

    /** Table db-name instance map. */
    protected static final Map<String, DBMeta> _tableDbNameInstanceMap;
    static {
        Map<String, DBMeta> tmpMap = new LinkedHashMap<String, DBMeta>();

        tmpMap.put("DEPT", getDBMeta("sample.dbflute.bsentity.dbmeta.DeptDbm"));
        tmpMap.put("EMP", getDBMeta("sample.dbflute.bsentity.dbmeta.EmpDbm"));

        _tableDbNameInstanceMap = java.util.Collections.unmodifiableMap(tmpMap);
    }

    /**
     * @deprecated
     */
    protected static final Map<String, DBMeta> _tableCapPropNameInstanceMap;
    static {
        Map<String, DBMeta> tmpMap = new LinkedHashMap<String, DBMeta>();

        tmpMap.put("Dept", getDBMeta("sample.dbflute.bsentity.dbmeta.DeptDbm"));
        tmpMap.put("Emp", getDBMeta("sample.dbflute.bsentity.dbmeta.EmpDbm"));

        _tableCapPropNameInstanceMap = java.util.Collections.unmodifiableMap(tmpMap);
    }

    /**
     * @deprecated
     */
    protected static final Map<String, DBMeta> _tableUncapPropNameInstanceMap;
    static {
        Map<String, DBMeta> tmpMap = new LinkedHashMap<String, DBMeta>();

        tmpMap.put("dept", getDBMeta("sample.dbflute.bsentity.dbmeta.DeptDbm"));
        tmpMap.put("emp", getDBMeta("sample.dbflute.bsentity.dbmeta.EmpDbm"));

        _tableUncapPropNameInstanceMap = java.util.Collections.unmodifiableMap(tmpMap);
    }

    protected static DBMeta getDBMeta(String className) {
        try {
            final Class clazz = Class.forName(className);
            final java.lang.reflect.Method methoz = clazz.getMethod("getInstance", (Class[])null);
            final Object result = methoz.invoke(null, (Object[])null);
            return (DBMeta)result;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Find dbmeta by table flexible-name.
     * <pre>
     * If the table name is 'ORDER_DETAIL', you can find the dbmeta by ...(as follows)
     *     'ORDER_DETAIL', 'ORDer_DeTAiL', 'order_detail'
     *     , 'OrderDetail', 'orderdetail', 'oRderDetaIl'
     * </pre>
     * @param tableFlexibleName Table flexible-name. (NotNull)
     * @return Instance. (NotNull)
     */
    public static DBMeta findDBMeta(String tableFlexibleName) {
        assertStringNotNullAndNotTrimmedEmpty("tableFlexibleName", tableFlexibleName);
        if (_tableDbNameInstanceMap.containsKey(tableFlexibleName)) {
            return byTableDbName(tableFlexibleName);
        }
        final String toLowerKey = tableFlexibleName.toLowerCase();
        if (_tableDbNamePropertyNameKeyToLowerMap.containsKey(toLowerKey)) {
            final String propertyName = (String)_tableDbNamePropertyNameKeyToLowerMap.get(toLowerKey);
            final String dbName = (String)_tablePropertyNameDbNameKeyToLowerMap.get(propertyName.toLowerCase());
            return byTableDbName(dbName);
        }
        if (_tablePropertyNameDbNameKeyToLowerMap.containsKey(toLowerKey)) {
            final String dbName = (String)_tablePropertyNameDbNameKeyToLowerMap.get(toLowerKey);
            return byTableDbName(dbName);
        }
        String msg = "The instance map returned null by the key: key=" + tableFlexibleName + " instanceMap=" + _tableDbNameInstanceMap;
        throw new IllegalStateException(msg);
    }

    /**
     * Get instance by table db-name.
     * 
     * @param tableDbName Table db-name. (NotNull)
     * @return Instance. (NotNull)
     */
    protected static DBMeta byTableDbName(String tableDbName) {
        assertStringNotNullAndNotTrimmedEmpty("tableDbName", tableDbName);
        final DBMeta instance = (DBMeta)_tableDbNameInstanceMap.get(tableDbName);
        if (instance == null) {
            String msg = "The instance map returned null by the key: key=" + tableDbName + " instanceMap=" + _tableDbNameInstanceMap;
            throw new IllegalStateException(msg);
        }
        return instance;
    }


    // ----------------------------------------------------------------
    //                                                    Assert Object
    //                                                    -------------
    /**
     * Assert that the argument is not null.
     * 
     * @param variableName Variable name. (NotNull)
     * @param arg Argument. (NotNull)
     */
    protected static void assertObjectNotNull(String variableName, Object arg) {
        if (variableName == null) {
            String msg = "Argument[variableName] should not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (arg == null) {
            String msg = "Argument[" + variableName + "] should not be null.";
            throw new IllegalArgumentException(msg);
        }
    }

    // ----------------------------------------------------------------
    //                                                    Assert String
    //                                                    -------------
    /**
     * Assert that the string is not null and not trimmed empty.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     */
    protected static void assertStringNotNullAndNotTrimmedEmpty(String variableName, String value) {
        if (variableName == null) {
            String msg = "Variable[variableName] should not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (value == null) {
            String msg = "Variable[" + variableName + "] should not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (value.trim().length() == 0) {
            String msg = "Variable[" + variableName + "] should not be empty: [" + value + "]";
            throw new IllegalArgumentException(msg);
        }
    }
}
