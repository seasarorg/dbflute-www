package sample.dbflute.allcommon;

import sample.dbflute.allcommon.bhv.BehaviorReadable;

import sample.dbflute.allcommon.dbmeta.DBMetaInstanceHandler;
import sample.dbflute.allcommon.dbmeta.DBMeta;

import org.seasar.framework.container.S2Container;

/**
 * The implementation of dao-selector.
 * <pre>
 * Long long ago this object have cache of dao and bhv.
 * But the cache cause wrong performance when this is initialized.
 * So now this object don't have cache.
 * </pre>
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class CacheDaoSelector implements DaoSelector {

    protected S2Container _container;

    public void setContainer(S2Container container) {
        this._container = container;
    }


    /**
     * Select dao.
     * 
     * @param <DAO_TYPE> The type of behavior.
     * @param daoType Dao type. (NotNull)
     * @return Dao. (NotNull)
     */
    public <DAO_TYPE extends DaoReadable> DAO_TYPE select(Class<DAO_TYPE> daoType) {
        return (DAO_TYPE)_container.getComponent(daoType);
    }

    /**
     * Select dao-readable by name.
     * 
     * @param tableFlexibleName Table flexible name. (NotNull)
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable byName(String tableFlexibleName) {
        assertStringNotNullAndNotTrimmedEmpty("tableFlexibleName", tableFlexibleName);
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(tableFlexibleName);
        return select(getDaoType(dbmeta));
    }



    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * Deprecated
    /**
     * Get dao.
     * 
     * @param daoType Dao type. (NotNull)
     * @return Dao. (NotNull)
     * @deprecated Please use this#select()
     */
    public <DAO_TYPE extends DaoReadable> DAO_TYPE getDao(Class<DAO_TYPE> daoType) {
        return (DAO_TYPE)_container.getComponent(daoType);
    }

    /**
     * Get dao-readable.
     * 
     * @param tableFlexibleName Table flexible name. (NotNull)
     * @return Dao-readable. (NotNull)
     * @deprecated Please use this#byName()
     */
    public DaoReadable byNameAsDaoReadable(String tableFlexibleName) {
        assertStringNotNullAndNotTrimmedEmpty("tableFlexibleName", tableFlexibleName);
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(tableFlexibleName);
        return getDao(getDaoType(dbmeta));
    }

    /**
     * Get behavior.
     * 
     * @param behaviorType Behavior type. (NotNull)
     * @return Behavior. (NotNull)
     * @deprecated Please use BehaviorSelector#select()
     */
    public <BEHAVIOR_TYPE extends BehaviorReadable> BEHAVIOR_TYPE getBehavior(Class<BEHAVIOR_TYPE> behaviorType) {
        return (BEHAVIOR_TYPE)_container.getComponent(behaviorType);
    }

    /**
     * Get behavior-readable.
     * 
     * @param tableFlexibleName Table flexible name. (NotNull)
     * @return Behavior-readable. (NotNull)
     * @deprecated Please use BehaviorSelector#byName()
     */
    public BehaviorReadable byNameAsBehaviorReadable(String tableFlexibleName) {
        assertStringNotNullAndNotTrimmedEmpty("tableFlexibleName", tableFlexibleName);
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(tableFlexibleName);
        return getBehavior(getBehaviorType(dbmeta));
    }


    /**
     * Get behavior-type by dbmeta.
     * 
     * @param dbmeta Dbmeta. (NotNull)
     * @return Behavior-type. (NotNull)
     */
    protected Class getBehaviorType(DBMeta dbmeta) {
        final String behaviorTypeName = dbmeta.getBehaviorTypeName();
        if (behaviorTypeName == null) {
            String msg = "The dbmeta.getBehaviorTypeName() should not return null: dbmeta=" + dbmeta;
            throw new IllegalStateException(msg);
        }
        final Class behaviorType;
        try {
            behaviorType = Class.forName(behaviorTypeName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("The class does not exist: " + behaviorTypeName, e);
        }
        return behaviorType;
    }

    protected Class getDaoType(DBMeta dbmeta) {
        final String daoTypeName = dbmeta.getDaoTypeName();
        if (daoTypeName == null) {
            String msg = "The dbmeta.getDaoTypeName() should not return null: dbmeta=" + dbmeta;
            throw new IllegalStateException(msg);
        }
        final Class daoType;
        try {
            daoType = Class.forName(daoTypeName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("The class does not exist: " + daoTypeName, e);
        }
        return daoType;
    }

    // =====================================================================================
    //                                                                               Destroy
    //                                                                               =======
    public void destroy() {
        _container = null;
    }

    // ----------------------------------------------------------------
    //                                                    Assert Object
    //                                                    -------------
    /**
     * Assert that the object is not null.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     * @exception IllegalArgumentException
     */
    protected void assertObjectNotNull(String variableName, Object value) {
        if (variableName == null) {
            String msg = "The value should not be null: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
        if (value == null) {
            String msg = "The value should not be null: variableName=" + variableName;
            throw new IllegalArgumentException(msg);
        }
    }

    // ----------------------------------------------------------------
    //                                                    Assert String
    //                                                    -------------
    /**
     * Assert that the entity is not null and not trimmed empty.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     */
    protected void assertStringNotNullAndNotTrimmedEmpty(String variableName, String value) {
        assertObjectNotNull("variableName", variableName);
        assertObjectNotNull("value", value);
        if (value.trim().length() ==0) {
            String msg = "The value should not be empty: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
    }
}
