package sample.dbflute.allcommon.cbean;

import sample.dbflute.allcommon.cbean.cvalue.ConditionValue;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;

/**
 * The condition-query as interface.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface ConditionQuery {

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    /**
     * Get table db-name.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName();

    /**
     * Get real alias name(that has nest level mark).
     * 
     * @return Real alias name.
     */
    public String getRealAliasName();

    /**
     * Get real column name(with real alias name).
     * 
     * @param columnName Column name without alias name.
     * @return Real column name.
     */
    public String getRealColumnName(String columnName);

    /**
     * Get child query.
     * 
     * @return Child query. (Nullable)
     */
    public ConditionQuery getChildQuery();

    /**
     * Get sql clause.
     * 
     * @return Sql clause. (NotNull)
     */
    public SqlClause getSqlClause();

    /**
     * Get alias name.
     * 
     * @return Alias name. (NotNull)
     */
    public String getAliasName();

    /**
     * Get nest level.
     * 
     * @return Nest level.
     */
    public int getNestLevel();

    /**
     * Get next nest level.
     * 
     * @return Next nest level.
     */
    public int getNextNestLevel();

    /**
     * Is base query?
     * 
     * @param query Condition query. (NotNull)
     * @return Determination.
     */
    public boolean isBaseQuery(ConditionQuery query);

    public String getForeignPropertyName();

    // ===================================================================================
    //                                                                              Invoke
    //                                                                              ======
    /**
     * Invoke getter.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     * @return Condition-value. (NotNull)
     */
    public ConditionValue invokeGetter(String columnMultiName);

    /**
     * Invoke setter for equal.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     * @param value Value. (Nullable)
     */
    public void invokeSetterEqual(String columnMultiName, Object value);

    /**
     * Invoke setter for notEqual.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     * @param value Value. (Nullable)
     */
    public void invokeSetterNotEqual(String columnMultiName, Object value);

    /**
     * Invoke setter for greaterThan.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     * @param value Value. (Nullable)
     */
    public void invokeSetterGreaterThan(String columnMultiName, Object value);

    /**
     * Invoke setter for lessThan.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     * @param value Value. (Nullable)
     */
    public void invokeSetterLessThan(String columnMultiName, Object value);

    /**
     * Invoke setter for greaterThan.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     * @param value Value. (Nullable)
     */
    public void invokeSetterGreaterEqual(String columnMultiName, Object value);

    /**
     * Invoke setter for lessThan.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     * @param value Value. (Nullable)
     */
    public void invokeSetterLessEqual(String columnMultiName, Object value);

    /**
     * Invoke add order-by asc.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     */
    public void invokeAddOrderByAsc(String columnMultiName);

    /**
     * Invoke add order-by desc.
     * 
     * @param columnMultiName Column multi name. (NotNull and NotEmpty)
     */
    public void invokeAddOrderByDesc(String columnMultiName);

    // ===================================================================================
    //                                                                       Foregin Query
    //                                                                       =============
    /**
     * Get foreign condition query contains referer-as-one.
     * 
     * @param foreignPropertyName Foreign property name. (NotNull and NotEmpty and Both OK -- InitCap or not)
     * @return Foreign condition-query. (NotNull)
     */
    public ConditionQuery getForeignConditionQuery(String foreignPropertyName);
}
