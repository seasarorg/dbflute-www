package sample.dbflute.allcommon.bhv;

import sample.dbflute.allcommon.DaoWritable;
import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.bhv.batch.TokenFileReflectionOption;
import sample.dbflute.allcommon.bhv.batch.TokenFileReflectionResult;

/**
 * The interface of behavior-writable.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface BehaviorWritable extends BehaviorReadable {

    /**
     * Get dao-writable.
     * 
     * @return Dao-writable. (NotNull)
     */
    public DaoWritable getDaoWritable();

    // =====================================================================================
    //                                                                   Basic Entity Update
    //                                                                   ===================
    /**
     * Create.
     * 
     * @param entity Entity. (NotNull)
     */
    public void create(sample.dbflute.allcommon.Entity entity);

    /**
     * Modify.
     * 
     * @param entity Entity. (NotNull)
     */
    public void modify(sample.dbflute.allcommon.Entity entity);

    /**
     * Modify non-strict.
     * 
     * @param entity Entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.RecordHasAlreadyBeenDeletedException
     * @exception sample.dbflute.allcommon.exception.RecordHasOverlappedException
     */
    public void modifyNonstrict(Entity entity);

    /**
     * Modify after select. <br />
     * {modify: modified only}
     * <pre>
     * The merit of this method is only Deleted-Check before updating!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param entity Entity.
     * @exception sample.dbflute.allcommon.exception.RecordHasAlreadyBeenDeletedException
     * @deprecated Thie method is old style and has wrong performance. Please use modify().
     */
    public void modifyAfterSelect(sample.dbflute.allcommon.Entity entity);

    /**
     * Create or modify. <br />
     * {modify: modified only} <br />
     * This method is faster than createOrModifyAfterSelect().
     * 
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     */
    public void createOrModify(sample.dbflute.allcommon.Entity entity);

    /**
     * Create or modify non-strict. <br />
     * {modify: modified only} <br />
     * This method is faster than createOrModifyAfterSelect().
     * 
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     */
    public void createOrModifyNonstrict(sample.dbflute.allcommon.Entity entity);

    /**
     * Create or modify after select. <br />
     * {modify: modified only}
     * <pre>
     * The merit of this method is only Deleted-Check before updating!
     * If you don't want the merit, please use update().
     * And the demerit of this method is as follows:
     *   : If the entity does not have the optimistic lock value, for example version-no and timestamp,
     *   : it does not throw optimistic lock exception. It can updates.
     * </pre>
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     * @deprecated Thie method is old style and has wrong performance. Please use createOrModify().
     */
    public void createOrModifyAfterSelect(sample.dbflute.allcommon.Entity entity);

    /**
     * Remove.
     * 
     * @param entity Entity. (NotNull)
     */
    public void remove(sample.dbflute.allcommon.Entity entity);


    // =====================================================================================
    //                                                                    Basic Batch Update
    //                                                                    ==================
    /**
     * Lump create the list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return The array of created count.
     */
    public int[] lumpCreate(java.util.List<Entity> entityList);

    /**
     * Create list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Created count.
     * @deprecated Sorry! This method name is very confusing. Please use lumpCreate().
     */
    public int createList(java.util.List<Entity> entityList);

    /**
     * Lump Modify the list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Modified count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] lumpModify(java.util.List<Entity> entityList);

    /**
     * Modify list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Modified count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use lumpModify().
     */
    public int modifyList(java.util.List<Entity> entityList);

    /**
     * Lump remove the list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Removed count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     */
    public int[] lumpRemove(java.util.List<Entity> entityList);

    /**
     * Remove list.
     * 
     * @param entityList Entity-list. (NotNull and NotEmpty)
     * @return Removed count.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyUpdatedException If s2dao's version is over 1.0.47 (contains 1.0.47).
     * @deprecated Sorry! This method name is very confusing. Please use lumpRemove().
     */
    public int removeList(java.util.List<Entity> entityList);

    // =====================================================================================
    //                                                                            Token File
    //                                                                            ==========
    /**
     * Reflect(insert or update) token-file to this table.
     * 
     * @param filename Name of the file. (NotNull and NotEmpty)
     * @param tokenFileReflectionOption token-file-reflection-option. (NotNull and Required{delimiter and encoding})
     * @return Token-file-reflection-result. (NotNull)
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public TokenFileReflectionResult reflectTokenFile(String filename, TokenFileReflectionOption tokenFileReflectionOption) throws java.io.FileNotFoundException, java.io.IOException;

    /**
     * Reflect(insert or update) token-file to this table.
     * 
     * @param inputStream Input stream. (NotNull and NotClosed)
     * @param tokenFileReflectionOption token-file-reflection-option. (NotNull and Required{delimiter and encoding})
     * @return Token-file-reflection-result. (NotNull)
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public TokenFileReflectionResult reflectTokenFile(java.io.InputStream inputStream, TokenFileReflectionOption tokenFileReflectionOption) throws java.io.FileNotFoundException, java.io.IOException;
}
