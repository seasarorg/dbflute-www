package sample.dbflute.allcommon.dbmeta.info;


import sample.dbflute.allcommon.dbmeta.DBMeta;

/**
 * The class of referer information.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface RelationInfo {

    public String getRelationPropertyName();

    public DBMeta getLocalDBMeta();

    public DBMeta getTargetDBMeta();

    public java.util.Map<ColumnInfo, ColumnInfo> getLocalTargetColumnInfoMap();

    public boolean isOneToOne();

    public boolean isReferer();
}
