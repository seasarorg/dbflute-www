package sample.dbflute.allcommon.cbean.pagenavi.group;


/**
 * The option of page group.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class PageGroupOption implements java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    protected int _pageGroupSize;

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    public int getPageGroupSize() {
        return _pageGroupSize;
    }

    public void setPageGroupSize(int pageGroupSize) {
        this._pageGroupSize = pageGroupSize;
    }

    // ===================================================================================
    //                                                                      Basic Override
    //                                                                      ==============
    /**
     * The override.
     * 
     * @return View string. (NotNull)
     */
    public String toString() {
        final StringBuffer sb = new StringBuffer();

        sb.append(" pageGroupSize=").append(_pageGroupSize);

        return sb.toString();
    }
}
