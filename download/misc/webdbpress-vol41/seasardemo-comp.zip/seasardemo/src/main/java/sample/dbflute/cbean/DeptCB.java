package sample.dbflute.cbean;


/**
 * The condition-bean of DEPT.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class DeptCB extends sample.dbflute.cbean.bs.BsDeptCB {
}
