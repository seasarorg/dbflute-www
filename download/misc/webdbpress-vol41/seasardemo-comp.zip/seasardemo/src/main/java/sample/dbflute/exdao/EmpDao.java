package sample.dbflute.exdao;


/**
 * The dao interface of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface EmpDao extends sample.dbflute.bsdao.BsEmpDao {
}
