package sample.dbflute.allcommon.s2dao;


import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import java.lang.reflect.Method;
import java.sql.DatabaseMetaData;
import java.util.List;


import org.seasar.dao.BeanEnhancer;
import org.seasar.dao.BeanMetaData;
import org.seasar.dao.BeanMetaDataFactory;

import org.seasar.dao.Dbms;
import org.seasar.dao.RelationPropertyType;
import org.seasar.dao.RelationRowCreator;
import org.seasar.dao.impl.BeanMetaDataImpl;
import org.seasar.dao.impl.DaoMetaDataImpl;
import org.seasar.dao.impl.AbstractSqlCommand;
import org.seasar.dao.impl.SelectDynamicCommand;
import org.seasar.dao.impl.UpdateAutoDynamicCommand;
import org.seasar.dao.impl.UpdateModifiedOnlyCommand;
import org.seasar.dao.impl.UpdateBatchAutoStaticCommand;
import org.seasar.dao.impl.DeleteAutoStaticCommand;
import org.seasar.dao.impl.DeleteBatchAutoStaticCommand;

import org.seasar.dao.BeanAnnotationReader;
import org.seasar.dao.PropertyTypeFactoryBuilder;
import org.seasar.dao.RelationPropertyTypeFactoryBuilder;
import org.seasar.dao.TableNaming;
import org.seasar.dao.ColumnNaming;
import org.seasar.dao.PropertyTypeFactory;
import org.seasar.dao.impl.PropertyTypeFactoryImpl;
import org.seasar.dao.impl.PropertyTypeFactoryBuilderImpl;

import org.seasar.extension.jdbc.PropertyType;
import org.seasar.extension.jdbc.ResultSetHandler;
import org.seasar.extension.jdbc.types.ValueTypes;
import org.seasar.framework.util.StringUtil;

import sample.dbflute.allcommon.annotation.OutsideSql;
import sample.dbflute.allcommon.cbean.ConditionBeanContext;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;

/**
 * DaoMetaDataImpl for DBFlute.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class S2DaoMetaDataExtension extends DaoMetaDataImpl {

    // ===================================================================================
    //                                                                          Definition
    //                                                                          ==========
    /** The determination of internal debug. */
    private static final boolean _internalDebug = false;

    /** Log instance. */
    private static final org.apache.commons.logging.Log _log = org.apache.commons.logging.LogFactory.getLog(S2DaoMetaDataExtension.class);

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Bean enhancer. */
    protected BeanEnhancer beanEnhancer;

    /** The factory of annotation reader. */
    protected org.seasar.dao.AnnotationReaderFactory annotationReaderFactory;

    /** The naming of column. {After S2Dao-1.0.47} */
    protected ColumnNaming columnNaming;

    /** The builder of property type factory. {After S2Dao-1.0.47} */
    protected PropertyTypeFactoryBuilder propertyTypeFactoryBuilder;

    /** The builder of relation property type factory. {After S2Dao-1.0.47} */
    protected RelationPropertyTypeFactoryBuilder relationPropertyTypeFactoryBuilder;

    /** The builder of table naming. {After S2Dao-1.0.47} */
    protected TableNaming tableNaming;


    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    public S2DaoMetaDataExtension() {
    }


    // ===================================================================================
    //                                                           OutsideSql Check Override
    //                                                           =========================
    protected void setupMethodByAuto(Method method) {
        final OutsideSql outsideSql = method.getAnnotation(OutsideSql.class);
        if (outsideSql != null) {
            String msg = "This method '" + method.getName() + "()' should use Outside Sql but the file was not found!";
            msg = msg + " Expected sql file name is '" + method.getDeclaringClass().getSimpleName() + "_" + method.getName() + ".sql'";
            throw new IllegalStateException(msg);
        }
        super.setupMethodByAuto(method);
    }
    // ===================================================================================
    //                                                           ResultSetHandler Override
    //                                                           =========================
    protected ResultSetHandler createResultSetHandler(Method method) {
        return this.resultSetHandlerFactory.getResultSetHandler(daoAnnotationReader, beanMetaData, method);
    }

    protected ResultSetHandler createResultSetHandler(BeanMetaData specifiedBeanMetaData, Method method) {
        return this.resultSetHandlerFactory.getResultSetHandler(daoAnnotationReader, specifiedBeanMetaData, method);
    }

    // ===================================================================================
    //                                             Customize SelectDynamicCommand Creation
    //                                             =======================================
    /**
     * Create customize select dynamic command.
     * 
     * @param handler The handler of result set. (NotNull)
     * @return Customize select dynamic command. (NotNull)
     */
    protected S2DaoSelectDynamicCommand createCustomizeSelectDynamicCommand(org.seasar.extension.jdbc.ResultSetHandler handler) {
        final org.seasar.extension.jdbc.ResultSetFactory customizeResultSetFactory = new sample.dbflute.allcommon.s2dao.FetchNarrowingResultSetFactory();
        final org.seasar.extension.jdbc.impl.ConfigurableStatementFactory confSf;
        if (statementFactory instanceof org.seasar.extension.jdbc.impl.ConfigurableStatementFactory) {
            confSf = (org.seasar.extension.jdbc.impl.ConfigurableStatementFactory)statementFactory;
        } else {
            confSf = null;
        }
        final org.seasar.extension.jdbc.StatementFactory customizeStatementFactory = new org.seasar.extension.jdbc.StatementFactory() {
            public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con, String sql) {
                try {
                    if (_internalDebug && _log.isDebugEnabled()) {
                        _log.debug("...Invoking ps.prepareStatement(sql, java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, java.sql.ResultSet.CONCUR_READ_ONLY)");
                    }
                    final java.sql.PreparedStatement ps = con.prepareStatement(sql, java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, java.sql.ResultSet.CONCUR_READ_ONLY);
                    if (confSf == null) {
                        return ps;
                    }
                    final Class confSfType = org.seasar.extension.jdbc.impl.ConfigurableStatementFactory.class;
                    final String confMethodName = "configurePreparedStatement";
                    final Class[] confMethodParameterType = new Class[]{java.sql.PreparedStatement.class};
                    try {
                        final Method confMethod = confSfType.getDeclaredMethod(confMethodName, confMethodParameterType);
                        confMethod.setAccessible(true);// Because the method is protected!
                        if (_internalDebug && _log.isDebugEnabled()) {
                            _log.debug("...Invoking configurableStatementFactory." + confMethodName + "(ps)");
                        }
                        confMethod.invoke(confSf, new Object[]{ps});
                        return ps;
                    } catch (Exception e) {
                        String msg = "The configuration of statement factory threw exception:";
                        msg = msg + " class=" + confSfType + " method=" + confMethodName + " parameter=java.sql.PreparedStatement";
                        throw new RuntimeException(msg, e);
                    }
                } catch (java.sql.SQLException e) {
                    throw new org.seasar.framework.exception.SQLRuntimeException(e);
                }
            }
            public java.sql.CallableStatement createCallableStatement(java.sql.Connection con, String sql) {
                return org.seasar.extension.jdbc.util.ConnectionUtil.prepareCall(con, sql);
            }
        };
        return new S2DaoSelectDynamicCommand(dataSource, customizeStatementFactory, handler, customizeResultSetFactory);
    }

    // ===================================================================================
    //                                                              ConditionBean Override
    //                                                              ======================

    protected SelectDynamicCommand setupNonQuerySelectMethodByDto(Method method, ResultSetHandler handler, String[] argNames, String query) {
        Class[] types = method.getParameterTypes();
        Class clazz = types[0];
        if (!ConditionBeanContext.isTheTypeConditionBean(clazz)) {
            return super.setupNonQuerySelectMethodByDto(method, handler, argNames, query);
        }
        // /----------------------------------------------------- [MyExtension]
        argNames = new String[] { "dto" };
        final String sqlNormal = getSelectClause(getBeanMetaData(), clazz);
        final String sqlPKOnly = getSelectClausePKOnly(getBeanMetaData());
        final S2DaoSelectDynamicCommand dynamicCommand = createCustomizeSelectDynamicCommand(handler);
        String sql = sqlNormal;
        final SelectDynamicCommand cmd = dynamicCommand;
        dynamicCommand.setSelectClause(sqlNormal);
        dynamicCommand.setSelectClausePKOnly(sqlPKOnly);
        // -----------/
        if (query != null) {
            sql = sql + " " + query;
        }
        cmd.setSql(sql);
        cmd.setArgNames(argNames);
        cmd.setArgTypes(types);
        return cmd;
    }

    /**
     * Get select clause.
     * 
     * @param beanMetaData BeanMetaData. (NotNull)
     * @param conditionBeanClass Condition-bean class. (NotNull)
     * @return Select clause. (NotNull)
     */
    protected String getSelectClause(BeanMetaData beanMetaData, Class conditionBeanClass) {
        final StringBuffer sb = new StringBuffer(100);
        sb.append("select/*$dto.selectHint*/ ");

        final StringBuffer sbMySelectList = new StringBuffer(100);
        for (int i = 0; i < beanMetaData.getPropertyTypeSize(); ++i) {
            final PropertyType pt = beanMetaData.getPropertyType(i);
            if (pt.isPersistent()) {
                if (sbMySelectList.length() != 0) {
                    sbMySelectList.append(", ");
                }
                final String columnFullName = beanMetaData.getTableName() + "." + pt.getColumnName();
                sbMySelectList.append(columnFullName);

                ConditionBeanContext.addColumnAliasInfo(conditionBeanClass, columnFullName, pt.getColumnName());
            }
        }
        sb.append(sbMySelectList);

        setupRelationSelectClause(sb, beanMetaData, "", "", 1, conditionBeanClass);
        return sb.toString();
    }

    protected void setupRelationSelectClause(StringBuffer sb, BeanMetaData baseBmd, String judgeProp, String preNoSuffix, int cqNestNo, Class conditionBeanClass) {
        for (int i = 0; i < baseBmd.getRelationPropertyTypeSize(); ++i) {
            final StringBuffer sbYourSelectList = new StringBuffer(100);
            final RelationPropertyType rpt = baseBmd.getRelationPropertyType(i);
            if (rpt == null) {
                continue;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                // Comment out because it is possible that s2dao make relation property type as null.
                //   Ref: org.seasar.dao.impl.BeanMetaDataImpl#addRelationPropertyType();
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                // String msg = "The baseBmd.getRelationPropertyType(" + i + ") returned null";
                // msg = msg + ": baseBmd.getTableName()=" + baseBmd.getTableName();
                // msg = msg + ": baseBmd.getRelationPropertyTypeSize()=" + baseBmd.getRelationPropertyTypeSize();
                // throw new IllegalStateException(msg);
            }

            final BeanMetaData relationBmd = rpt.getBeanMetaData();
            final String initCapPropertyName = StringUtil.capitalize(rpt.getPropertyName());
            final String ifComment = "/*IF dto." + judgeProp + "isSelect" + initCapPropertyName + "()*/";
            final String endComment = "/*END*/";
            for (int j = 0; j < relationBmd.getPropertyTypeSize(); ++j) {
                final PropertyType pt = relationBmd.getPropertyType(j);
                final String relationPath = preNoSuffix + "_" + rpt.getRelationNo();
                final String tableAliasName = resolveJoinAliasName(relationPath, cqNestNo);
                if (pt.isPersistent()) {
                    final String columnName = pt.getColumnName();
                    final String columnFullName = tableAliasName + "." + columnName;
                    final String columnAliasName = pt.getColumnName() + relationPath;
                    sbYourSelectList.append(", ");
                    sbYourSelectList.append(columnFullName).append(" AS ").append(columnAliasName);

                    ConditionBeanContext.addColumnAliasInfo(conditionBeanClass, columnFullName, columnAliasName);
                }
            }
            if (relationBmd.getRelationPropertyTypeSize() > 0) {
                final String nssString = "nss" + initCapPropertyName + ".";
                final String nextPreNoSuffix = preNoSuffix + "_" + rpt.getRelationNo();
                final int nextCQNestNo = cqNestNo + 1;
                setupRelationSelectClause(sbYourSelectList, relationBmd, nssString, nextPreNoSuffix, nextCQNestNo, conditionBeanClass);
            }
            sb.append(ifComment).append(sbYourSelectList).append(endComment);
        }
    }

    protected String resolveJoinAliasName(String relationPath, int cqNestNo) {
        final SqlClause sqlClause = ConditionBeanContext.createSqlClause("dummy");
        return sqlClause.resolveJoinAliasName(relationPath, cqNestNo);
    }

    /**
     * Get select clause PK only.
     * 
     * @param beanMetaData BeanMetaData. (NotNull)
     * @return Select clause PK only. (NotNull)
     */
    protected String getSelectClausePKOnly(BeanMetaData beanMetaData) {
        final StringBuffer sb = new StringBuffer(100);
        sb.append("select/*$dto.selectHint*/ ");

        final StringBuffer sbMySelectList = new StringBuffer(100);
        for (int i = 0; i < beanMetaData.getPropertyTypeSize(); ++i) {
            final PropertyType pt = beanMetaData.getPropertyType(i);
            if (pt.isPersistent() && pt.isPrimaryKey()) {
                if (sbMySelectList.length() != 0) {
                    sbMySelectList.append(", ");
                }
                sbMySelectList.append(beanMetaData.getTableName());
                sbMySelectList.append(".");
                sbMySelectList.append(pt.getColumnName());
            }
        }
        sb.append(sbMySelectList);

        return sb.toString();
    }

    // ===================================================================================
    //                                                  Update and Delete By Auto Override
    //                                                  ==================================
    @Override()
    protected AbstractSqlCommand createUpdateAutoDynamicCommand(Method method, String[] propertyNames) {
        AbstractSqlCommand cmd;
        final UpdateAutoDynamicCommand uac = newUpdateAutoDynamicCommand(dataSource, statementFactory);
        uac.setBeanMetaData(createBeanMetaData4UpdateDeleteByAuto(method));// Extension Point!
        uac.setPropertyNames(propertyNames);
        uac.setNotSingleRowUpdatedExceptionClass(getNotSingleRowUpdatedExceptionClass(method));
        cmd = uac;
        return cmd;
    }

    protected UpdateAutoDynamicCommand newUpdateAutoDynamicCommand(javax.sql.DataSource ds, org.seasar.extension.jdbc.StatementFactory sf) {
        return new UpdateAutoDynamicCommand(ds, sf);
    }

    @Override()
    protected AbstractSqlCommand createUpdateModifiedOnlyCommand(final Method method, final String[] propertyNames) {
        UpdateModifiedOnlyCommand uac = newUpdateModifiedOnlyCommand(dataSource, statementFactory);
        uac.setBeanMetaData(createBeanMetaData4UpdateDeleteByAuto(method));// Extension Point!
        uac.setPropertyNames(propertyNames);
        uac.setNotSingleRowUpdatedExceptionClass(getNotSingleRowUpdatedExceptionClass(method));
        return uac;
    }

    protected UpdateModifiedOnlyCommand newUpdateModifiedOnlyCommand(javax.sql.DataSource ds, org.seasar.extension.jdbc.StatementFactory sf) {
        return new UpdateModifiedOnlyCommand(ds, sf);
    }

    @Override()
    protected UpdateBatchAutoStaticCommand createUpdateBatchAutoStaticCommand(final Method method, final String[] propertyNames, boolean returningRows) {
        return new UpdateBatchAutoStaticCommand(dataSource, statementFactory, createBeanMetaData4UpdateDeleteByAuto(method), propertyNames, returningRows) {
            public Object execute(Object[] args) {
                final Object result = super.execute(args);
                handleBatchUpdateResultWithOptimisticLock(args, result);
                return result;
            }
        };
    }

    protected void handleBatchUpdateResultWithOptimisticLock(Object[] args, Object result) {
        if (args.length == 0) {
            return;// for Safety!
        }
        if (result instanceof int[]) {
            final int[] updatedCountArray = (int[])result;
            int index = 0;
            for (int updatedCount : updatedCountArray) {
                if (updatedCount == 0) {
                    if (args.length <= index) {
                        return;// for Safety!
                    }
                    throw new org.seasar.dao.NotSingleRowUpdatedRuntimeException(args[index], updatedCount);
                }
            }
        }
    }


    @Override()
    protected DeleteAutoStaticCommand createDeleteAutoStaticCommand(final Method method, final String[] propertyNames) {
        return new DeleteAutoStaticCommand(dataSource, statementFactory, createBeanMetaData4UpdateDeleteByAuto(method), propertyNames);
    }

    @Override()
    protected DeleteBatchAutoStaticCommand createDeleteBatchAutoStaticCommand(final Method method, final String[] propertyNames, boolean returningRows) {
        return new DeleteBatchAutoStaticCommand(dataSource, statementFactory, createBeanMetaData4UpdateDeleteByAuto(method), propertyNames, returningRows);
    }


    protected BeanMetaData createBeanMetaData4UpdateDeleteByAuto(Method method) {
        if (method.getName().contains("Nonstrict")) {
            return createNonConcurrencyBmdFactory().createBeanMetaData(getBeanClass());
        } else {
            return getBeanMetaData();
        }
    }

    protected BeanMetaDataFactory createNonConcurrencyBmdFactory() {
        final S2BeanMetaDataFactoryImpl nonConcurrencyBmdFactory = new S2BeanMetaDataFactoryImpl() {
            protected BeanMetaDataImpl createBeanMetaDataImpl() {
                return new BeanMetaDataImpl() {
                    public boolean hasVersionNoPropertyType() {
                        return false;
                    }

                    public boolean hasTimestampPropertyType() {
                        return false;
                    }
                };
            }
        };
        nonConcurrencyBmdFactory.setAnnotationReaderFactory(this.annotationReaderFactory);
        nonConcurrencyBmdFactory.setPropertyTypeFactoryBuilder(this.propertyTypeFactoryBuilder);
        nonConcurrencyBmdFactory.setRelationPropertyTypeFactoryBuilder(this.relationPropertyTypeFactoryBuilder);
        nonConcurrencyBmdFactory.setTableNaming(this.tableNaming);
        nonConcurrencyBmdFactory.setDataSource(this.dataSource);
        nonConcurrencyBmdFactory.setDaoNamingConvention(this.daoNamingConvention);
        nonConcurrencyBmdFactory.setBeanEnhancer(this.beanEnhancer);
        return nonConcurrencyBmdFactory;
    }

    // ===================================================================================
    //                                                                 OutsideSql Override
    //                                                                 ===================
    protected void setupSelectMethodByManual(Method method, String sql) {
        Class<?>[] parameterTypes = method.getParameterTypes();
        Class<?>[] filteredParameterTypes;
        if (parameterTypes != null && parameterTypes.length > 0
                && sample.dbflute.allcommon.jdbc.CursorHandler.class.isAssignableFrom(parameterTypes[parameterTypes.length-1])) {
            filteredParameterTypes = new Class<?>[parameterTypes.length - 1];
            for (int i=0; i < parameterTypes.length - 1; i++) {
                filteredParameterTypes[i] = parameterTypes[i];
            }
        } else {
            filteredParameterTypes = parameterTypes;
        }
        final BeanMetaData myBeanMetaData = getOutsideSqlBeanMetaData(method);
        final SelectDynamicCommand cmd = createCustomizeSelectDynamicCommand(createResultSetHandler(myBeanMetaData, method));
        cmd.setSql(sql);
        cmd.setArgNames(this.daoAnnotationReader.getArgNames(method));
        cmd.setArgTypes(filteredParameterTypes);
        this.sqlCommands.put(method.getName(), cmd);
    }

    protected BeanMetaData getOutsideSqlBeanMetaData(Method method) {
        final Class beanClass4SelectMethodByManual = getOutsideSqlDefaultBeanClass(method);
        if (beanClass4SelectMethodByManual.equals(getBeanClass())) {
            return getOutsideSqlDefaultBeanMetaData(method);
        }
        return getOutsideSqlCustomizeBeanMetaData(method);
    }

    protected BeanMetaData getOutsideSqlDefaultBeanMetaData(Method method) {
        return getBeanMetaData();
    }

    protected BeanMetaData getOutsideSqlCustomizeBeanMetaData(Method method) {
        return createOutsideSqlCustomizeBeanMetaDataFactory().createBeanMetaData(getOutsideSqlDefaultBeanClass(method));
    }

    protected BeanMetaDataFactory createOutsideSqlCustomizeBeanMetaDataFactory() {
        final S2BeanMetaDataFactoryImpl originalBmdFactory = new S2BeanMetaDataFactoryImpl() {
            protected BeanMetaDataImpl createBeanMetaDataImpl() {
                return newOutsideSqlCustomizeBeanMetaDataImpl();
            }
        };
        originalBmdFactory.setAnnotationReaderFactory(this.annotationReaderFactory);
        originalBmdFactory.setPropertyTypeFactoryBuilder(newOutsideSqlPropertyTypeFactoryBuilderImpl());
        originalBmdFactory.setRelationPropertyTypeFactoryBuilder(this.relationPropertyTypeFactoryBuilder);
        originalBmdFactory.setTableNaming(this.tableNaming);
        originalBmdFactory.setDataSource(this.dataSource);
        originalBmdFactory.setDaoNamingConvention(this.daoNamingConvention);
        originalBmdFactory.setBeanEnhancer(this.beanEnhancer);
        return originalBmdFactory;
    }

    protected BeanMetaDataImpl newOutsideSqlCustomizeBeanMetaDataImpl() {
        return new OutsideSqlCustomizeBeanMetaDataImpl();
    }

    protected static class OutsideSqlCustomizeBeanMetaDataImpl extends BeanMetaDataImpl {
    }

    protected PropertyTypeFactoryBuilderImpl newOutsideSqlPropertyTypeFactoryBuilderImpl() {
        final PropertyTypeFactoryBuilderImpl impl = new OutsideSqlPropertyTypeFactoryBuilderImpl();
        if (columnNaming == null) {
            String msg = "Internal Error! The columnNaming should not be null! {Failed to Injection!}";
            throw new IllegalStateException(msg);
        }
        impl.setColumnNaming(columnNaming);
        impl.setDaoNamingConvention(daoNamingConvention);
        impl.setValueTypeFactory(valueTypeFactory);
        return impl;
    }

    protected static class OutsideSqlPropertyTypeFactoryBuilderImpl extends PropertyTypeFactoryBuilderImpl {
        @Override
        public PropertyTypeFactory build(Class beanClass, BeanAnnotationReader beanAnnotationReader, Dbms dbms, DatabaseMetaData databaseMetaData) {
            return new PropertyTypeFactoryImpl(beanClass, beanAnnotationReader, valueTypeFactory, columnNaming, dbms, databaseMetaData) {
                @Override
                protected void setupPrimaryKey(PropertyType[] propertyTypes, String tableName) {
                    try {
                        super.setupPrimaryKey(propertyTypes, tableName);
                    } catch (RuntimeException e) {
                        // Nothing because MySQL throws Exception when the table does not exist.
                    }
                }
            };
        }
    }

    protected Class getOutsideSqlDefaultBeanClass(Method method) {
        final Class retType = method.getReturnType();
        if (java.util.List.class.isAssignableFrom(retType)) {
            final Class elementType = InternalMethodUtil.getElementTypeOfListFromReturnMethod(method);
            if (elementType != null) {
                return elementType;
            } else {
                return getBeanClass();
            }
        } else if (retType.isArray()) {
            return retType.getComponentType();
        } else if (retType.isPrimitive() || !ValueTypes.getValueType(retType).equals(ValueTypes.OBJECT)) {
            return getBeanClass();
        } else {
            return retType;
        }
    }

    // ===================================================================================
    //                                                                       Vert Internal
    //                                                                       =============
    protected static class InternalMethodUtil {
        public static Class getElementTypeOfListFromReturnMethod(Method method) {
            return InternalReflectionUtil.getElementTypeOfListFromReturnType(method);
        }
    }

    protected static class InternalReflectionUtil {
        public static Class<?> getElementTypeOfList(final Type parameterizedList) {
            if (!(parameterizedList instanceof ParameterizedType)) {
                return null;
            }

            final ParameterizedType parameterizedType = ParameterizedType.class.cast(parameterizedList);
            final Type rawType = parameterizedType.getRawType();
            if (!(rawType instanceof Class)) {
                return null;
            }

            final Class<?> rawClass = Class.class.cast(rawType);
            if (!rawClass.isAssignableFrom(List.class)) {
                return null;
            }

            final Type[] actualTypeArgument = parameterizedType.getActualTypeArguments();
            if (actualTypeArgument == null || actualTypeArgument.length != 1) {
                return null;
            }
            if (!(actualTypeArgument[0] instanceof Class)) {
                return null;
            }

            return Class.class.cast(actualTypeArgument[0]);
        }

        public static Class<?> getElementTypeOfListFromParameterType(final Method method, final int parameterPosition) {
            final Type[] parameterTypes = method.getGenericParameterTypes();
            return getElementTypeOfList(parameterTypes[parameterPosition]);
        }

        public static Class<?> getElementTypeOfListFromReturnType(final Method method) {
            return getElementTypeOfList(method.getGenericReturnType());
        }
    }

    // ===================================================================================
    //                                               ResultSetHandlerFactoryImpl Extension
    //                                               =====================================
    public static class ResultSetHandlerFactoryExtension extends org.seasar.dao.impl.ResultSetHandlerFactoryImpl {
        public ResultSetHandlerFactoryExtension() {
            super();
        }
        protected RelationRowCreator createRelationRowCreator() {
            return new RelationRowCreatorExtension();
        }
    }

    // ===================================================================================
    //                                                    RelationRowCreatorImpl Extension
    //                                                    ================================
    public static class RelationRowCreatorExtension extends org.seasar.dao.impl.RelationRowCreatorImpl {
        protected boolean isTargetProperty(org.seasar.dao.impl.RelationRowCreationResource res) throws java.sql.SQLException {
            final PropertyType pt = res.getCurrentPropertyType();
            if (!pt.getPropertyDesc().hasWriteMethod()) {
                return false;
            }
            if (java.util.List.class.isAssignableFrom(pt.getPropertyDesc().getPropertyType())) {
                return false;
            }
            return true;
        }

        protected boolean isCreateDeadLink() {
            return false;
        }

        protected int getLimitRelationNestLevel() {
            return 2;
        }
    }

    // ===================================================================================
    //                                                                   Sql File Encoding
    //                                                                   =================
    public String getSqlFileEncoding() {
        return sqlFileEncoding;
    }

    // ===================================================================================
    //                                                                       Bean Enhancer
    //                                                                       =============
    public BeanEnhancer getBeanEnhancer() {
        return beanEnhancer;
    }

    public void setBeanEnhancer(final BeanEnhancer beanEnhancer) {
        this.beanEnhancer = beanEnhancer;
    }

    // ===================================================================================
    //                                                           Annotation Reader Factory
    //                                                           =========================
    public void setAnnotationReaderFactory(org.seasar.dao.AnnotationReaderFactory annotationReaderFactory) {
        this.annotationReaderFactory = annotationReaderFactory;
    }

    // ===================================================================================
    //                                                                Version After 1.0.47
    //                                                                ====================
    public ColumnNaming getColumnNaming() {
        return columnNaming;
    }

    public void setColumnNaming(final ColumnNaming columnNaming) {
        this.columnNaming = columnNaming;
    }

    public PropertyTypeFactoryBuilder getPropertyTypeFactoryBuilder() {
        return propertyTypeFactoryBuilder;
    }

    public void setPropertyTypeFactoryBuilder(final PropertyTypeFactoryBuilder propertyTypeFactoryBuilder) {
        this.propertyTypeFactoryBuilder = propertyTypeFactoryBuilder;
    }

    public RelationPropertyTypeFactoryBuilder getRelationPropertyTypeFactoryBuilder() {
        return relationPropertyTypeFactoryBuilder;
    }

    public void setRelationPropertyTypeFactoryBuilder(final RelationPropertyTypeFactoryBuilder relationPropertyTypeFactoryBuilder) {
        this.relationPropertyTypeFactoryBuilder = relationPropertyTypeFactoryBuilder;
    }

    public TableNaming getTableNaming() {
        return tableNaming;
    }

    public void setTableNaming(final TableNaming tableNaming) {
        this.tableNaming = tableNaming;
    }

}
