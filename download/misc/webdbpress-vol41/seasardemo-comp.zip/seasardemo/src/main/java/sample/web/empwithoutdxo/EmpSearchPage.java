package sample.web.empwithoutdxo;

import java.util.Date;

public class EmpSearchPage extends AbstractEmpPage {

	public String condEmpName;

	public Date condFromHireDate;

	public Date condToHireDate;

	
	public Class doSearch() {
		return EmpListPage.class;
	}

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		return null;
	}

}
