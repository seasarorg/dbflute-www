package sample.web.emp;

import java.util.Date;

public class EmpDto {

	public Integer id;

	public String deptName;

	public Date hireDate;

	public String empName;
}
