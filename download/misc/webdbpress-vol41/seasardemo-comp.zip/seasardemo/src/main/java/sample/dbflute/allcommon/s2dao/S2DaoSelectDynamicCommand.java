package sample.dbflute.allcommon.s2dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.sql.DataSource;

import org.seasar.dao.CommandContext;
import org.seasar.dao.EndCommentNotFoundRuntimeException;
import org.seasar.dao.IfConditionNotFoundRuntimeException;
import org.seasar.dao.Node;
import org.seasar.dao.SqlParser;
import org.seasar.dao.SqlTokenizer;
import org.seasar.dao.impl.SelectDynamicCommand;
import org.seasar.dao.node.BeginNode;
import org.seasar.dao.node.BindVariableNode;
import org.seasar.dao.node.ContainerNode;
import org.seasar.dao.node.ElseNode;
import org.seasar.dao.node.EmbeddedValueNode;
import org.seasar.dao.node.IfNode;
import org.seasar.dao.node.ParenBindVariableNode;
import org.seasar.dao.node.PrefixSqlNode;
import org.seasar.dao.node.SqlNode;
import org.seasar.dao.parser.SqlTokenizerImpl;
import org.seasar.extension.jdbc.ResultSetFactory;
import org.seasar.extension.jdbc.ResultSetHandler;
import org.seasar.extension.jdbc.StatementFactory;
import org.seasar.extension.jdbc.ValueType;
import org.seasar.extension.jdbc.impl.BasicSelectHandler;
import org.seasar.extension.jdbc.types.ValueTypes;
import org.seasar.framework.beans.BeanDesc;
import org.seasar.framework.beans.PropertyDesc;
import org.seasar.framework.beans.factory.BeanDescFactory;
import org.seasar.framework.exception.SQLRuntimeException;
import org.seasar.framework.util.StringUtil;

import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.cbean.ConditionBeanContext;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;

/**
 * SelectDynamicCommand for DBFlute.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class S2DaoSelectDynamicCommand extends SelectDynamicCommand {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Root node. */
    protected Node rootNode;// Override!

    /** Result-set handler. */
    protected ResultSetHandler resultSetHandler;

    /** Result-set factory. */
    protected ResultSetFactory resultSetFactory;

    /** Cache of select clause command. */
    protected S2DaoSelectDynamicCommand _selectClauseCommand;

    /** Cache of select clause PK-only command. */
    protected S2DaoSelectDynamicCommand _selectClausePKOnlyCommand;

    /** DBFlute does not use this class! */
    protected org.seasar.dao.pager.PagingSqlRewriter pagingSqlRewriter;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param dataSource Data source.
     * @param statementFactory Statement factory.
     * @param resultSetHandler Result-set handler.
     * @param resultSetFactory Result-set factory.
     */
    public S2DaoSelectDynamicCommand(DataSource dataSource,
            StatementFactory statementFactory,
            ResultSetHandler resultSetHandler, ResultSetFactory resultSetFactory) {
        this(dataSource, statementFactory, resultSetHandler, resultSetFactory, null);
    }

    /**
     * Constructor.
     * 
     * @param dataSource Data source.
     * @param statementFactory Statement factory.
     * @param resultSetHandler Result-set handler.
     * @param resultSetFactory Result-set factory.
     * @param pagingSqlRewriter Paging sql rewriter.
     */
    public S2DaoSelectDynamicCommand(DataSource dataSource,
            StatementFactory statementFactory,
            ResultSetHandler resultSetHandler, ResultSetFactory resultSetFactory, org.seasar.dao.pager.PagingSqlRewriter pagingSqlRewriter) {
        super(dataSource, statementFactory, resultSetHandler, resultSetFactory, pagingSqlRewriter);
        this.resultSetHandler = resultSetHandler;
        this.resultSetFactory = resultSetFactory;
        this.pagingSqlRewriter = pagingSqlRewriter;
    }

    // ===================================================================================
    //                                                                                Main
    //                                                                                ====
    // -----------------------------------------------------
    //                               Very Important Override
    //                               -----------------------
    /**
     * The override for extension.
     * 
     * @param sql SQL. (NotNull)
     */
    @Override()
    public void setSql(String sql) {// Override!
        super.setSql(sql);
        this.rootNode = new InternalSqlParserImpl(sql).parse();// Use internal sql parser.
    }

    /**
     * The override for extension.
     * 
     * @param args The array of argument. (NotNull)
     */
    @Override()
    protected CommandContext apply(Object[] args) {// Override!
        CommandContext ctx = createCommandContext(args);
        rootNode.accept(ctx);
        return ctx;
    }

    /**
     * The override for extension.
     * 
     * @param argNames The array of argument name. (NotNull)
     */
    @Override()
    public void setArgNames(String[] argNames) {
        if (_selectClauseCommand != null) {
            _selectClauseCommand.setArgNames(argNames);
        }
        if (_selectClausePKOnlyCommand != null) {
            _selectClausePKOnlyCommand.setArgNames(argNames);
        }
        super.setArgNames(argNames);
    }

    /**
     * The override for extension.
     * 
     * @param argTypes The array of argument type. (NotNull)
     */
    @Override()
    public void setArgTypes(Class[] argTypes) {
        if (_selectClauseCommand != null) {
            _selectClauseCommand.setArgTypes(argTypes);
        }
        if (_selectClausePKOnlyCommand != null) {
            _selectClausePKOnlyCommand.setArgTypes(argTypes);
        }
        super.setArgTypes(argTypes);
    }

    // -----------------------------------------------------
    //                                            For Public
    //                                            ----------
    /**
     * Do apply as public. {for delegating to apply()}
     * 
     * @param args Arguments. (NotNull)
     * @return Command context. (NotNull)
     */
    public CommandContext doApply(Object[] args) {
        return apply(args);
    }

    // -----------------------------------------------------
    //                                         Select Clause
    //                                         -------------
    /**
     * Set select clause.
     * 
     * @param value Select clause. (Nullable)
     * @return this. (NotNull)
     */
    public S2DaoSelectDynamicCommand setSelectClause(String value) {
        _selectClauseCommand = createMySelectDynamicCommand();
        _selectClauseCommand.setSql(value);
        return this;
    }

    /**
     * Set select clause PK only.
     * 
     * @param value Select clause PK only. (Nullable)
     * @return this. (NotNull)
     */
    public S2DaoSelectDynamicCommand setSelectClausePKOnly(String value) {
        _selectClausePKOnlyCommand = createMySelectDynamicCommand();
        _selectClausePKOnlyCommand.setSql(value);
        return this;
    }

    // -----------------------------------------------------
    //                         SelectDynamicCommand Creation
    //                         -----------------------------
    protected S2DaoSelectDynamicCommand createMySelectDynamicCommand() {
        return new S2DaoSelectDynamicCommand(getDataSource(), getStatementFactory(), resultSetHandler, resultSetFactory);
    }

    // -----------------------------------------------------
    //                                               Execute
    //                                               -------
    /**
     * The override for extension.
     * 
     * @param args The array of argument. (Nullable)
     * @return Result. (Nullable)
     */
    @Override()
    public Object execute(Object[] args) {
        if (!ConditionBeanContext.isExistConditionBeanOnThread()) {
            if (sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext.isExistOutsideSqlContextOnThread()) {
                final sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext outsideSqlContext = sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext.getOutsideSqlContextOnThread();
                if (!outsideSqlContext.isDynamicAnalysis() || args == null || args.length == 0 || args[0] == null) {
                    return doDefaulExecute(args);
                }
                return executeOutsideSql(args, outsideSqlContext);
            }
            return doDefaulExecute(args);
        }
        assertSelectClauseCommand();
        final List<Object> bindVariableList = new ArrayList<Object>();
        final List<Class> bindVariableTypeList = new ArrayList<Class>();

        final ConditionBean cb = ConditionBeanContext.getConditionBeanOnThread();
        final String finalClause;
        if (cb.hasUnionQueryOrUnionAllQuery()) {
            final String selectClause = setupRealSelectClause(args, bindVariableList, bindVariableTypeList);
            final String fromWhereClause = setupRealFromWhereClause(args, bindVariableList, bindVariableTypeList);
            if (cb.isSelectCountIgnoreFetchScope()) {
                // If the query uses union and it selects count, the way of select-count is as follows.
                // (Then it needs included-select-column)
                finalClause = "select count(*) from (" + InternalStringUtil.replace(fromWhereClause, SqlClause.INCLUDE_SELECT_CLAUSE_MARK, selectClause) + ") base";
            } else {
                finalClause = InternalStringUtil.replace(fromWhereClause, SqlClause.INCLUDE_SELECT_CLAUSE_MARK, selectClause);
            }
        } else {
            final String selectClause;
            if (cb.isSelectCountIgnoreFetchScope()) {
                selectClause = "select count(*)";
            } else {
                selectClause = setupRealSelectClause(args, bindVariableList, bindVariableTypeList);
            }
            final String fromWhereClause = setupRealFromWhereClause(args, bindVariableList, bindVariableTypeList);
            finalClause = InternalStringUtil.replace(fromWhereClause, SqlClause.INCLUDE_SELECT_CLAUSE_MARK, selectClause);
        }

        final BasicSelectHandler selectHandler = createBasicSelectHandler(finalClause, this.resultSetHandler);
        return selectHandler.execute(bindVariableList.toArray(), toClassArray(bindVariableTypeList));
    }

    protected Object doDefaulExecute(Object args[]) {
        // Supports SpecifiedResultSetHandler
        final ResultSetHandler specifiedResultSetHandler = findSpecifiedResultSetHandler(args);
        final Object[] filteredArgs = filterArgumentsForResultSetHandler(args);

        final org.seasar.dao.CommandContext ctx = apply(filteredArgs);
        final BasicSelectHandler selectHandler = createBasicSelectHandler(ctx.getSql(), specifiedResultSetHandler);
        return selectHandler.execute(ctx.getBindVariables(), ctx.getBindVariableTypes());
    }

    // -----------------------------------------------------
    //                                           Outside-Sql
    //                                           -----------
    protected Object executeOutsideSql(Object[] args, sample.dbflute.allcommon.cbean.outsidesql.OutsideSqlContext outsideSqlContext) {
        final Object firstArg = args[0];
        final org.seasar.framework.beans.BeanDesc beanDesc = org.seasar.framework.beans.factory.BeanDescFactory.getBeanDesc(firstArg.getClass());
        String filteredSql = getSql();
        for (int i = 0; i < beanDesc.getPropertyDescSize(); i++) {
            final PropertyDesc propertyDesc = beanDesc.getPropertyDesc(i);
            final Class propertyType = propertyDesc.getPropertyType();
            if (!propertyType.equals(String.class)) {
                continue;
            }
            final String outsideSqlPiece = (String) propertyDesc.getValue(firstArg);
            if (outsideSqlPiece == null) {
                continue;
            }
            final String embeddedComment = "/*$pmb." + propertyDesc.getPropertyName() + "*/";
            filteredSql = InternalStringUtil.replace(filteredSql, embeddedComment, outsideSqlPiece);
        }
        final S2DaoSelectDynamicCommand outsideSqlCommand = createMySelectDynamicCommand();
        outsideSqlCommand.setArgNames(getArgNames());
        outsideSqlCommand.setArgTypes(getArgTypes());
        outsideSqlCommand.setSql(filteredSql);

        // Supports SpecifiedResultSetHandler
        final ResultSetHandler specifiedResultSetHandler = findSpecifiedResultSetHandler(args);
        final Object[] filteredArgs = filterArgumentsForResultSetHandler(args);

        final org.seasar.dao.CommandContext ctx = outsideSqlCommand.doApply(filteredArgs);
        final java.util.List<Object> bindVariableList = new java.util.ArrayList<Object>();
        final java.util.List<Class> bindVariableTypeList = new java.util.ArrayList<Class>();
        addBindVariableInfo(ctx, bindVariableList, bindVariableTypeList);
        final BasicSelectHandler selectHandler = createBasicSelectHandler(ctx.getSql(), specifiedResultSetHandler);
        return selectHandler.execute(bindVariableList.toArray(), toClassArray(bindVariableTypeList));
    }

    protected Object[] filterArgumentsForResultSetHandler(Object[] args) {
        if (args == null || args.length == 0) {
            return args;
        }
        final Object[] filteredArgs;
        if (args[args.length - 1] instanceof sample.dbflute.allcommon.jdbc.CursorHandler) {
            filteredArgs = new Object[args.length - 1];
            for (int i=0; i < args.length - 1; i++) {
                filteredArgs[i] = args[i];
            }
        } else {
            filteredArgs = args;
        }
        return filteredArgs;
    }

    protected ResultSetHandler findSpecifiedResultSetHandler(Object[] args) {
        if (args == null || args.length == 0) {
            return this.resultSetHandler;
        }
        if (args[args.length-1] instanceof sample.dbflute.allcommon.jdbc.CursorHandler) {
            final sample.dbflute.allcommon.jdbc.CursorHandler cursorHandler = (sample.dbflute.allcommon.jdbc.CursorHandler)args[args.length-1];
            return new ResultSetHandler() { public Object handle(java.sql.ResultSet rs) throws java.sql.SQLException { return cursorHandler.handle(rs); } };
        }
        if (getArgTypes().length+1 == args.length && args[args.length-1] == null) {
            String msg = "System Level Exception!" + getLineSeparator();
            msg = msg + "/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *" + getLineSeparator();
            msg = msg + "The size of arg types have not been same as the size of arg objects:";
            msg = msg + " argTypes=" + getArgTypes().length + " args=" + args.length + getLineSeparator();
            msg = msg + "If the arguments contain ResultSetHandler, the argument value should not be null!" + getLineSeparator();
            for (int i=0; i < args.length - 1; i++) {
                msg = msg + "  args[" + i + "] -- " + args[i] + getLineSeparator();
            }
            msg = msg + "* * * * * * * * * */" + getLineSeparator();
            throw new IllegalStateException(msg);
        }
        return this.resultSetHandler;
    }

    // -----------------------------------------------------
    //                                          Setup Clause
    //                                          ------------
    protected String setupRealSelectClause(Object[] args, List<Object> bindVariableList, List<Class> bindVariableTypeList) {
        final ConditionBean cb = ConditionBeanContext.getConditionBeanOnThread();
        final String realSelectClause;
        {
            final CommandContext ctx;
            if (cb.isLimitSelect_PKOnly()) {
                ctx = _selectClausePKOnlyCommand.doApply(args);
            } else {
                ctx = _selectClauseCommand.doApply(args);
            }
            realSelectClause = ctx.getSql();
            addBindVariableInfo(ctx, bindVariableList, bindVariableTypeList);
        }
        return realSelectClause;
    }

    protected String setupRealFromWhereClause(Object[] args, java.util.List<Object> bindVariableList, List<Class> bindVariableTypeList) {
        final ConditionBean cb = ConditionBeanContext.getConditionBeanOnThread();
        final String realFromWhereClause;
        {
            final S2DaoSelectDynamicCommand fromWhereCommand = createMySelectDynamicCommand();
            fromWhereCommand.setArgNames(getArgNames());
            fromWhereCommand.setArgTypes(getArgTypes());

            // for Union
            cb.getSqlClause().setSelectClauseColumnAliasMap(ConditionBeanContext.getSelectClauseColumnAliasMap(cb.getClass()));

            fromWhereCommand.setSql(cb.getSqlClause().getClause());
            final CommandContext ctx = fromWhereCommand.doApply(args);
            realFromWhereClause = ctx.getSql();
            addBindVariableInfo(ctx, bindVariableList, bindVariableTypeList);
        }
        return realFromWhereClause;
    }

    protected BasicSelectHandler createBasicSelectHandler(String realSql, ResultSetHandler specifiedResultSetHandler) {
        final BasicSelectHandler selectHandler = newBasicSelectHandler(realSql, specifiedResultSetHandler, getStatementFactory(), resultSetFactory);
        selectHandler.setFetchSize(-1);
        return selectHandler;
    }

    protected BasicSelectHandler newBasicSelectHandler(String sql, ResultSetHandler resultSetHandler, StatementFactory statementFactory, ResultSetFactory resultSetFactory) {
        return new BasicSelectHandler(getDataSource(), sql, resultSetHandler, statementFactory, resultSetFactory) {
            @Override
            protected void bindArgs(java.sql.PreparedStatement ps, Object[] args, Class[] argTypes) {
                if (args == null) {
                    return;
                }
                for (int i = 0; i < args.length; ++i) {
                    final ValueType valueType = findValueType(argTypes[i], args[i]);
                    try {
                        valueType.bindValue(ps, i + 1, args[i]);
                    } catch (java.sql.SQLException ex) {
                        throw new SQLRuntimeException(ex);
                    }
                }
            }
            protected ValueType findValueType(Class argType, Object arg) {
                ValueType valueType = ValueTypes.getValueType(arg);
                if (valueType != null) {
                    return valueType;
                }
                valueType = ValueTypes.getValueType(argType);
                if (valueType != null) {
                    return valueType;
                }
                String msg = "Unknown type：argType=" + argType + " args=" + arg;
                throw new IllegalStateException(msg);
            }
        };
    }

    protected Class[] toClassArray(List<Class> bindVariableTypeList) {
        final Class[] bindVariableTypesArray = new Class[bindVariableTypeList.size()];
        for (int i = 0; i < bindVariableTypeList.size(); i++) {
            final Class bindVariableType = (Class) bindVariableTypeList.get(i);
            bindVariableTypesArray[i] = bindVariableType;
        }
        return bindVariableTypesArray;
    }

    protected void addBindVariableInfo(CommandContext ctx, List<Object> bindVariableList, List<Class> bindVariableTypeList) {
        final Object[] bindVariables = ctx.getBindVariables();
        addBindVariableList(bindVariableList, bindVariables);
        final Class[] bindVariableTypes = ctx.getBindVariableTypes();
        addBindVariableTypeList(bindVariableTypeList, bindVariableTypes);
    }

    protected void addBindVariableList(List<Object> bindVariableList, Object[] bindVariables) {
        for (int i=0; i < bindVariables.length; i++) {
            bindVariableList.add(bindVariables[i]);
        }
    }

    protected void addBindVariableTypeList(List<Class> bindVariableTypeList, Class[] bindVariableTypes) {
        for (int i=0; i < bindVariableTypes.length; i++) {
            bindVariableTypeList.add(bindVariableTypes[i]);
        }
    }

    protected void assertSelectClauseCommand() {
        if (_selectClauseCommand == null) {
            String msg = "Select clause command should not be null.";
            throw new IllegalStateException(msg);
        }
    }

    /**
     * Get the value of line separator.
     * 
     * @return The value of line separator. (NotNull)
     */
    protected String getLineSeparator() {
        return System.getProperty("line.separator");
    }

    // =====================================================================================
    //                                                                 Internal Static Class
    //                                                                 =====================
    // --------------------------------------
    //                              SqlParser
    //                              ---------
    protected static class InternalSqlParserImpl implements SqlParser {

        private SqlTokenizer tokenizer;

        private Stack nodeStack = new Stack();

        public InternalSqlParserImpl(String sql) {
            sql = sql.trim();
            if (sql.endsWith(";")) {
                sql = sql.substring(0, sql.length() - 1);
            }
            tokenizer = new SqlTokenizerImpl(sql);
        }

        public Node parse() {
            push(new ContainerNode());
            while (SqlTokenizer.EOF != tokenizer.next()) {
                parseToken();
            }
            return pop();
        }

        protected void parseToken() {
            switch (tokenizer.getTokenType()) {
            case SqlTokenizer.SQL:
                parseSql();
                break;
            case SqlTokenizer.COMMENT:
                parseComment();
                break;
            case SqlTokenizer.ELSE:
                parseElse();
                break;
            case SqlTokenizer.BIND_VARIABLE:
                parseBindVariable();
                break;
            }
        }

        protected void parseSql() {
            String sql = tokenizer.getToken();
            if (isElseMode()) {
                sql = StringUtil.replace(sql, "--", "");
            }
            Node node = peek();
            if ((node instanceof IfNode || node instanceof ElseNode) && node.getChildSize() == 0) {

                SqlTokenizer st = new SqlTokenizerImpl(sql);
                st.skipWhitespace();
                String token = st.skipToken();
                st.skipWhitespace();
                if (sql.startsWith(",")) {
                    if (sql.startsWith(", ")) {
                        node.addChild(new PrefixSqlNode(", ", sql.substring(2)));
                    } else {
                        node.addChild(new PrefixSqlNode(",", sql.substring(1)));
                    }
                } else if ("AND".equalsIgnoreCase(token) || "OR".equalsIgnoreCase(token)) {
                    node.addChild(new PrefixSqlNode(st.getBefore(), st.getAfter()));
                } else {
                    node.addChild(new SqlNode(sql));
                }
            } else {
                node.addChild(new SqlNode(sql));
            }
        }

        protected void parseComment() {
            String comment = tokenizer.getToken();
            if (isTargetComment(comment)) {
                if (isIfComment(comment)) {
                    parseIf();
                } else if (isBeginComment(comment)) {
                    parseBegin();
                } else if (isEndComment(comment)) {
                    return;
                } else {
                    parseCommentBindVariable();
                }
            } else if (comment != null && 0 < comment.length()) {
                String before = tokenizer.getBefore();
                peek().addChild(new SqlNode(before.substring(before.lastIndexOf("/*"))));
            }
        }

        protected void parseIf() {
            String condition = tokenizer.getToken().substring(2).trim();
            if (StringUtil.isEmpty(condition)) {
                throw new IfConditionNotFoundRuntimeException();
            }
            IfNode ifNode = new IfNode(condition);
            peek().addChild(ifNode);
            push(ifNode);
            parseEnd();
        }

        protected void parseBegin() {
            BeginNode beginNode = new BeginNode();
            peek().addChild(beginNode);
            push(beginNode);
            parseEnd();
        }

        protected void parseEnd() {
            while (SqlTokenizer.EOF != tokenizer.next()) {
                if (tokenizer.getTokenType() == SqlTokenizer.COMMENT && isEndComment(tokenizer.getToken())) {

                    pop();
                    return;
                }
                parseToken();
            }
            throw new EndCommentNotFoundRuntimeException();
        }

        protected void parseElse() {
            Node parent = peek();
            if (!(parent instanceof IfNode)) {
                return;
            }
            IfNode ifNode = (IfNode) pop();
            ElseNode elseNode = new ElseNode();
            ifNode.setElseNode(elseNode);
            push(elseNode);
            tokenizer.skipWhitespace();
        }

        protected void parseCommentBindVariable() {
            String expr = tokenizer.getToken();
            String s = tokenizer.skipToken();
            if (s.startsWith("(") && s.endsWith(")")) {
                peek().addChild(new ParenBindVariableNode(expr));
            } else if (expr.startsWith("$")) {
                peek().addChild(new InternalEmbeddedValueNode(expr.substring(1)));
            } else {
                peek().addChild(new InternalBindVariableNode(expr));// Extension!
            }
        }

        protected void parseBindVariable() {
            String expr = tokenizer.getToken();
            peek().addChild(new InternalBindVariableNode(expr));// Extension!
        }

        protected Node pop() {
            return (Node) nodeStack.pop();
        }

        protected Node peek() {
            return (Node) nodeStack.peek();
        }

        protected void push(Node node) {
            nodeStack.push(node);
        }

        protected boolean isElseMode() {
            for (int i = 0; i < nodeStack.size(); ++i) {
                if (nodeStack.get(i) instanceof ElseNode) {
                    return true;
                }
            }
            return false;
        }

        private static boolean isTargetComment(String comment) {
            return comment != null && comment.length() > 0 && Character.isJavaIdentifierStart(comment.charAt(0));
        }

        private static boolean isIfComment(String comment) {
            return comment.startsWith("IF");
        }

        private static boolean isBeginComment(String content) {
            return content != null && "BEGIN".equals(content);
        }

        private static boolean isEndComment(String content) {
            return content != null && "END".equals(content);
        }
    }

    // --------------------------------------
    //                       BindVariableNode
    //                       ----------------
    protected static class InternalBindVariableNode extends BindVariableNode {
        private String expression;

        private String[] names;

        public InternalBindVariableNode(String expression) {
            super(expression);
            
            this.expression = expression;
            names = StringUtil.split(expression, ".");
            // baseName_ = array[0];
            // if (array.length > 1) {
            // propertyName_ = array[1];
            // }
        }

        public String getExpression() {
            return expression;
        }

        public void accept(CommandContext ctx) {
            Object value = ctx.getArg(names[0]);
            Class clazz = ctx.getArgType(names[0]);
            for (int pos = 1; pos < names.length; pos++) {
                if (value == null) {
                    break;
                }
                if (java.util.Map.class.isInstance(value)) {// Extension!
                    final java.util.Map map = (java.util.Map) value;
                    value = map.get(names[pos]);
                    if (value == null) {
                        break;
                    }
                    clazz = value.getClass();
                    continue;
                }
                final org.seasar.framework.beans.BeanDesc beanDesc = org.seasar.framework.beans.factory.BeanDescFactory.getBeanDesc(clazz);
                final String currentName = names[pos];
                if (beanDesc.hasPropertyDesc(currentName)) {
                    PropertyDesc pd = beanDesc.getPropertyDesc(currentName);
                    value = pd.getValue(value);
                    clazz = pd.getPropertyType();
                    continue;
                }
                final String methodName = "get" + initCap(currentName);
                if (beanDesc.hasMethod(methodName)) {
                    final java.lang.reflect.Method method = beanDesc.getMethod(methodName);
                    value = invokeGetter(method, value);
                    clazz = method.getReturnType();
                    continue;
                }
                String msg = "Not found property: currentName=" + currentName + " class=" + clazz;
                throw new IllegalStateException(msg);
            }
            ctx.addSql("?", value, clazz);
        }

        protected String initCap(String name) {
            return name.substring(0, 1).toUpperCase() + name.substring(1);
        }

        protected Object invokeGetter(java.lang.reflect.Method method, Object target) {
            try {
                return method.invoke(target, (Object[]) null);
            } catch (IllegalArgumentException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            } catch (java.lang.reflect.InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        }
    }

    // --------------------------------------
    //                      EmbeddedValueNode
    //                      -----------------
    protected static class InternalEmbeddedValueNode extends EmbeddedValueNode {
        private String expression;

        private String[] names;

        public InternalEmbeddedValueNode(String expression) {
            super(expression);

            this.expression = expression;
            names = StringUtil.split(expression, ".");
            // this.baseName = array[0];
            // if (array.length > 1) {
            //     this.propertyName = array[1];
            // }
        }

        public String getExpression() {
            return expression;
        }

        /**
         * @see org.seasar.dao.Node#accept(org.seasar.dao.QueryContext)
         */
        public void accept(CommandContext ctx) {
            Object value = ctx.getArg(names[0]);
            Class clazz = ctx.getArgType(names[0]);
            for (int pos = 1; pos < names.length; pos++) {
                if (value == null) {
                    break;
                }
                if (java.util.Map.class.isInstance(value)) {// Extension!
                    final java.util.Map map = (java.util.Map) value;
                    value = map.get(names[pos]);
                    if (value == null) {
                        break;
                    }
                    clazz = value.getClass();
                } else {
                    BeanDesc beanDesc = BeanDescFactory.getBeanDesc(clazz);
                    PropertyDesc pd = beanDesc.getPropertyDesc(names[pos]);
                    value = pd.getValue(value);
                    clazz = pd.getPropertyType();
                }
            }
            if (value != null && value.toString().indexOf("?") > -1) {
                throw new org.seasar.framework.exception.SRuntimeException("EDAO0023");
            }
            ctx.addSql(value != null ? value.toString() : null);
        }
    }

    // --------------------------------------
    //                             StringUtil
    //                             ----------
    protected static class InternalStringUtil {

        public static final String[] EMPTY_STRINGS = new String[0];

        private InternalStringUtil() {
        }

        public static final boolean isEmpty(String text) {
            return text == null || text.length() == 0;
        }

        public static final String replace(String text, String fromText,  String toText) {
            if (text == null || fromText == null || toText == null) {
                return null;
            }
            StringBuffer buf = new StringBuffer(100);
            int pos = 0;
            int pos2 = 0;
            while (true) {
                pos = text.indexOf(fromText, pos2);
                if (pos == 0) {
                    buf.append(toText);
                    pos2 = fromText.length();
                } else if (pos > 0) {
                    buf.append(text.substring(pos2, pos));
                    buf.append(toText);
                    pos2 = pos + fromText.length();
                } else {
                    buf.append(text.substring(pos2));
                    break;
                }
            }
            return buf.toString();
        }

        public static String[] split(String str, String delim) {
            if (str == null) {
                return EMPTY_STRINGS;
            }
            java.util.List<String> list = new java.util.ArrayList<String>();
            java.util.StringTokenizer st = new java.util.StringTokenizer(str, delim);
            while (st.hasMoreElements()) {
                list.add(st.nextToken());
            }
            return (String[]) list.toArray(new String[list.size()]);
        }
    }
}