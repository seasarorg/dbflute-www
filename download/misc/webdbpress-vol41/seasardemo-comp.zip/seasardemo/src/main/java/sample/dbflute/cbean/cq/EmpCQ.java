package sample.dbflute.cbean.cq;


import sample.dbflute.allcommon.cbean.ConditionQuery;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;
import sample.dbflute.cbean.cq.bs.BsEmpCQ;

/**
 * The condition-query of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class EmpCQ extends BsEmpCQ {

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public EmpCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }
}
