package sample.dbflute.allcommon.bhv;


import sample.dbflute.allcommon.BehaviorSelector;
import sample.dbflute.allcommon.DaoSelector;
import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.bhv.setup.ValueLabelSetupper;
import sample.dbflute.allcommon.bhv.setup.ValueLabelBox;
import sample.dbflute.allcommon.cbean.ConditionBean;
import sample.dbflute.allcommon.cbean.ListResultBean;
import sample.dbflute.allcommon.cbean.PagingBean;
import sample.dbflute.allcommon.cbean.PagingResultBean;

import sample.dbflute.allcommon.bhv.batch.TokenFileOutputOption;
import sample.dbflute.allcommon.bhv.batch.TokenFileOutputResult;

import sample.dbflute.allcommon.dbmeta.info.ColumnInfo;

import sample.dbflute.allcommon.helper.token.file.FileMakingOption;
import sample.dbflute.allcommon.helper.token.file.FileMakingHeaderInfo;
import sample.dbflute.allcommon.helper.token.file.FileMakingSimpleFacade;
import sample.dbflute.allcommon.helper.token.file.impl.FileMakingSimpleFacadeImpl;

/**
 * The abstract class of behavior-readable.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public abstract class AbstractBehaviorReadable implements BehaviorReadable {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Behavior-selector instance. */
    protected BehaviorSelector _behaviorSelector;

    /** Dao-selector instance. */
    protected DaoSelector _daoSelector;

    // ===================================================================================
    //                                                                            Selector
    //                                                                            ========
    /**
     * The implementation.
     * 
     * @return Behavior-selector.
     */
    public BehaviorSelector getBehaviorSelector() {
        return _behaviorSelector;
    }

    /**
     * The implementation.
     * 
     * @param value Behavior-selector.
     */
    public void setBehaviorSelector(BehaviorSelector value) {
        _behaviorSelector = value;
    }

    /**
     * The implementation.
     * 
     * @return Dao-selector.
     */
    public DaoSelector getDaoSelector() {
        return _daoSelector;
    }

    /**
     * The implementation.
     * 
     * @param value Dao-selector.
     */
    public void setDaoSelector(DaoSelector value) {
        _daoSelector = value;
    }

    // ===================================================================================
    //                                                                     Delegate Method
    //                                                                     ===============
    /**
     * The implementation.
     * 
     * @return All count.
     */
    protected int callGetCountAll() {
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "getCountAll", new Class[]{});
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{});
        return ((Integer)result).intValue();
    }

    /**
     * The implementation.
     * 
     * @return All list. (NotNull)
     */
    protected java.util.List<Entity> callGetListAll() {
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "getListAll", new Class[]{});
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{});
        return (java.util.List<Entity>)result;
    }

    /**
     * The implementation.
     * 
     * @param cb Condition-bean that the type is condition-bean-interface. (NotNull)
     * @return Read count. (NotNull)
     */
    protected int callReadCount(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final Class[] types = new Class[]{cb.getClass()};
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "selectCount", types);
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{cb});
        return ((Integer)result).intValue();
    }

    /**
     * The implementation.
     * 
     * @param cb Condition-bean that the type is condition-bean-interface. (NotNull)
     * @return Read entity. If the select result is zero, it returns null. (Nullable)
     */
    protected Entity callReadEntity(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final Class[] types = new Class[]{cb.getClass()};
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "selectEntity", types);
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{cb});
        return (Entity)result;
    }

    /**
     * The implementation.
     * 
     * @param cb Condition-bean that the type is condition-bean-interface. (NotNull)
     * @return Read list. If the select result is zero, it returns empty list. (NotNull)
     */
    protected java.util.List<Entity> callReadList(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final Class[] types = new Class[]{cb.getClass()};
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "selectList", types);
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{cb});
        return (java.util.List<Entity>)result;
    }

    private java.lang.reflect.Method getMethod(Class clazz, String methodName, Class[] argTypes) {
        try {
            return clazz.getMethod(methodName, argTypes);
        } catch (NoSuchMethodException ex) {
            String msg = "class=" + clazz + " method=" + methodName + "-" + java.util.Arrays.asList(argTypes);
            throw new RuntimeException(msg, ex);
        }
    }

    private Object invoke(java.lang.reflect.Method method, Object target, Object[] args) {
        try {
            return method.invoke(target, args);
        } catch (java.lang.reflect.InvocationTargetException ex) {
            Throwable t = ex.getCause();
            if (t instanceof RuntimeException) {
                throw (RuntimeException) t;
            }
            if (t instanceof Error) {
                throw (Error) t;
            }
            String msg = "target=" + target + " method=" + method + "-" + java.util.Arrays.asList(args);
            throw new RuntimeException(msg, ex);
        } catch (IllegalAccessException ex) {
            String msg = "target=" + target + " method=" + method + "-" + java.util.Arrays.asList(args);
            throw new RuntimeException(msg, ex);
        }
    }

    // =====================================================================================
    //                                                                         Basic Get All
    //                                                                         =============
    /**
     * Get count all.
     * 
     * @return Count all.
     */
    public int getCountAll() {
        return callGetCountAll();
    }

    // =====================================================================================
    //                                                                      Basic Read Count
    //                                                                      ================
    /**
     * The implementation.
     * 
     * @param cb Condition-bean. This condition-bean should not be set up about fetch-scope. (NotNull)
     * @return Read count. (NotNull)
     */
    public int readCount(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        return callReadCount(cb);
    }

    // =====================================================================================
    //                                                                     Basic Read Entity
    //                                                                     =================
    /**
     * The implementation.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read entity. (Nullalble)
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Entity readEntity(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final java.util.List<Entity> ls = readList(cb);
        if (ls.isEmpty()) {
            return null;
        }
        assertRecordHasBeenSelectedAsOne(ls, cb);
        return (Entity)ls.get(0);
    }

    /**
     * The implementation.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read entity. (NotNull)
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    public Entity readEntityWithDeletedCheck(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final java.util.List<Entity> ls = readList(cb);
        assertRecordHasNotBeenDeleted(ls, cb);
        assertRecordHasBeenSelectedAsOne(ls, cb);
        return (Entity)ls.get(0);
    }

    // =====================================================================================
    //                                                     Basic Read Entity Internal Helper
    //                                                     =================================
    protected <ENTITY_TYPE extends Entity, CB_TYPE extends ConditionBean>
            ENTITY_TYPE helpSelectEntityInternally(CB_TYPE cb, InternalSelectEntityCallback<ENTITY_TYPE, CB_TYPE> callback) {
        assertConditionBeanNotNull(cb);
        cb.checkSafetyResult(1);
        java.util.List<ENTITY_TYPE> ls = null;
        try {
            ls = callback.callbackSelectList(cb);
        } catch (sample.dbflute.allcommon.exception.DangerousResultSizeException e) {
            throwRecordHasOverlappedException("{Over safetyMaxResultSize '1'}", cb, e);
        }
        if (ls.isEmpty()) {
            return null;
        }
        assertRecordHasBeenSelectedAsOne(ls, cb);
        return (ENTITY_TYPE)ls.get(0);
    }

    protected static interface InternalSelectEntityCallback<ENTITY_TYPE extends Entity, CB_TYPE extends ConditionBean> {
        public java.util.List<ENTITY_TYPE> callbackSelectList(CB_TYPE cb);
    }

    protected <ENTITY_TYPE extends Entity, CB_TYPE extends ConditionBean>
            ENTITY_TYPE helpSelectEntityWithDeletedCheckInternally(CB_TYPE cb, InternalSelectEntityWithDeletedCheckCallback<ENTITY_TYPE, CB_TYPE> callback) {
        assertConditionBeanNotNull(cb);
        cb.checkSafetyResult(1);
        java.util.List<ENTITY_TYPE> ls = null;
        try {
            ls = callback.callbackSelectList(cb);
        } catch (sample.dbflute.allcommon.exception.DangerousResultSizeException e) {
            throwRecordHasOverlappedException("{Over safetyMaxResultSize '1'}", cb, e);
        }
        assertRecordHasNotBeenDeleted(ls, cb);
        assertRecordHasBeenSelectedAsOne(ls, cb);
        return (ENTITY_TYPE)ls.get(0);
    }

    protected static interface InternalSelectEntityWithDeletedCheckCallback<ENTITY_TYPE extends Entity, CB_TYPE extends ConditionBean> {
        public java.util.List<ENTITY_TYPE> callbackSelectList(CB_TYPE cb);
    }


    // =====================================================================================
    //                                                                       Basic Read List
    //                                                                       ===============
    /**
     * The implementation.
     * 
     * @param cb Condition-bean.
     * @return List-result-bean. If the select result is zero, it returns empty list. (NotNull)
     */
    public ListResultBean<Entity> readList(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        return new ResultBeanBuilder<Entity>(this).buildListResultBean(cb, callReadList(cb));
    }

    /**
     * The implementation.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        return readPage(cb, new SelectPageSimpleInvoker<Entity>(this));
    }

    /**
     * The implementation.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb, SelectPageInvoker<Entity> invoker) {
        assertConditionBeanNotNull(cb);
        final SelectPageCallback<Entity> pageCallback = new SelectPageCallback<Entity>() {
            public PagingBean getPagingBean() { return cb; }
            public int selectCountIgnoreFetchScope() {
                return readCount(cb);
            }
            public java.util.List<Entity> selectListWithFetchScope() {
                return readList(cb);
            }
        };
        return invoker.invokeSelectPage(pageCallback);
    }

    /**
     * Assert that record has not been deleted.
     * 
     * @param entity Selected entity.
     * @param searchKey4log Search-key for Logging.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     */
    protected void assertRecordHasNotBeenDeleted(sample.dbflute.allcommon.Entity entity, Object searchKey4log) {
        if (entity == null) {
            String msg = buildRecordHasBeenDeletedMessage(searchKey4log);
            throw new sample.dbflute.allcommon.exception.EntityAlreadyDeletedException(msg);
        }
    }

    /**
     * Assert that record has not been deleted.
     * 
     * @param ls Selected list.
     * @param searchKey4Log Search-key for Logging.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     */
    protected void assertRecordHasNotBeenDeleted(java.util.List ls, Object searchKey4Log) {
        if (ls == null || ls.isEmpty()) {
            String msg = buildRecordHasBeenDeletedMessage(searchKey4Log);
            throw new sample.dbflute.allcommon.exception.EntityAlreadyDeletedException(msg);
        }
    }

    /**
     * Assert that record has been selected as one.
     * 
     * @param ls Selected list.
     * @param searchKey4Log Search-key for Logging.
     * @exception sample.dbflute.allcommon.exception.EntityAlreadyDeletedException
     * @exception sample.dbflute.allcommon.exception.EntityDuplicatedException
     */
    protected void assertRecordHasBeenSelectedAsOne(java.util.List ls, Object searchKey4Log) {
        if (ls == null || ls.isEmpty()) {
            String msg = buildRecordHasBeenDeletedMessage(searchKey4Log);
            throw new sample.dbflute.allcommon.exception.EntityAlreadyDeletedException(msg);
        }
        if (ls.size() != 1) {
            throwRecordHasOverlappedException(ls.size() + "", searchKey4Log, null);
        }
    }

    protected void throwRecordHasOverlappedException(String resultCountString, Object searchKey4Log, Throwable cause) {
        String msg = "The selected records should be only one! But the resultCount=" + resultCountString + getLineSeparator();
        msg = msg + "/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *" + getLineSeparator();
        msg = msg + "Please confirm your condition. Does it really select only one?" + getLineSeparator();
        msg = msg + "And please confirm your database. Does it really exist only one?" + getLineSeparator();
        msg = msg + "- - - - -" + getLineSeparator();
        msg = msg + "The searchKey is as follows:" + getLineSeparator() + searchKey4Log + getLineSeparator();
        msg = msg + "* * * * * * * * * */" + getLineSeparator();
        if (cause != null) {
            throw new sample.dbflute.allcommon.exception.EntityDuplicatedException(msg, cause);
        } else {
            throw new sample.dbflute.allcommon.exception.EntityDuplicatedException(msg);
        }
    }

    private String buildRecordHasBeenDeletedMessage(Object searchKey4log) {
        String msg = "The record has already been deleted!" + getLineSeparator();
        msg = msg + "/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *" + getLineSeparator();
        msg = msg + "Please confirm the existence of your target record." + getLineSeparator();
        msg = msg + "Does the target record really created before this operation?" + getLineSeparator();
        msg = msg + "Has the target record been deleted by other thread?" + getLineSeparator();
        msg = msg + "It is precondition that the record exists on database." + getLineSeparator();
        msg = msg + "- - - - -" + getLineSeparator();
        msg = msg + "The searchKey is as follows:" + getLineSeparator() + searchKey4log + getLineSeparator();
        msg = msg + "* * * * * * * * * */" + getLineSeparator();
        return msg;
    }

    /**
     * Assert that selected count has not exceeded max count.
     * 
     * @param selectedCount Selected count.
     * @param maxCount Max count.
     * @param clauseObject Clause object for exception message.
     * @exception sample.dbflute.allcommon.exception.SelectedCountExceedMaxCountException
     */
    protected void assertSelectedCountHasNotExceededMaxCount(int selectedCount, int maxCount, Object clauseObject) {
        if (selectedCount > maxCount) {
            String msg = "Selected count[" + selectedCount + "] has exceeded max count[" + maxCount + "]: clauseObject=" + clauseObject;
            throw new sample.dbflute.allcommon.exception.SelectedCountExceedMaxCountException(msg, selectedCount, maxCount);
        }
    }

    // ===================================================================================
    //                                                                      Various Select
    //                                                                      ==============
    /**
     * Select value-label list.
     * 
     * @param <ENTITY> The type of entity.
     * @param cb Condition-bean. (NotNull)
     * @param valueLabelSetupper Value-label-setupper. (NotNull)
     * @return Value-label list. (NotNull)
     */
    protected <ENTITY extends Entity> java.util.List<java.util.Map<String, Object>> createValueLabelList(ListResultBean<ENTITY> ls, ValueLabelSetupper<ENTITY> valueLabelSetupper) {
        final java.util.List<java.util.Map<String, Object>> valueLabelList = new java.util.ArrayList<java.util.Map<String, Object>>();
        final ValueLabelBox box = new ValueLabelBox();
        for (ENTITY entity : ls) {
            final java.util.Map<String, Object> valueLabel = new java.util.HashMap<String, Object>();
            valueLabelSetupper.setup(box, entity);
            valueLabel.put("value", box.getValue());
            valueLabel.put("label", box.getLabel());
            valueLabelList.add(valueLabel);
        }
        return valueLabelList;
    }

    // ===================================================================================
    //                                                                            Sequence
    //                                                                            ========
    /**
     * The implementation.
     * 
     * @return The value of sequence. (NotNull)
     */
    public java.math.BigDecimal readNextVal() {
        try {
            final java.lang.reflect.Method method = getClass().getMethod("selectNextVal", new Class[]{});
            Object sequenceObject = method.invoke(this, new Object[] {});
            if (sequenceObject instanceof java.math.BigDecimal) {
                return (java.math.BigDecimal)sequenceObject;
            }
            return (java.math.BigDecimal)newInstanceSequence(java.math.BigDecimal.class, sequenceObject);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("The table does not have sequence: " + getTableDbName(), e);
        } catch (Exception e) {
            throw new RuntimeException("The selectNextVal() of the table threw the exception: " + getTableDbName(), e);
        }
    }

    private Object newInstanceSequence(Class resultClass, Object sequenceObject) {
        try {
            final java.lang.reflect.Method method = resultClass.getMethod("valueOf", new Class[]{String.class});
            return method.invoke(null, new Object[]{sequenceObject.toString()});
        } catch (NoSuchMethodException e) {
        } catch (Exception e) {
            throw new RuntimeException("The readNextVal() of the table threw the exception: " + getTableDbName(), e);
        }
        try {
            final java.lang.reflect.Method method = resultClass.getMethod("valueOf", new Class[]{Long.class});
            return method.invoke(null, new Object[]{Long.valueOf(sequenceObject.toString())});
        } catch (NoSuchMethodException e) {
        } catch (Exception e) {
            throw new RuntimeException("The readNextVal() of the table threw the exception: " + getTableDbName(), e);
        }
        String msg = "The result type of selectNextVal() is unsupported: type=" + resultClass;
        throw new IllegalStateException(msg);
    }

    // ===================================================================================
    //                                                        Load Referer Internal Helper
    //                                                        ============================
    /**
     * Help load referer internally. <br />
     * About internal policy, the value of primary key(and others too) is treated as CaseInsensitive.
     * 
     * @param <BASE_ENTITY_TYPE> The type of base entity.
     * @param <PK_TYPE> The type of primary key.
     * @param <REFERER_CB_TYPE> The type of referer condition-bean.
     * @param <REFERER_ENTITY_TYPE> The type of referer entity.
     * @param baseEntityList The list of base entity. (NotNull)
     * @param loadRefererOption The option of load referer. (NotNull)
     * @param callback The internal callback of load referer. (NotNull) 
     */
    protected <BASE_ENTITY_TYPE extends Entity, PK_TYPE, REFERER_CB_TYPE extends ConditionBean, REFERER_ENTITY_TYPE extends Entity>
            void helpLoadRefererInternally(java.util.List<BASE_ENTITY_TYPE> baseEntityList
                                         , sample.dbflute.allcommon.bhv.load.LoadRefererOption<REFERER_CB_TYPE, REFERER_ENTITY_TYPE> loadRefererOption
                                         , InternalLoadRefererCallback<BASE_ENTITY_TYPE, PK_TYPE, REFERER_CB_TYPE, REFERER_ENTITY_TYPE> callback) {

        // - - - - - - - - - - -
        // Assert pre-condition
        // - - - - - - - - - - -
        assertObjectNotNull("baseEntityList", baseEntityList);
        assertObjectNotNull("loadRefererOption", loadRefererOption);
        if (baseEntityList.isEmpty()) {
            return;
        }

        // - - - - - - - - - - - - - -
        // Prepare temporary container
        // - - - - - - - - - - - - - -
        final java.util.Map<PK_TYPE, BASE_ENTITY_TYPE> pkBaseEntityMap = new java.util.LinkedHashMap<PK_TYPE, BASE_ENTITY_TYPE>();
        final java.util.List<PK_TYPE> pkList = new java.util.ArrayList<PK_TYPE>();
        for (BASE_ENTITY_TYPE baseEntity : baseEntityList) {
            final PK_TYPE primaryKeyValue = callback.callbackBase_getPrimaryKeyValue(baseEntity);
            pkList.add(callback.callbackBase_getPrimaryKeyValue(baseEntity));
            pkBaseEntityMap.put(toLowerCasePrimaryKeyIfString(primaryKeyValue), baseEntity);
        }

        // - - - - - - - - - - - - - - - -
        // Prepare referer condition bean
        // - - - - - - - - - - - - - - - -
        final REFERER_CB_TYPE cb;
        if (loadRefererOption.getRefererConditionBean() != null) {
            cb = loadRefererOption.getRefererConditionBean();
        } else {
            cb = callback.callbackReferer_newMyConditionBean();
        }

        // - - - - - - - - - - - - - -
        // Select the list of referer
        // - - - - - - - - - - - - - -
        callback.callbackReferer_queryForeignKeyInScope(cb, pkList);
        loadRefererOption.delegateKeyConditionExchangingFirstWhereClauseForLastOne(cb);
        if (!loadRefererOption.isStopOrderByKey()) {
            callback.callbackReferer_queryAddOrderByForeignKeyAsc(cb);
            cb.getSqlComponentOfOrderByClause().exchangeFirstOrderByElementForLastOne();
        }
        loadRefererOption.delegateConditionBeanSettingUp(cb);
        final java.util.List<REFERER_ENTITY_TYPE> refererList = callback.callbackReferer_selectList(cb);
        loadRefererOption.delegateEntitySettingUp(refererList);

        // - - - - - - - - - - - - - - - - - - - - - - - -
        // Create the map of {primary key / referer list}
        // - - - - - - - - - - - - - - - - - - - - - - - -
        final java.util.Map<PK_TYPE, java.util.List<REFERER_ENTITY_TYPE>> pkReffererListMap = new java.util.LinkedHashMap<PK_TYPE, java.util.List<REFERER_ENTITY_TYPE>>();
        for (REFERER_ENTITY_TYPE refererEntity : refererList) {
            final PK_TYPE refererListKey;
            {
                final PK_TYPE foreignKeyValue = callback.callbackReferer_getForeignKeyValue(refererEntity);
                refererListKey = toLowerCasePrimaryKeyIfString(foreignKeyValue);
            }
            if (!pkReffererListMap.containsKey(refererListKey)) {
                pkReffererListMap.put(refererListKey, new java.util.ArrayList<REFERER_ENTITY_TYPE>());
            }
            (pkReffererListMap.get(refererListKey)).add(refererEntity);

            // for Reverse Reference.
            final BASE_ENTITY_TYPE baseEntity = pkBaseEntityMap.get(refererListKey);
            callback.callbackReferer_setForeignEntity(refererEntity, baseEntity);
        }

        // - - - - - - - - - - - - - - - - - -
        // Relate referer list to base entity
        // - - - - - - - - - - - - - - - - - -
        for (BASE_ENTITY_TYPE baseEntity : baseEntityList) {
            final PK_TYPE refererListKey;
            {
                final PK_TYPE primaryKey = callback.callbackBase_getPrimaryKeyValue(baseEntity);
                refererListKey = toLowerCasePrimaryKeyIfString(primaryKey);
            }
            if (pkReffererListMap.containsKey(refererListKey)) {
                callback.callbackBase_setRefererList(baseEntity, pkReffererListMap.get(refererListKey));
            } else {
                callback.callbackBase_setRefererList(baseEntity, new java.util.ArrayList<REFERER_ENTITY_TYPE>());
            }
        }
    }

    /**
     * To lower case for primary key if the value is string.
     * 
     * @param <PK_TYPE> The type of primary key.
     * @param value The value of primary key. (Nullable)
     * @return The value of primary key. (Nullable)
     */
    protected <PK_TYPE> PK_TYPE toLowerCasePrimaryKeyIfString(PK_TYPE value) {
        return (PK_TYPE)toLowerCaseIfString(value);
    }

    /**
     * @param <BASE_ENTITY_TYPE> The type of base entity.
     * @param <PK_TYPE> The type of primary key.
     * @param <REFERER_CB_TYPE> The type of referer condition-bean.
     * @param <REFERER_ENTITY_TYPE> The type of referer entity.
     */
    protected static interface InternalLoadRefererCallback<BASE_ENTITY_TYPE extends Entity
                                                         , PK_TYPE, REFERER_CB_TYPE extends ConditionBean
                                                         , REFERER_ENTITY_TYPE extends Entity> {
        // For Base
        public PK_TYPE callbackBase_getPrimaryKeyValue(BASE_ENTITY_TYPE entity);
        public void callbackBase_setRefererList(BASE_ENTITY_TYPE entity, java.util.List<REFERER_ENTITY_TYPE> refererList);

        // For Referer
        public REFERER_CB_TYPE callbackReferer_newMyConditionBean();
        public void callbackReferer_queryForeignKeyInScope(REFERER_CB_TYPE cb, java.util.List<PK_TYPE> pkList);
        public void callbackReferer_queryAddOrderByForeignKeyAsc(REFERER_CB_TYPE cb);
        public java.util.List<REFERER_ENTITY_TYPE> callbackReferer_selectList(REFERER_CB_TYPE cb);
        public PK_TYPE callbackReferer_getForeignKeyValue(REFERER_ENTITY_TYPE entity);
        public void callbackReferer_setForeignEntity(REFERER_ENTITY_TYPE refererEntity, BASE_ENTITY_TYPE baseEntity);
    }

    // ===================================================================================
    //                                                             Pullout Internal Helper
    //                                                             =======================
    protected <BASE_ENTITY_TYPE extends Entity, FOREIGN_ENTITY_TYPE extends Entity>
            java.util.List<FOREIGN_ENTITY_TYPE> helpPulloutInternally(java.util.List<BASE_ENTITY_TYPE> baseEntityList, InternalPulloutCallback<BASE_ENTITY_TYPE, FOREIGN_ENTITY_TYPE> callback) {
        assertObjectNotNull("baseEntityList", baseEntityList);
        final java.util.Set<FOREIGN_ENTITY_TYPE> foreignSet = new java.util.LinkedHashSet<FOREIGN_ENTITY_TYPE>();
        for (BASE_ENTITY_TYPE entity : baseEntityList) {
            final FOREIGN_ENTITY_TYPE foreignEntity = callback.callbackGetForeignEntity(entity);
            if (foreignEntity == null || foreignSet.contains(foreignEntity)) {
                continue;
            }
            foreignSet.add(foreignEntity);
        }
        return new java.util.ArrayList<FOREIGN_ENTITY_TYPE>(foreignSet);
    }

    protected static interface InternalPulloutCallback<BASE_ENTITY_TYPE extends Entity, FOREIGN_ENTITY_TYPE extends Entity> {
        public FOREIGN_ENTITY_TYPE callbackGetForeignEntity(BASE_ENTITY_TYPE entity);
    }

    // ===================================================================================
    //                                                                          Token File
    //                                                                          ==========
    /**
     * Output token-file from this table records.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param filename Name of the file. (NotNull and NotEmpty)
     * @param tokenFileOutputOption token-file-output-option. (NotNull and Required{delimiter and encoding})
     * @return Token-file-output-result. (NotNull)
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public TokenFileOutputResult outputTokenFile(ConditionBean cb, String filename, TokenFileOutputOption tokenFileOutputOption) throws java.io.FileNotFoundException, java.io.IOException {
        assertConditionBeanNotNull(cb);
        assertStringNotNullAndNotTrimmedEmpty("filename", filename);
        assertObjectNotNull("tokenFileOutputOption", tokenFileOutputOption);

        final java.util.List<Entity> ls = readList(cb);
        java.util.List<java.util.List<String>> rowList = new java.util.ArrayList<java.util.List<String>>();
        for (java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            final java.util.List<String> valueList = getDBMeta().convertToColumnStringValueList(entity);
            rowList.add(valueList);
        }
        final FileMakingSimpleFacade fileMakingSimpleFacade = new FileMakingSimpleFacadeImpl();
        final FileMakingOption fileMakingOption = tokenFileOutputOption.getFileMakingOption();
        final FileMakingHeaderInfo fileMakingHeaderInfo = new FileMakingHeaderInfo();
        final java.util.List<String> columnDbNameList = new java.util.ArrayList<String>();
        for (final java.util.Iterator ite = getDBMeta().getColumnInfoList().iterator(); ite.hasNext(); ) {
            final ColumnInfo columnInfo = (ColumnInfo)ite.next();
            columnDbNameList.add(columnInfo.getColumnDbName());
        }
        fileMakingHeaderInfo.setColumnNameList(columnDbNameList);
        fileMakingOption.setFileMakingHeaderInfo(fileMakingHeaderInfo);
        fileMakingSimpleFacade.makeFromRowList(filename, rowList, fileMakingOption);
        final TokenFileOutputResult tokeFileOutputResult = new TokenFileOutputResult();
        tokeFileOutputResult.setSelectedList(ls);
        return tokeFileOutputResult;
    }

    // ===================================================================================
    //                                                                              Helper
    //                                                                              ======
    /**
     * To lower case if the type is String.
     * 
     * @param obj Object. (Nullable)
     * @return Lower object. (Nullable)
     */
    protected Object toLowerCaseIfString(Object obj) {
        if (obj != null && obj instanceof String) {
            return ((String)obj).toLowerCase();
        }
        return obj;
    }

    /**
     * Get the value of line separator.
     * 
     * @return The value of line separator. (NotNull)
     */
    protected String getLineSeparator() {
        return System.getProperty("line.separator");
    }

    protected <ENTITY_TYPE extends Entity> ENTITY_TYPE helpDowncastInternally(Entity entity, Class<ENTITY_TYPE> clazz) {
        assertObjectNotNull("entity", entity);
        assertObjectNotNull("clazz", clazz);
        try {
            return (ENTITY_TYPE)entity;
        } catch (ClassCastException e) {
            String msg = "The entity should be " + clazz.getSimpleName() + " but it was: " + entity.getClass();
            throw new RuntimeException(msg, e);
        }
    }

    // ----------------------------------------------------------------
    //                                                    Assert Object
    //                                                    -------------
    /**
     * Assert that the object is not null.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     * @exception IllegalArgumentException
     */
    protected void assertObjectNotNull(String variableName, Object value) {
        if (variableName == null) {
            String msg = "The value should not be null: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
        if (value == null) {
            String msg = "The value should not be null: variableName=" + variableName;
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the entity is not null.
     * 
     * @param entity Entity. (NotNull)
     */
    protected void assertEntityNotNull(Entity entity) {
        assertObjectNotNull("entity", entity);
    }

    /**
     * Assert that the condition-bean is not null.
     * 
     * @param cb Condition-bean. (NotNull)
     */
    protected void assertConditionBeanNotNull(sample.dbflute.allcommon.cbean.ConditionBean cb) {
        assertObjectNotNull("cb", cb);
    }

    /**
     * Assert that the entity has primary-key value.
     * 
     * @param entity Entity. (NotNull)
     */
    protected void assertEntityNotNullAndHasPrimaryKeyValue(Entity entity) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            String msg = "The entity must should primary-key: entity=" + entity;
            throw new IllegalArgumentException(msg + entity);
        }
    }

    // ----------------------------------------------------------------
    //                                                    Assert String
    //                                                    -------------
    /**
     * Assert that the entity is not null and not trimmed empty.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     */
    protected void assertStringNotNullAndNotTrimmedEmpty(String variableName, String value) {
        assertObjectNotNull("variableName", variableName);
        assertObjectNotNull(variableName, value);
        if (value.trim().length() ==0) {
            String msg = "The value should not be empty: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
    }

    // ----------------------------------------------------------------
    //                                                      Assert List
    //                                                      -----------
    /**
     * Assert that the list is empty.
     * 
     * @param ls List. (NotNull)
     */
    protected void assertListNotNullAndEmpty(java.util.List ls) {
        assertObjectNotNull("ls", ls);
        if (!ls.isEmpty()) {
            String msg = "The list should be empty: ls=" + ls.toString();
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the list is not empty.
     * 
     * @param ls List. (NotNull)
     */
    protected void assertListNotNullAndNotEmpty(java.util.List ls) {
        assertObjectNotNull("ls", ls);
        if (ls.isEmpty()) {
            String msg = "The list should not be empty: ls=" + ls.toString();
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the list having only one.
     * 
     * @param ls List. (NotNull)
     */
    protected void assertListNotNullAndHasOnlyOne(java.util.List ls) {
        assertObjectNotNull("ls", ls);
        if (ls.size() != 1) {
            String msg = "The list should contain only one object: ls=" + ls.toString();
            throw new IllegalArgumentException(msg);
        }
    }
}
