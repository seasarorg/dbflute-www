package sample.dbflute.allcommon.exception;

/**
 * The exception when the entity has been updated (by other thread).
 * 
 * @author DBFlute(AutoGenerator)
 */
public class EntityAlreadyUpdatedException extends org.seasar.dao.NotSingleRowUpdatedRuntimeException {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor.
     * 
     * @param bean Bean. (NotNull)
     * @param rows Rows.
     */
    public EntityAlreadyUpdatedException(Object bean, int rows) {
        super(bean, rows);
    }

    /**
     * Constructor.
     * 
     * @param e NotSingleRowUpdatedRuntimeException. (NotNull)
     */
    public EntityAlreadyUpdatedException(org.seasar.dao.NotSingleRowUpdatedRuntimeException e) {
        super(e.getBean(), e.getRows());
    }
}
