package sample.dbflute.allcommon.bhv.batch;

import sample.dbflute.allcommon.Entity;

/**
 * @author DBFlute(AutoGenerator)
 */
public class TokenFileOutputResult {

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    protected java.util.List<Entity> _selectedList;

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========
    public java.util.List<Entity> getSelectedList() {
        return _selectedList;
    }

    public void setSelectedList(java.util.List<Entity> selectedList) {
        _selectedList = selectedList;
    }
}
