package sample.web.layout;

public abstract class AbstractLayoutPage {
	public String getLayout() {
		return null;
	}
}
