package sample.dbflute.exentity;


/**
 * The entity of DEPT.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class Dept extends sample.dbflute.bsentity.BsDept {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
}
