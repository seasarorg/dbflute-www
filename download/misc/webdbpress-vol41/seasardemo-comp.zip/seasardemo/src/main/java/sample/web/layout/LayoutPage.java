package sample.web.layout;

public class LayoutPage extends AbstractLayoutPage {

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		return null;
	}

}
