package sample.dbflute.allcommon;

import sample.dbflute.allcommon.bhv.BehaviorReadable;

import sample.dbflute.allcommon.dbmeta.DBMetaInstanceHandler;
import sample.dbflute.allcommon.dbmeta.DBMeta;

/**
 * The implementation of behavior-selector.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class CacheBehaviorSelector implements BehaviorSelector {

    /** The container of Seasar. */
    protected org.seasar.framework.container.S2Container _container;

    public void setContainer(org.seasar.framework.container.S2Container container) {
        this._container = container;
    }

    /** The cache of behavior. (It's the generics hell!) */
    protected java.util.Map<Class<? extends BehaviorReadable>, BehaviorReadable> _behaviorCache = new java.util.LinkedHashMap<Class<? extends BehaviorReadable>, BehaviorReadable>();


    /**
     * Select behavior.
     * 
     * @param <BEHAVIOR_TYPE> The type of behavior.
     * @param behaviorType Behavior type. (NotNull)
     * @return Behavior. (NotNull)
     */
    public <BEHAVIOR_TYPE extends BehaviorReadable> BEHAVIOR_TYPE select(Class<BEHAVIOR_TYPE> behaviorType) {
        if (_behaviorCache.containsKey(behaviorType)) {
            return (BEHAVIOR_TYPE)_behaviorCache.get(behaviorType);
        }
        final BEHAVIOR_TYPE bhv = (BEHAVIOR_TYPE)_container.getComponent(behaviorType);
        _behaviorCache.put(behaviorType, bhv);
        return bhv;
    }

    /**
     * Select behavior-readable by name.
     * 
     * @param tableFlexibleName Table flexible-name. (NotNull)
     * @return Behavior-readable. (NotNull)
     */
    public BehaviorReadable byName(String tableFlexibleName) {
        assertStringNotNullAndNotTrimmedEmpty("tableFlexibleName", tableFlexibleName);
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(tableFlexibleName);
        return select(getBehaviorType(dbmeta));
    }

    /**
     * Get behavior-type by dbmeta.
     * 
     * @param dbmeta Dbmeta. (NotNull)
     * @return Behavior-type. (NotNull)
     */
    protected Class getBehaviorType(DBMeta dbmeta) {
        final String behaviorTypeName = dbmeta.getBehaviorTypeName();
        if (behaviorTypeName == null) {
            String msg = "The dbmeta.getBehaviorTypeName() should not return null: dbmeta=" + dbmeta;
            throw new IllegalStateException(msg);
        }
        final Class behaviorType;
        try {
            behaviorType = Class.forName(behaviorTypeName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("The class does not exist: " + behaviorTypeName, e);
        }
        return behaviorType;
    }

    // =====================================================================================
    //                                                                               Destroy
    //                                                                               =======
    public void destroy() {
        _container = null;
    }

    // ----------------------------------------------------------------
    //                                                    Assert Object
    //                                                    -------------
    /**
     * Assert that the object is not null.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     * @exception IllegalArgumentException
     */
    protected void assertObjectNotNull(String variableName, Object value) {
        if (variableName == null) {
            String msg = "The value should not be null: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
        if (value == null) {
            String msg = "The value should not be null: variableName=" + variableName;
            throw new IllegalArgumentException(msg);
        }
    }

    // ----------------------------------------------------------------
    //                                                    Assert String
    //                                                    -------------
    /**
     * Assert that the entity is not null and not trimmed empty.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     */
    protected void assertStringNotNullAndNotTrimmedEmpty(String variableName, String value) {
        assertObjectNotNull("variableName", variableName);
        assertObjectNotNull("value", value);
        if (value.trim().length() ==0) {
            String msg = "The value should not be empty: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
    }
}
