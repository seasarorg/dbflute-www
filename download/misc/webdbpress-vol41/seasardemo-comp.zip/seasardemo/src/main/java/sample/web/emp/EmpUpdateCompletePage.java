package sample.web.emp;

public class EmpUpdateCompletePage extends AbstractEmpPage {

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		return null;
	}

}
