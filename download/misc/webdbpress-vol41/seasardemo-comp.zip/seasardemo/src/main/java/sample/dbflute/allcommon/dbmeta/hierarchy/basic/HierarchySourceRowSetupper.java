package sample.dbflute.allcommon.dbmeta.hierarchy.basic;


/**
 * @author DBFlute(AutoGenerator)
 * @param <SOURCE_ROW> The type of source.
 */
public interface HierarchySourceRowSetupper<SOURCE_ROW> {

    public sample.dbflute.allcommon.dbmeta.hierarchy.HierarchySourceRow setup(SOURCE_ROW source);
}