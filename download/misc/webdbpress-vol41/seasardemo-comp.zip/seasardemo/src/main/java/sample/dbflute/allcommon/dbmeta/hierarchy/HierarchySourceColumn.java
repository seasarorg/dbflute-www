package sample.dbflute.allcommon.dbmeta.hierarchy;


/**
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface HierarchySourceColumn {

    public String getColumnName();
}