package sample.dbflute.bsentity;



import sample.dbflute.allcommon.Entity;
import sample.dbflute.allcommon.dbmeta.DBMeta;
import sample.dbflute.allcommon.dbmeta.DBMetaInstanceHandler;

/**
 * The entity of EMP(TABLE). <br />
 * 
 * <pre>
 * [primary-key]
 *     ID
 * 
 * [column-property]
 *     ID, NAME, HIRE_DATE, DEPT_ID, VERSION_NO
 * 
 * [foreign-property]
 *     dept
 * 
 * [referer-property]
 *     
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     VersionNo
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public abstract class BsEmp implements Entity, java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /** TABLE-Annotation for S2Dao. The value is EMP. */
    public static final String TABLE = "EMP";

    
    /** VERSION_NO-Annotation */
    public static final String VERSION_NO_PROPERTY = "versionNo";


    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Entity modified properties. (for S2Dao) */
    protected EntityModifiedProperties _modifiedProperties = newEntityModifiedProperties();

    /** The value of id. PK : INTEGER : NotNull : Default=[] */
    protected java.lang.Integer _id;

    /** The value of name. VARCHAR(20) : Default=[] */
    protected String _name;

    /** The value of hireDate. DATE : Default=[] */
    protected java.util.Date _hireDate;

    /** The value of deptId. INTEGER : Default=[] : FK to DEPT */
    protected java.lang.Integer _deptId;

    /** The value of versionNo. DECIMAL(8) : Default=[] */
    protected java.math.BigDecimal _versionNo;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     */
    public BsEmp() {
    }


    // ===================================================================================
    //                                                                              DBMeta
    //                                                                              ======
    /**
     * The implementation.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return DBMetaInstanceHandler.findDBMeta(getTableDbName());
    }

    // ===================================================================================
    //                                                                          Table Name
    //                                                                          ==========
    /**
     * The implementation.
     * 
     * @return Table db-name of EMP(TABLE). (NotNull)
     */
    public String getTableDbName() {
        return "EMP";
    }

    /**
     * The implementation.
     * 
     * @return Table property name(JavaBeansRule) of EMP(TABLE). (NotNull)
     */
    public String getTablePropertyName() {
        return "emp";
    }

    /**
     * The implementation.
     * 
     * @return Table prop-name(JavaBeansRule) of EMP(TABLE). (NotNull)
     * @deprecated Please use getTablePropertyName()
     */
    public String getTablePropName() {
        return "emp";
    }

    /**
     * The implementation.
     * 
     * @return Table cap-prop-name of EMP(TABLE). (NotNull)
     */
    public String getTableCapPropName() {
        return "Emp";
    }

    /**
     * The implementation.
     * 
     * @return Table uncap-prop-name of EMP(TABLE). (NotNull)
     */
    public String getTableUncapPropName() {
        return "emp";
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========

    /** Column Annotation for S2Dao. PK : INTEGER : NotNull : Default=[] */
    public static final String id_COLUMN = "ID";

    /**
     * Get the value of id. <br />
     * {PK : INTEGER : NotNull : Default=[]}
     * 
     * @return The value of id. (Nullable)
     */
    public java.lang.Integer getId() {
        return _id;
    }

    /**
     * Set the value of id. <br />
     * {PK : INTEGER : NotNull : Default=[]}
     * 
     * @param id The value of id. (Nullable)
     */
    public void setId(java.lang.Integer id) {
        _modifiedProperties.addPropertyName("id");
        this._id = id;
    }

    /** Column Annotation for S2Dao. VARCHAR(20) : Default=[] */
    public static final String name_COLUMN = "NAME";

    /**
     * Get the value of name. <br />
     * {VARCHAR(20) : Default=[]}
     * 
     * @return The value of name. (Nullable)
     */
    public String getName() {
        return _name;
    }

    /**
     * Set the value of name. <br />
     * {VARCHAR(20) : Default=[]}
     * 
     * @param name The value of name. (Nullable)
     */
    public void setName(String name) {
        _modifiedProperties.addPropertyName("name");
        this._name = name;
    }

    /** Column Annotation for S2Dao. DATE : Default=[] */
    public static final String hireDate_COLUMN = "HIRE_DATE";

    /**
     * Get the value of hireDate. <br />
     * {DATE : Default=[]}
     * 
     * @return The value of hireDate. (Nullable)
     */
    public java.util.Date getHireDate() {
        return _hireDate;
    }

    /**
     * Set the value of hireDate. <br />
     * {DATE : Default=[]}
     * 
     * @param hireDate The value of hireDate. (Nullable)
     */
    public void setHireDate(java.util.Date hireDate) {
        _modifiedProperties.addPropertyName("hireDate");
        this._hireDate = hireDate;
    }

    /** Column Annotation for S2Dao. INTEGER : Default=[] : FK to DEPT */
    public static final String deptId_COLUMN = "DEPT_ID";

    /**
     * Get the value of deptId. <br />
     * {INTEGER : Default=[] : FK to DEPT}
     * 
     * @return The value of deptId. (Nullable)
     */
    public java.lang.Integer getDeptId() {
        return _deptId;
    }

    /**
     * Set the value of deptId. <br />
     * {INTEGER : Default=[] : FK to DEPT}
     * 
     * @param deptId The value of deptId. (Nullable)
     */
    public void setDeptId(java.lang.Integer deptId) {
        _modifiedProperties.addPropertyName("deptId");
        this._deptId = deptId;
    }

    /** Column Annotation for S2Dao. DECIMAL(8) : Default=[] */
    public static final String versionNo_COLUMN = "VERSION_NO";

    /**
     * Get the value of versionNo. <br />
     * {DECIMAL(8) : Default=[]}
     * 
     * @return The value of versionNo. (Nullable)
     */
    public java.math.BigDecimal getVersionNo() {
        return _versionNo;
    }

    /**
     * Set the value of versionNo. <br />
     * {DECIMAL(8) : Default=[]}
     * 
     * @param versionNo The value of versionNo. (Nullable)
     */
    public void setVersionNo(java.math.BigDecimal versionNo) {
        _modifiedProperties.addPropertyName("versionNo");
        this._versionNo = versionNo;
    }


    // ===================================================================================
    //                                                                     Classify Method
    //                                                                     ===============
          
    // ===================================================================================
    //                                                        Classification Determination
    //                                                        ============================
          

    // ===================================================================================
    //                                                               Classification Getter
    //                                                               =====================
          

    // ===================================================================================
    //                                                                       Foreign Table
    //                                                                       =============

    // /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [DEPT(TABLE)]
    //   ForeignProperty = [dept]
    // * * * * * * * * */

    /** RELNO of foreign table for s2dao. */
    public static final int dept_RELNO = 0;

    /** RELKEYS of foreign table for s2dao. */
    public static final String dept_RELKEYS = "DEPT_ID:ID";

    /** The entity of foreign table. */
    protected sample.dbflute.exentity.Dept _parentDept;

    /**
     * Get the entity of foreign table of dept. {without lazyload}
     * 
     * @return The entity of foreign table. (Nullable: If the foreign key does not have NotNull-constraint, please check null.)
     */
    public sample.dbflute.exentity.Dept getDept() {
        return _parentDept;
    }

    /**
     * Set the entity of foreign table of dept.
     * 
     * @param dept The entity of foreign table. (Nullable)
     */
    public void setDept(sample.dbflute.exentity.Dept dept) {
        this._parentDept = dept;
    }

    /**
     * Has foreign instance of dept.
     * 
     * @return Determination.
     */
    public boolean hasForeignInstanceDept() {
        return _parentDept != null;
    }

    /**
     * @return Determination.
     * @deprecated Sorry! Please use hasForeignInstanceDept().
     */
    public boolean hasRelationDept() {
        return hasForeignInstanceDept();
    }

    /**
     * Trace foreign entity (for read) of dept.
     * 
     * @return The entity of foreign table. (NotNull: If the object is nul, it returns new empty entity as read-only.)
     */
    public sample.dbflute.exentity.Dept traceDept() {
        return _parentDept != null ? _parentDept : new sample.dbflute.exentity.Dept();
    }
  
    // ===================================================================================
    //                                                                       Referer Table
    //                                                                       =============

    // ===================================================================================
    //                                                                       Determination
    //                                                                       =============
    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasPrimaryKeyValue() {
        if (_id == null) {
            return false;
        }
        return true;
    }

    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasVersionNoValue() {
        return !(getVersionNo() + "").equals("null");// For primitive type
    }

    /**
     * The implementation.
     * 
     * @return Determination.
     */
    public boolean hasUpdateDateValue() {
        return false;
    }

    // ===================================================================================
    //                                                                 Modified Properties
    //                                                                 ===================
    /**
     * Get modified property names. (S2Dao uses this for updateModifiedProperties())
     * 
     * @return Modified property names. (NotNull)
     */
    public java.util.Set<String> getModifiedPropertyNames() {
        return _modifiedProperties.getPropertyNames();
    }

    /**
     * New entity modified properties. You can override this at the sub-class if you need it.
     * 
     * @return Entity modified properties. (NotNull)
     */
    protected EntityModifiedProperties newEntityModifiedProperties() {
        return new EntityModifiedProperties();
    }

    /**
     * Clear modified property names.
     */
    public void clearModifiedPropertyNames() {
        _modifiedProperties.clear();
    }

    /**
     * Has modification?
     * 
     * @return Determination.
     */
    public boolean hasModification() {
        return !_modifiedProperties.isEmpty();
    }

    // ===================================================================================
    //                                                                      Basic Override
    //                                                                      ==============

    /**
     * The override.
     * If the primary-key of the other is same as this one, returns true.
     * 
     * @param other Other entity.
     * @return Comparing result.
     */
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (!(other instanceof BsEmp)) {
            return false;
        }
        final BsEmp otherEntity = (BsEmp)other;

        if (getId() == null || !getId().equals(otherEntity.getId())) {
            return false;
        }

        return true;
    }

    /**
     * The override.
     * Calculates hash-code from primary-key.
     * 
     * @return Hash-code from primary-keys.
     */
    public int hashCode() {
        int result = 0;

        if (this.getId() != null) {
            result = result + getId().hashCode();
        }

        return result;
    }

    /**
     * The override.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String toString() {
        final String delimiter = ",";
        final StringBuffer sb = new StringBuffer();

        sb.append(delimiter).append(getId());
        sb.append(delimiter).append(getName());
        sb.append(delimiter).append(getHireDate());
        sb.append(delimiter).append(getDeptId());
        sb.append(delimiter).append(getVersionNo());

        sb.delete(0, delimiter.length());
        sb.insert(0, "{").append("}");
        return sb.toString();
    }
}
