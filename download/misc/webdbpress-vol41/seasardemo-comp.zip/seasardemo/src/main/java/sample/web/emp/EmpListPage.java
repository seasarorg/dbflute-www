package sample.web.emp;

import java.util.Date;
import java.util.List;

import org.seasar.teeda.extension.annotation.convert.DateTimeConverter;

import sample.dbflute.cbean.EmpCB;
import sample.dbflute.exentity.Emp;


public class EmpListPage extends AbstractEmpPage {

	// ##### 検索条件 #####
	public String condEmpName;

	@DateTimeConverter(pattern = "yyyy年MM月dd日")
	public Date condFromHireDate;

	@DateTimeConverter(pattern = "yyyy年MM月dd日")
	public Date condToHireDate;

	
	// ##### 繰り返し項目 #####
	public int empIndex;

	public EmpDto[] empItems;
	
	public Integer id;
	
	public String empName;
	
	@DateTimeConverter(pattern = "yyyy年MM月dd日")
	public Date hireDate;

	public String deptName;

	/* ダイナミックプロパティ */
	public String getEmpItemStyle() {
		if (empIndex % 2 == 0) {
			return "background-color: lightblue;";
		} else {
			return "background-color: white;";
		}		
	}
	
	// ##### ロジック #####
	public Class initialize() {
		return null;
	}

	public Class prerender() {
		List<Emp> emps = findEmps();
		empItems = empDxo.convert(emps);		
		return null;
	}
	
	protected List<Emp> findEmps() {		
		EmpCB cb = new EmpCB();
		
		/* テーブル結合：DEPT */
		cb.setupSelect_Dept();
		
		/* 範囲検索：入社日 */
		cb.query().setHireDate_DateFromTo(condFromHireDate, condToHireDate);
		
		/* 先頭一致：社員名 */
		cb.query().setName_PrefixSearch(condEmpName);
		
		/* 並べ替え：社員名（昇順） */
		cb.query().addOrderBy_Name_Asc();
		
		/* 検索の実施 */
		return empBhv.selectList(cb);
	}	

}
