package sample.dbflute.allcommon.cbean.coption;


/**
 * The interface of condition-option.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface ConditionOption {
    public String getRearOption();
}
