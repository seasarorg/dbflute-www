package sample.dbflute.allcommon.s2dao;

import org.seasar.dao.AnnotationReaderFactory;
import org.seasar.dao.BeanEnhancer;
import org.seasar.dao.impl.DaoMetaDataFactoryImpl;
import org.seasar.dao.impl.DaoMetaDataImpl;
import org.seasar.extension.jdbc.ResultSetFactory;
import org.seasar.extension.jdbc.StatementFactory;

import org.seasar.dao.PropertyTypeFactoryBuilder;
import org.seasar.dao.RelationPropertyTypeFactoryBuilder;
import org.seasar.dao.TableNaming;
import org.seasar.dao.ColumnNaming;

import sample.dbflute.allcommon.cbean.ConditionBeanContext;

/**
 * DaoMetaDataFactoryImpl for DBFlute.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class S2DaoMetaDataFactoryImpl extends DaoMetaDataFactoryImpl {

    // ===================================================================================
    //                                                                          Definition
    //                                                                          ==========
    /** Log-instance. */
    private static final org.apache.commons.logging.Log _log = org.apache.commons.logging.LogFactory.getLog(S2DaoInterceptor.class);

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Bean enhancer. */
    protected BeanEnhancer beanEnhancer;

    /** The naming of column. {After S2Dao-1.0.47} */
    protected ColumnNaming columnNaming;

    /** The builder of property type factory. {After S2Dao-1.0.47} */
    protected PropertyTypeFactoryBuilder propertyTypeFactoryBuilder;

    /** The builder of relation property type factory. {After S2Dao-1.0.47} */
    protected RelationPropertyTypeFactoryBuilder relationPropertyTypeFactoryBuilder;

    /** The builder of table naming. {After S2Dao-1.0.47} */
    protected TableNaming tableNaming;


    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param dataSource Data source.
     * @param statementFactory Statement factory.
     * @param resultSetFactory Result set factory.
     * @param readerFactory Annotation reader factory.
     * @param xaDataSource XA data source.
     */
    public S2DaoMetaDataFactoryImpl(javax.sql.DataSource dataSource,
            StatementFactory statementFactory,
            ResultSetFactory resultSetFactory,
            AnnotationReaderFactory readerFactory,
            javax.sql.XADataSource xaDataSource) {
        super(dataSource, statementFactory, resultSetFactory, readerFactory);

        _log.info("/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * {DBFlute}");
        showInformation(dataSource, xaDataSource);

        // Stop the LinkageError!
        ConditionBeanContext.initialize();

        initializeDatabaseProductNameOfContext(xaDataSource);

        _log.info("* * * * */");
    }

    protected void showInformation(javax.sql.DataSource dataSource, javax.sql.XADataSource xaDataSource) {
        if (xaDataSource != null && xaDataSource instanceof org.seasar.extension.dbcp.impl.XADataSourceImpl) {
            final org.seasar.extension.dbcp.impl.XADataSourceImpl xaDataSourceImpl = (org.seasar.extension.dbcp.impl.XADataSourceImpl)xaDataSource;
            final String driverClassName = xaDataSourceImpl.getDriverClassName();
            final String url = xaDataSourceImpl.getURL();
            final String user = xaDataSourceImpl.getUser();
            _log.info("[XADataSource]: " + xaDataSourceImpl);
            _log.info("    driver = " + driverClassName);
            _log.info("    url    = " + url);
            _log.info("    user   = " + user);
        }
        _log.info("[StatementFactory]: " + statementFactory);
        _log.info("[ResultSetFactory]: " + resultSetFactory);
    }

    // -----------------------------------------------------
    //                                 Database Product Name
    //                                 ---------------------
    protected void initializeDatabaseProductNameOfContext(javax.sql.XADataSource xaDataSource) {
        if (getDatabaseProductNameFromContext() != null) {
            return;
        }

        // From JDBC Driver!
        if (xaDataSource != null && xaDataSource instanceof org.seasar.extension.dbcp.impl.XADataSourceImpl) {
            final org.seasar.extension.dbcp.impl.XADataSourceImpl xaDataSourceImpl = (org.seasar.extension.dbcp.impl.XADataSourceImpl)xaDataSource;
            final String driverClassName = xaDataSourceImpl.getDriverClassName();
            if (driverClassName != null) {
                if (setupDatabaseProductNameByDriverClassName(driverClassName)) {
                    _log.info("...Initializing database product name from driverClassName: " + getDatabaseProductNameFromContext());
                    return;
                }
            }
        }

        _log.info("...Initializing database product name as default: H2");
        setDatabaseProductNameToContext("H2");
    }

    protected String getDatabaseProductNameFromContext() {
        return ConditionBeanContext.getDatabaseProductName();
    }

    protected void setDatabaseProductNameToContext(String name) {
        ConditionBeanContext.setDatabaseProductName(name);
    }

    protected boolean setupDatabaseProductNameByDriverClassName(String driverClassName) {
        return ConditionBeanContext.setupDatabaseProductNameByDriverClassName(driverClassName);
    }


    // ===================================================================================
    //                                                      DataMetaData Creation Override
    //                                                      ==============================
    protected DaoMetaDataImpl createDaoMetaDataImpl() {// Override!
        final S2DaoMetaDataExtension dmdExtension = newDaoMetaDataExtension();
        dmdExtension.setBeanEnhancer(beanEnhancer);
        dmdExtension.setAnnotationReaderFactory(this.annotationReaderFactory);
        dmdExtension.setColumnNaming(this.columnNaming);
        dmdExtension.setPropertyTypeFactoryBuilder(this.propertyTypeFactoryBuilder);
        dmdExtension.setRelationPropertyTypeFactoryBuilder(this.relationPropertyTypeFactoryBuilder);
        dmdExtension.setTableNaming(tableNaming);
        return dmdExtension;
    }

    protected S2DaoMetaDataExtension newDaoMetaDataExtension() {
        return new S2DaoMetaDataExtension();
    }

    // ===================================================================================
    //                                                                   Sql File Encoding
    //                                                                   =================
    public String getSqlFileEncoding() {
        return sqlFileEncoding;
    }

    // ===================================================================================
    //                                                                       Bean Enhancer
    //                                                                       =============
    public BeanEnhancer getBeanEnhancer() {
        return beanEnhancer;
    }

    public void setBeanEnhancer(final BeanEnhancer beanEnhancer) {
        this.beanEnhancer = beanEnhancer;
    }

    // ===================================================================================
    //                                                                Version After 1.0.47
    //                                                                ====================
    public ColumnNaming getColumnNaming() {
        return columnNaming;
    }

    public void setColumnNaming(final ColumnNaming columnNaming) {
        this.columnNaming = columnNaming;
    }

    public PropertyTypeFactoryBuilder getPropertyTypeFactoryBuilder() {
        return propertyTypeFactoryBuilder;
    }

    public void setPropertyTypeFactoryBuilder(final PropertyTypeFactoryBuilder propertyTypeFactoryBuilder) {
        this.propertyTypeFactoryBuilder = propertyTypeFactoryBuilder;
    }

    public RelationPropertyTypeFactoryBuilder getRelationPropertyTypeFactoryBuilder() {
        return relationPropertyTypeFactoryBuilder;
    }

    public void setRelationPropertyTypeFactoryBuilder(final RelationPropertyTypeFactoryBuilder relationPropertyTypeFactoryBuilder) {
        this.relationPropertyTypeFactoryBuilder = relationPropertyTypeFactoryBuilder;
    }

    public TableNaming getTableNaming() {
        return tableNaming;
    }

    public void setTableNaming(final TableNaming tableNaming) {
        this.tableNaming = tableNaming;
    }
}