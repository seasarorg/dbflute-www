package sample.dbflute.allcommon.dbmeta.info;


import sample.dbflute.allcommon.dbmeta.DBMeta;

/**
 * The class of column info.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class ColumnInfo {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    protected DBMeta dbmeta;
    protected String columnDbName;
    protected String propertyName;
    protected Class propertyType;
    protected boolean primary;
    protected Integer columnSize;

    // ===================================================================================
    //                                                                         Easy-to-Use
    //                                                                         ===========
    public ColumnInfo(DBMeta dbmeta, String columnDbName) {
        this.dbmeta = dbmeta;
        this.columnDbName = columnDbName;
    }

    public ColumnInfo(DBMeta dbmeta, String columnDbName, String propertyName, Class propertyType, boolean primary, Integer columnSize) {
        this(dbmeta, columnDbName);
        this.propertyName = propertyName;
        this.propertyType = propertyType;
        this.primary = primary;
        this.columnSize = columnSize;
    }

    // ===================================================================================
    //                                                                             Builder
    //                                                                             =======
    public String buildInitCapPropertyName() {
        return initCap(this.propertyName);
    }

    // ===================================================================================
    //                                                                              Finder
    //                                                                              ======
    public java.lang.reflect.Method findSetter() {
        return findMethod(dbmeta.getEntityType(), "set" + buildInitCapPropertyName(), new Class[] { this.propertyType });
    }

    public java.lang.reflect.Method findGetter() {
        return findMethod(dbmeta.getEntityType(), "get" + buildInitCapPropertyName(), new Class[] {});
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    public DBMeta getDBMeta() {
        return dbmeta;
    }

    public void setDBMeta(DBMeta dbmeta) {
        this.dbmeta = dbmeta;
    }

    public String getColumnDbName() {
        return this.columnDbName;
    }

    public void setColumnDbName(String columnDbName) {
        this.columnDbName = columnDbName;
    }

    public String getPropertyName() {
        return this.propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public boolean isPrimary() {
        return this.primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public Integer getColumnSize() {
        return this.columnSize;
    }

    public void setColumnSize(Integer columnSize) {
        this.columnSize = columnSize;
    }

    // ===================================================================================
    //                                                                     Internal Helper
    //                                                                     ===============
    protected String initCap(final String name) {
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    protected java.lang.reflect.Method findMethod(Class clazz, String methodName, Class[] argTypes) {
        try {
            return clazz.getMethod(methodName, argTypes);
        } catch (NoSuchMethodException ex) {
            String msg = "class=" + clazz + " method=" + methodName + "-" + java.util.Arrays.asList(argTypes);
            throw new RuntimeException(msg, ex);
        }
    }

    // ===================================================================================
    //                                                                      Basic Override
    //                                                                      ==============
    public int hashCode() {
        return dbmeta.hashCode() + columnDbName.hashCode();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof ColumnInfo)) {
            return false;
        }
        final ColumnInfo target = (ColumnInfo)obj;
        if (this.dbmeta == null || target.getDBMeta() == null) {
            return false;
        }
        if (!this.dbmeta.equals(target.getDBMeta())) {
            return false;
        }
        if (this.columnDbName == null || target.getColumnDbName() == null) {
            return false;
        }
        if (!this.columnDbName.equals(target.getColumnDbName())) {
            return false;
        }
        return true;
    }

    public String toString() {
        return dbmeta.getTableDbName() + "." + columnDbName;
    }
}
