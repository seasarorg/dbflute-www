package sample.dbflute.allcommon.cbean;


import sample.dbflute.allcommon.cbean.ckey.ConditionKey;
import sample.dbflute.allcommon.cbean.coption.ConditionOption;
import sample.dbflute.allcommon.cbean.coption.FromToOption;
import sample.dbflute.allcommon.cbean.coption.LikeSearchOption;
import sample.dbflute.allcommon.cbean.coption.InScopeOption;
import sample.dbflute.allcommon.cbean.cvalue.ConditionValue;
import sample.dbflute.allcommon.dbmeta.DBMeta;
import sample.dbflute.allcommon.dbmeta.DBMetaInstanceHandler;
import sample.dbflute.allcommon.cbean.sqlclause.SqlClause;

/**
 * The abstract class of condition-query.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class AbstractConditionQuery implements ConditionQuery {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Condition value for DUMMY. */
    protected static final ConditionValue DUMMY_CONDITION_VALUE = new ConditionValue();

    /** Object for DUMMY. */
    protected static final Object DUMMY_OBJECT = new Object();

    /** SQL clause. */
    protected final SqlClause _sqlClause;

    /** My alias name. */
    protected final String _aliasName;

    /** Nest level. */
    protected final int _nestLevel;

    // -----------------------------------------------------
    //                                          Foreign Info
    //                                          ------------
    /** Foreign property name. */
    protected String _foreignPropertyName;

    /** Relation Path. */
    protected String _relationPath;

    /** Child query. */
    protected final ConditionQuery _childQuery;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public AbstractConditionQuery(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        _childQuery = childQuery;
        _sqlClause = sqlClause;
        _aliasName = aliasName;
        _nestLevel = nestLevel;
    }

    // ===================================================================================
    //                                                                            Location
    //                                                                            ========
    /**
     * Get location.
     * 
     * @param columnPropertyName Column property name.
     * @param key Condition key.
     * @return Next nest level.
     */
    protected String getLocation(String columnPropertyName, ConditionKey key) {
        return getLocationBase(columnPropertyName) + "." + key.getConditionKey();
    }

    protected String getLocationBase() {
        final StringBuffer sb = new StringBuffer();
        ConditionQuery query = this;
        while (true) {
            if (query.isBaseQuery(query)) {
                sb.insert(0, "conditionQuery.");
                break;
            } else {
                sb.insert(0, "conditionQuery" + initCap(query.getForeignPropertyName()) + ".");
            }
            query = query.getChildQuery();
        }
        return sb.toString();
    }

    protected String getLocationBase(String columnPropertyName) {
        return getLocationBase() + columnPropertyName;
    }

    // ===================================================================================
    //                                                                         Union Query
    //                                                                         ===========
    /** The map of union query. */
    protected java.util.Map<String, ConditionQuery> _unionQueryMap = new java.util.LinkedHashMap<String, ConditionQuery>();

    /**
     * Get the map of union query.
     * 
     * @return The map of union query. (NotNull)
     */
    public java.util.Map<String, ConditionQuery> getUnionQueryMap() {// for Internal
        return _unionQueryMap;
    }

    /**
     * Set union query. {Internal}
     * <pre>
     * Add union query to condition bean.
     * </pre>
     * @param unionQuery Union query. (NotNull)
     */
    public void xsetUnionQuery(ConditionQuery unionQuery) {
        xsetupUnion(unionQuery, false, _unionQueryMap);
    }

    /** The map of union all query. */
    protected java.util.Map<String, ConditionQuery> _unionAllQueryMap = new java.util.LinkedHashMap<String, ConditionQuery>();

    /**
     * Get the map of union all query.
     * 
     * @return The map of union all query. (NotNull)
     */
    public java.util.Map<String, ConditionQuery> getUnionAllQueryMap() {// for Internal
        return _unionAllQueryMap;
    }

    /**
     * Set union all query. {Internal}
     * <pre>
     * Add union all query to condition bean.
     * </pre>
     * @param unionAllQuery Union all query. (NotNull)
     */
    public void xsetUnionAllQuery(ConditionQuery unionAllQuery) {
        xsetupUnion(unionAllQuery, true, _unionAllQueryMap);
    }

    protected void xsetupUnion(ConditionQuery unionQuery, boolean unionAll, java.util.Map<String, ConditionQuery> unionQueryMap) {
        if (unionQuery == null) {
            String msg = "The argument[unionQuery] should not be null.";
            throw new IllegalArgumentException(msg);
        }
        reflectRelationOnUnionQuery(this, unionQuery);// Reflect Relation!
        getSqlClause().copyIncludedSelectColumn(unionQuery.getSqlClause());// Reflect IncludedSelectColumn!
        final String key = (unionAll ? "unionAllQuery" : "unionQuery") + unionQueryMap.size();
        unionQueryMap.put(key, unionQuery);
        registerUnionQuery(unionQuery, unionAll, (unionAll ? "unionAllQueryMap" : "unionQueryMap") + "." + key);
    }

    /**
     * Reflect relation on union query.
     * 
     * @param baseQueryAsSuper Base query as super. (NotNull)
     * @param unionQueryAsSuper Union query as super. (NotNull)
     */
    abstract protected void reflectRelationOnUnionQuery(ConditionQuery baseQueryAsSuper, ConditionQuery unionQueryAsSuper);

    /**
     * Has union query or union all query?
     * 
     * @return Determination.
     */
    public boolean hasUnionQueryOrUnionAllQuery() {
        return !_unionQueryMap.isEmpty() || !_unionAllQueryMap.isEmpty();
    }

    /**
     * Get the list of union query.
     * 
     * @return The list of union query. (NotNull)
     */
    public java.util.List<ConditionQuery> getUnionQueryList() {
        return new java.util.ArrayList<ConditionQuery>(_unionQueryMap.values());
    }

    /**
     * Get the list of union all query.
     * 
     * @return The list of union all query. (NotNull)
     */
    public java.util.List<ConditionQuery> getUnionAllQueryList() {
        return new java.util.ArrayList<ConditionQuery>(_unionAllQueryMap.values());
    }

    // ===================================================================================
    //                                                                            Register
    //                                                                            ========
    // ----------------------------------------
    //                          Include-As-Mine
    //                          ---------------
    /**
     * Register included-select-column.
     * 
     * @param aliasName Alias name. This should not contain comma. (NotNull)
     * @param realColumnName Real column name. This should not contain comma. (NotNull)
     */
    protected void registerIncludedSelectColumn(String aliasName, String realColumnName) {
        assertAliasName(aliasName);
        assertColumnName(realColumnName);
        getSqlClause().registerIncludedSelectColumn(aliasName, realColumnName);
    }

    // ----------------------------------------
    //                                   Normal
    //                                   ------
    protected void registerQuery(ConditionKey key, Object value, ConditionValue cvalue
                                 , String colName, String capPropName, String uncapPropName) {
        if (key.isValidRegistration(cvalue, value, key.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
            setupConditionValueAndRegisterWhereClause(key, value, cvalue, colName, capPropName, uncapPropName);
        }
    }

    protected void registerQuery(ConditionKey key, Object value, ConditionValue cvalue
                                 , String colName, String capPropName, String uncapPropName, ConditionOption option) {
        if (key.isValidRegistration(cvalue, value, key.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
            setupConditionValueAndRegisterWhereClause(key, value, cvalue, colName, capPropName, uncapPropName, option);
        }
    }

    // ----------------------------------------
    //                                   FromTo
    //                                   ------
    protected void registerFromToQuery(java.util.Date fromDate, java.util.Date toDate, ConditionValue cvalue
                                 , String colName, String capPropName, String uncapPropName, FromToOption option) {
        {
            final java.util.Date filteredFromDate = option.filterFromDate(fromDate);
            final ConditionKey fromKey = option.getFromDateConditionKey();
            if (fromKey.isValidRegistration(cvalue, filteredFromDate, fromKey.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
                setupConditionValueAndRegisterWhereClause(fromKey, filteredFromDate, cvalue, colName, capPropName, uncapPropName);
            }
        }
        {
            final java.util.Date filteredToDate = option.filterToDate(toDate);
            final ConditionKey toKey = option.getToDateConditionKey();
            if (toKey.isValidRegistration(cvalue, filteredToDate, toKey.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
                setupConditionValueAndRegisterWhereClause(toKey, filteredToDate, cvalue, colName, capPropName, uncapPropName);
            }
        }
    }

    // ----------------------------------------
    //                               LikeSearch
    //                               ----------
    protected void registerLikeSearchQuery(ConditionKey key, String value, ConditionValue cvalue
                                     , String colName, String capPropName, String uncapPropName, LikeSearchOption option) {
        if (key.isValidRegistration(cvalue, value, key.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
            if (value != null && option.isSplit()) {
                final String[] strArray = option.generateSplitValueArray(value);
                for (int i=0; i < strArray.length; i++) {
                    final String currentValue = strArray[i];
                    setupConditionValueAndRegisterWhereClause(key, currentValue, cvalue, colName, capPropName, uncapPropName, option);

                    // Callback for LikeAsOr!
                    final java.util.List<LikeSearchOption.LikeAsOrCallback> callbackList = option.getLikeAsOrCallbackList();
                    if (!callbackList.isEmpty()) {
                        getSqlClause().makeAdditionalConditionAsOrEffective();
                        for (java.util.Iterator ite = callbackList.iterator(); ite.hasNext(); ) {
                            final LikeSearchOption.LikeAsOrCallback likeAsOrCallback = (LikeSearchOption.LikeAsOrCallback)ite.next();
                            final String additionalTargetPropertyName = likeAsOrCallback.getAdditionalTargetPropertyName();
                            final String filteredValue = likeAsOrCallback.filterValue(currentValue);
                            final LikeSearchOption optionDeepCopy = (LikeSearchOption)option.createDeepCopy();
                            optionDeepCopy.clearLikeAsOrCallback();
                            final LikeSearchOption filteredOption = likeAsOrCallback.filterOption(optionDeepCopy);
                            invokeSetterLikeSearch(additionalTargetPropertyName, filteredValue, filteredOption);
                        }
                        getSqlClause().ignoreAdditionalConditionAsOr();
                    }
                }
            } else {
                setupConditionValueAndRegisterWhereClause(key, value, cvalue, colName, capPropName, uncapPropName, option);
            }
        }
    }

    // ----------------------------------------
    //                                  InScope
    //                                  -------
    protected void registerInScopeQuery(ConditionKey key, String value, ConditionValue cvalue
                                     , String colName, String capPropName, String uncapPropName, InScopeOption option) {
        if (key.isValidRegistration(cvalue, value, key.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
            if (value != null && option.isSplit()) {
                final String[] strArray = option.generateSplitValueArray(value);
                final java.util.List<String> realValueList = new java.util.ArrayList<String>();
                for (int i=0; i < strArray.length; i++) {
                    final String currentValue = strArray[i];
                    realValueList.add(currentValue);
                }
                setupConditionValueAndRegisterWhereClause(key, realValueList, cvalue, colName, capPropName, uncapPropName, option);
            } else {
                setupConditionValueAndRegisterWhereClause(key, value, cvalue, colName, capPropName, uncapPropName, option);
            }
        }
    }

    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName) {
        key.setupConditionValue(cvalue, value, getLocation(uncapPropName, key));// If Java, UncapProp!
        getSqlClause().registerWhereClause(getRealColumnName(colName), key, cvalue);
    }

    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName, ConditionOption option) {
        key.setupConditionValue(cvalue, value, getLocation(uncapPropName, key), option);// If Java, UncapProp!
        getSqlClause().registerWhereClause(getRealColumnName(colName), key, cvalue, option);
    }

    // ----------------------------------------
    //                                   Inline
    //                                   ------
    protected void registerInlineQuery(ConditionKey key, Object value, ConditionValue cvalue
                                       , String colName, String capPropName, String uncapPropName) {
        if (key.isValidRegistration(cvalue, value, key.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
            key.setupConditionValue(cvalue, value, getLocation(uncapPropName, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(colName, key, cvalue);
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), colName, key, cvalue);
            }
        }
    }

    protected void registerInlineQuery(ConditionKey key, Object value, ConditionValue cvalue
                                       , String colName, String capPropName, String uncapPropName, ConditionOption option) {
        if (key.isValidRegistration(cvalue, value, key.getConditionKey() + " of " + getRealAliasName() + "." + uncapPropName)) {
            key.setupConditionValue(cvalue, value, getLocation(uncapPropName, key), option);// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(colName, key, cvalue, option);
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), colName, key, cvalue, option);
            }
        }
    }

    // -----------------------------------------------------
    //                                       InScopeSubQuery
    //                                       ---------------
    protected void registerInScopeSubQuery(ConditionQuery subQuery
                                 , String columnName, String relatedColumnName, String propertyName) {
        final String realColumnName = getInScopeSubQueryRealColumnName(columnName);
        final String subQueryClause = getInScopeSubQuerySql(subQuery, relatedColumnName, propertyName);
        registerWhereClause(realColumnName + " in (" + subQueryClause + ")");
    }

    protected String getInScopeSubQueryRealColumnName(String columnName) {
        return getRealColumnName(columnName);
    }

    protected String getInScopeSubQuerySql(ConditionQuery subQuery
                                 , String relatedColumnName, String propertyName) {
        final String selectClause = "select " + subQuery.getTableDbName() + "." + relatedColumnName;
        String clause = subQuery.getSqlClause().getClauseWithoutIncludedOrderBySqlSuffix();
        clause = replaceString(clause, ".conditionQuery.", "." + getLocationBase(propertyName) + ".");// Very Important!
        return replaceString(clause, SqlClause.INCLUDE_SELECT_CLAUSE_MARK, selectClause);
    }

    // -----------------------------------------------------
    //                                        ExistsSubQuery
    //                                        --------------
    protected void registerExistsSubQuery(ConditionQuery subQuery
                                 , String columnName, String relatedColumnName, String propertyName) {
        final String realColumnName = getExistsSubQueryRealColumnName(columnName);
        final String subQueryClause = getExistsSubQuerySql(subQuery, realColumnName, relatedColumnName, propertyName);
        registerWhereClause("exists (" + subQueryClause + ")");
    }

    protected String getExistsSubQueryRealColumnName(String columnName) {
        return getRealColumnName(columnName);
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    // *Unsupport ExistsSubQuery as inline because it's so dangerous.
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

    protected String getExistsSubQuerySql(ConditionQuery subQuery
                                 , String realColumnName, String relatedColumnName, String propertyName) {
        final String selectClause = "select " + subQuery.getTableDbName() + "." + relatedColumnName;
        String clause = subQuery.getSqlClause().getClauseWithoutIncludedOrderBySqlSuffix();
        clause = replaceString(clause, ".conditionQuery.", "." + getLocationBase(propertyName) + ".");// Very Important!
        final String joinCondition = relatedColumnName + " = " + realColumnName;
        final String finalClause;
        final int whereIndex = clause.indexOf(" where ");
        final int whereEndIndex = whereIndex + " where ".length();
        if (whereIndex >= 0) {
            finalClause = clause.substring(0, whereEndIndex) + joinCondition + " and " + clause.substring(whereEndIndex);
        } else {
            finalClause = clause + " where " + joinCondition;
        }
        return replaceString(finalClause, SqlClause.INCLUDE_SELECT_CLAUSE_MARK, selectClause);
    }

    protected void registerWhereClause(String whereClause) {
        getSqlClause().registerWhereClause(whereClause);
    }

    protected void registerInlineWhereClause(String whereClause) {
        if (isBaseQuery(this)) {
            getSqlClause().registerBaseTableInlineWhereClause(whereClause);
        } else {
            getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), whereClause);
        }
    }


    // ----------------------------------------
    //                               UnionQuery
    //                               ----------
    public void registerUnionQuery(ConditionQuery unionQuery, boolean unionAll, String unionQueryPropertyName) {
        final String unionQueryClause = getUnionQuerySql(unionQuery, unionQueryPropertyName);
        getSqlClause().registerUnionQuery(unionQueryClause, unionAll);
    }

    protected String getUnionQuerySql(ConditionQuery unionQuery, String unionQueryPropertyName) {
        final String selectClause = unionQuery.getSqlClause().getIncludedSelectColumnClause();
        final String queryClause = unionQuery.getSqlClause().getFromClause() + " " + unionQuery.getSqlClause().getWhereClause();
        final String oldStr = ".conditionQuery.";
        final String newStr = ".conditionQuery." + unionQueryPropertyName + ".";
        final String replacedClause = replaceString(queryClause, oldStr, newStr);// Very Important!
        return selectClause + " " + replacedClause;
    }

    // ===================================================================================
    //                                                                       Name Resolver
    //                                                                       =============
    /**
     * Resolve join alias name.
     * 
     * @param relationPath Relation path. (NotNull)
     * @param nestLevel Nest level.
     * @return Resolved join alias name. (NotNull)
     */
    protected String resolveJoinAliasName(String relationPath, int nestLevel) {
        return getSqlClause().resolveJoinAliasName(relationPath, nestLevel);
    }

    protected String resolveNestLevelExpression(String name) {
        return getSqlClause().resolveNestLevelExpression(name, getNestLevel());
    }

    // ===================================================================================
    //                                                                     Fixed Condition
    //                                                                     ===============
    protected String prepareFixedCondition(String fixedCondition, String localAliasName, String foreignAliasName) {
        fixedCondition = replaceString(fixedCondition, "$$alias$$", foreignAliasName);
        fixedCondition = replaceString(fixedCondition, "$$foreignAlias$$", foreignAliasName);
        fixedCondition = replaceString(fixedCondition, "$$localAlias$$", localAliasName);
        return fixedCondition;
    }

    // ===================================================================================
    //                                                                              Invoke
    //                                                                              ======
    /**
     * The implementation.
     * 
     * @param columnFlexibleName Column flexiblename. (NotNull and NotEmpty)
     * @return Condition-value. (NotNull)
     */
    public ConditionValue invokeGetter(String columnFlexibleName) {
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(getTableDbName());
        final String columnCapPropName = initCap(dbmeta.findPropertyName(columnFlexibleName));
        String methodName = "get" + columnCapPropName;
        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The columnFlexibleName is not existing in this table: columnFlexibleName=" + columnFlexibleName;
            msg = msg + " tableName=" + getTableDbName() + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            final Object result = method.invoke(this, new Object[]{});
            return (ConditionValue)result;
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }


    public void invokeSetterEqual(String columnFlexibleName, Object value) {
        invokeSetter(columnFlexibleName, value, "equal");
    }

    public void invokeSetterNotEqual(String columnFlexibleName, Object value) {
        invokeSetter(columnFlexibleName, value, "notEqual");
    }

    public void invokeSetterGreaterThan(String columnFlexibleName, Object value) {
        invokeSetter(columnFlexibleName, value, "greaterThan");
    }

    public void invokeSetterLessThan(String columnFlexibleName, Object value) {
        invokeSetter(columnFlexibleName, value, "lessThan");
    }

    public void invokeSetterGreaterEqual(String columnFlexibleName, Object value) {
        invokeSetter(columnFlexibleName, value, "greaterEqual");
    }

    public void invokeSetterLessEqual(String columnFlexibleName, Object value) {
        invokeSetter(columnFlexibleName, value, "lessEqual");
    }

    protected void invokeSetter(String columnFlexibleName, Object value, String conditionKeyName) {
        if (value == null) {
            return;
        }
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(getTableDbName());
        final String columnCapPropName = initCap(dbmeta.findPropertyName(columnFlexibleName));
        String methodName = "set" + columnCapPropName + "_" + conditionKeyName.substring(0, 1).toUpperCase() + conditionKeyName.substring(1);
        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{value.getClass()});
        } catch (NoSuchMethodException e) {
            String msg = "The columnFlexibleName is not existing in this table: columnFlexibleName=" + columnFlexibleName;
            msg = msg + " tableName=" + getTableDbName() + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            method.invoke(this, new Object[]{value});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    protected void invokeSetterLikeSearch(String columnFlexibleName, Object value, LikeSearchOption option) {
        if (value == null) {
            return;
        }
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(getTableDbName());
        final String columnCapPropName = initCap(dbmeta.findPropertyName(columnFlexibleName));
        String methodName = "set" + columnCapPropName + "_" + "likeSearch".substring(0, 1).toUpperCase() + "likeSearch".substring(1);
        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{value.getClass(), LikeSearchOption.class});
        } catch (NoSuchMethodException e) {
            String msg = "The columnFlexibleName is not existing in this table: columnFlexibleName=" + columnFlexibleName;
            msg = msg + " tableName=" + getTableDbName() + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            method.invoke(this, new Object[]{value, option});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    public void invokeAddOrderByAsc(String columnFlexibleName) {
        invokeOrderBy(columnFlexibleName, true);
    }

    public void invokeAddOrderByDesc(String columnFlexibleName) {
        invokeOrderBy(columnFlexibleName, false);
    }

    protected void invokeOrderBy(String columnFlexibleName, boolean isAsc) {
        String ascDesc = null;
        if (isAsc) {
            ascDesc = "Asc";
        } else {
            ascDesc = "Desc";
        }
        final DBMeta dbmeta = DBMetaInstanceHandler.findDBMeta(getTableDbName());
        final String columnCapPropName = initCap(dbmeta.findPropertyName(columnFlexibleName));
        final String methodName = "addOrderBy_" + columnCapPropName + "_" + ascDesc;

        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The columnFlexibleName is not existing in this table: columnFlexibleName=" + columnFlexibleName;
            msg = msg + " tableName=" + getTableDbName() + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    // ===================================================================================
    //                                                                       Foreign Query
    //                                                                       =============
    /**
     * The implementation.
     * 
     * @param foreignPropertyName Foreign property name. (NotNull and NotEmpty and Both OK -- InitCap or not)
     * @return Foreign condition-query. (NotNull)
     */
    public ConditionQuery getForeignConditionQuery(String foreignPropertyName) {
        final String methodName = "query" + foreignPropertyName.substring(0, 1).toUpperCase() + foreignPropertyName.substring(1);
        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The foreignPropertyName is not existing in this table: foreignPropertyName=" + foreignPropertyName;
            msg = msg + " tableName=" + getTableDbName() + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            return (ConditionQuery)method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    // ===================================================================================
    //                                                                              Helper
    //                                                                              ======
    protected final String replaceString(String text, String fromText, String toText) {
        if(text == null || fromText == null || toText == null)
            return null;
        StringBuffer buf = new StringBuffer(100);
        int pos = 0;
        int pos2 = 0;
        do {
            pos = text.indexOf(fromText, pos2);
            if(pos == 0) {
                buf.append(toText);
                pos2 = fromText.length();
            } else
            if(pos > 0) {
                buf.append(text.substring(pos2, pos));
                buf.append(toText);
                pos2 = pos + fromText.length();
            } else {
                buf.append(text.substring(pos2));
                return buf.toString();
            }
        } while(true);
    }

    /**
     * Initcap string.
     * 
     * @param col Target collection. (Nullable)
     * @param <PROPERTY_TYPE> The type of property.
     * @return List. (Nullable: If the argument is null, returns null.)
     */
    protected <PROPERTY_TYPE> java.util.List<PROPERTY_TYPE> convertToList(java.util.Collection<PROPERTY_TYPE> col) {
        if (col == null) {
            return null;
        }
        if (col instanceof java.util.List) {
            return (java.util.List<PROPERTY_TYPE>)col;
        }
        return new java.util.ArrayList<PROPERTY_TYPE>(col);
    }

    /**
     * Filter removing empty-string.
     * If the value is null or empty-string, returns null.
     * 
     * @param value Query-value-string. (Nullable)
     * @return Filtered value. (Nullable)
     */
    protected String filterRemoveEmptyString(String value) {
        return ((value != null && !"".equals(value)) ? value : null);
    }

    /**
     * Filter removing empty-string from the list.
     * If the list is null or empty-string, returns null.
     * 
     * @param ls List. (Nullable)
     * @return Filtered list. (Nullable)
     */
    protected java.util.List<String> filterRemoveEmptyStringFromList(java.util.List<String> ls) {
        if (ls == null) {
            return null;
        }
        java.util.List<String> newList = new java.util.ArrayList<String>();
        for (final java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final String str = (String)ite.next();
            if (str == null || "".equals(str)) {
                continue;
            }
            newList.add(str);
        }
        return newList;
    }

    /**
     * Initcap string.
     * 
     * @param str Target string. (NotNull)
     * @return Initcaped string. (NotNull)
     */
    protected String initCap(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    // ----------------------------------------------------------------
    //                                                    Assert Object
    //                                                    -------------
    /**
     * Assert that the object is not null.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     * @exception IllegalArgumentException
     */
    protected void assertObjectNotNull(String variableName, Object value) {
        if (variableName == null) {
            String msg = "The value should not be null: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
        if (value == null) {
            String msg = "The value should not be null: variableName=" + variableName;
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the column-name is not null and is not emtpy and does not contain comma.
     * 
     * @param columnName Column-name. (NotNull)
     * @exception IllegalArgumentException
     */
    protected void assertColumnName(String columnName) {
        if (columnName == null) {
            String msg = "The columnName should not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (columnName.trim().length() == 0) {
            String msg = "The columnName should not be empty-string.";
            throw new IllegalArgumentException(msg);
        }
        if (columnName.indexOf(",") >= 0) {
            String msg = "The columnName should not contain comma ',': " + columnName;
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the alias-name is not null and is not emtpy and does not contain comma.
     * 
     * @param aliasName Alias-name. (NotNull)
     * @exception IllegalArgumentException
     */
    protected void assertAliasName(String aliasName) {
        if (aliasName == null) {
            String msg = "The aliasName should not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (aliasName.trim().length() == 0) {
            String msg = "The aliasName should not be empty-string.";
            throw new IllegalArgumentException(msg);
        }
        if (aliasName.indexOf(",") >= 0) {
            String msg = "The aliasName should not contain comma ',': " + aliasName;
            throw new IllegalArgumentException(msg);
        }
    }


    // ----------------------------------------------------------------
    //                                                    Assert String
    //                                                    -------------
    /**
     * Assert that the entity is not null and not trimmed empty.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     */
    protected void assertStringNotNullAndNotTrimmedEmpty(String variableName, String value) {
        assertObjectNotNull("variableName", variableName);
        assertObjectNotNull("value", value);
        if (value.trim().length() ==0) {
            String msg = "The value should not be empty: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
    }


    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    /**
     * Get child query.
     * 
     * @return Child query. (Nullable)
     */
    public ConditionQuery getChildQuery() {
        return _childQuery;
    }

    /**
     * Get sql clause.
     * 
     * @return Sql clause. (NotNull)
     */
    public SqlClause getSqlClause() {
        return _sqlClause;
    }

    /**
     * Get alias name.
     * 
     * @return Alias name. (NotNull)
     */
    public String getAliasName() {
        return _aliasName;
    }

    /**
     * Get nest level.
     * 
     * @return Nest level.
     */
    public int getNestLevel() {
        return _nestLevel;
    }

    /**
     * Get next nest level.
     * 
     * @return Next nest level.
     */
    public int getNextNestLevel() {
        return _nestLevel+1;
    }

    /**
     * Is base query?
     * 
     * @param query Condition query. (NotNull)
     * @return Determination.
     */
    public boolean isBaseQuery(ConditionQuery query) {
        return (query.getChildQuery() == null);
    }

    // -----------------------------------------------------
    //                                             Real Name
    //                                             ---------
    /**
     * Get real alias name(that has nest level mark).
     * 
     * @return Real alias name.
     */
    public String getRealAliasName() {
        return getAliasName();
    }

    /**
     * Get real column name(with real alias name).
     * 
     * @param columnName Column name without alias name. This should not contain comma. (NotNull)
     * @return Real column name.
     */
    public String getRealColumnName(String columnName) {
        assertColumnName(columnName);
        return buildRealColumnName(getRealAliasName(), columnName);
    }

    /**
     * Build real column name.
     * 
     * @param aliasName Alias name. (NotNull)
     * @param columnName Column name. (NotNull)
     * @return Real column name. (NotNull)
     */
    protected String buildRealColumnName(String aliasName, String columnName) {
        return aliasName + "." + columnName;
    }

    // -----------------------------------------------------
    //                                          Foreign Info
    //                                          ------------
    public String getForeignPropertyName() {
        return _foreignPropertyName;
    }

    public void setForeignPropertyName(String foreignPropertyName) {
        this._foreignPropertyName = foreignPropertyName;
    }

    public String getRelationPath() {
        return _relationPath;
    }

    public void setRelationPath(String relationPath) {
        this._relationPath = relationPath;
    }
}
