package sample.dbflute.allcommon.cbean;

import sample.dbflute.allcommon.cbean.sqlclause.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Condition-Bean context. (referring to s2pager)
 * 
 * @author DBFlute(AutoGenerator)
 */
public class ConditionBeanContext {

    /** Log-instance. */
    private static final Log _log = LogFactory.getLog(ConditionBeanContext.class);

    // ===================================================================================
    //                                                                        Thread Local
    //                                                                        ============
    /** The thread-local for this. */
    private static final ThreadLocal<ConditionBean> _threadLocal = new ThreadLocal<ConditionBean>();

    /**
     * Get condition-bean on thread.
     * 
     * @return Condition-bean context. (Nullable)
     */
    public static ConditionBean getConditionBeanOnThread() {
        return (ConditionBean)_threadLocal.get();
    }

    /**
     * Set condition-bean on thread.
     * 
     * @param cb Condition-bean. (NotNull)
     */
    public static void setConditionBeanOnThread(ConditionBean cb) {
        if (cb == null) {
            String msg = "The argument[cb] must not be null.";
            throw new IllegalArgumentException(msg);
        }
        _threadLocal.set(cb);
    }

    /**
     * Is existing condition-bean on thread?
     * 
     * @return Determination.
     */
    public static boolean isExistConditionBeanOnThread() {
        return (_threadLocal.get() != null);
    }

    /**
     * Clear condition-bean on thread.
     */
    public static void clearConditionBeanOnThread() {
        _threadLocal.set(null);
    }

    // ===================================================================================
    //                                         Initialize against the ClassLoader Headache
    //                                         ===========================================
    public static void initialize() {
        boolean debugEnabled = _log.isDebugEnabled();
        // Against the ClassLoader Headache!
        if (debugEnabled) {
            _log.debug("/---------------------------------------- Initialize against the ClassLoader Headache!");
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.SimplePagingBean.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.coption.FromToOption.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.coption.LikeSearchOption.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.coption.InScopeOption.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.grouping.GroupingOption.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.grouping.GroupingRowEndDeterminer.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.grouping.GroupingRowResource.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.grouping.GroupingRowSetupper.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.pagenavi.PageNumberLink.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.cbean.pagenavi.PageNumberLinkSetupper.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        {
            final Class clazz = sample.dbflute.allcommon.jdbc.CursorHandler.class;
            if (debugEnabled) { _log.debug("...Loading class of " + clazz.getName() + ": " + clazz.getClassLoader()); }
        }
        _log.debug("----------/");
    }

    // ===================================================================================
    //                                                                      Type Judgement
    //                                                                      ==============
    /**
     * Is the argument condition-bean?
     * 
     * @param dtoInstance Dto instance.
     * @return Determination.
     */
    public static boolean isTheArgumentConditionBean(final Object dtoInstance) {
        if (dtoInstance instanceof ConditionBean) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Is the type condition-bean?
     * 
     * @param dtoClass DtoClass.
     * @return Determination.
     */
    public static boolean isTheTypeConditionBean(final Class dtoClass) {
        if (ConditionBean.class.isAssignableFrom(dtoClass)) {
            return true;
        } else {
            return false;
        }
    }

    // ===================================================================================
    //                                                                        Column Alias
    //                                                                        ============
    public static final java.util.Map<Class, java.util.Map<String, String>> _selectClauseColumnAliasContainerMap = new java.util.HashMap<Class, java.util.Map<String, String>>();

    public static void addColumnAliasInfo(Class conditionBeanClass, String columnFullName, String columnAliasName) {
        if (_selectClauseColumnAliasContainerMap.containsKey(conditionBeanClass)) {
            final java.util.Map<String, String> selectClauseColumnAliasMap = (java.util.Map<String, String>)_selectClauseColumnAliasContainerMap.get(conditionBeanClass);
            selectClauseColumnAliasMap.put(columnFullName, columnAliasName);
        } else {
            final java.util.Map<String, String> selectClauseColumnAliasMap = new java.util.HashMap<String, String>();
            _selectClauseColumnAliasContainerMap.put(conditionBeanClass, selectClauseColumnAliasMap);
            selectClauseColumnAliasMap.put(columnFullName, columnAliasName);
        }
    }

    public static java.util.Map<String, String> getSelectClauseColumnAliasMap(Class conditionBeanClass) {
        return (java.util.Map<String, String>)_selectClauseColumnAliasContainerMap.get(conditionBeanClass);
    }

    // ===================================================================================
    //                                                                        Product Name
    //                                                                        ============
    public static final String DB_NAME_DERBY = "derby";
    public static final String DB_NAME_H2 = "h2";
    public static final String DB_NAME_ORACLE = "oracle";
    public static final String DB_NAME_MYSQL = "mysql";
    public static final String DB_NAME_POSTGRESQL = "postgresql";
    public static final String DB_NAME_FIREBIRD = "firebird";
    public static final String DB_NAME_MSSQL = "mssql";
    public static final String DB_NAME_SYBASE = "sybase";
    public static final String DB_NAME_DB2 = "db2";

    protected static final java.util.Map<String, String> _driverHintDatabaseProductNameMap;
    protected static final java.util.List<String> _targetDatabaseProductNameList = new java.util.ArrayList<String>();
    static {
        final java.util.Map<String, String> tmpMap = new java.util.LinkedHashMap<String, String>();
        tmpMap.put("org.apache.derby", DB_NAME_DERBY);
        tmpMap.put("org.h2", DB_NAME_H2);
        tmpMap.put("oracle", DB_NAME_ORACLE);
        tmpMap.put("mysql", DB_NAME_MYSQL);
        tmpMap.put("postgresql", DB_NAME_POSTGRESQL);
        tmpMap.put("firebird", DB_NAME_FIREBIRD);
        tmpMap.put("sqlserver", DB_NAME_MSSQL);
        tmpMap.put("sybase", DB_NAME_SYBASE);
        tmpMap.put("db2", DB_NAME_DB2);
        _driverHintDatabaseProductNameMap = java.util.Collections.unmodifiableMap(tmpMap);
    }

    public static boolean setupDatabaseProductNameByDriverClassName(String driverClassName) {
        final java.util.Set<String> keySet = _driverHintDatabaseProductNameMap.keySet();
        for (final java.util.Iterator ite = keySet.iterator(); ite.hasNext(); ) {
            final String driverHint = (String)ite.next();
            if (driverClassName.indexOf(driverHint) >= 0) {
                final String databaseProductName = (String)_driverHintDatabaseProductNameMap.get(driverHint);
                setDatabaseProductName(databaseProductName);
                return true;
            }
        }
        return false;
    }

    /** The database product name. */
    private static String _databaseProductName;

    /**
     * Get database product name.
     * 
     * @return Database product name.
     */
    public static String getDatabaseProductName() {
        return _databaseProductName;
    }

    /**
     * Set database product name.
     * 
     * @param name Database product name. (NotNull)
     */
    public static void setDatabaseProductName(String name) {
        if (_databaseProductName != null) {
            String msg = "Already set up: current=" + _databaseProductName + " your=" + name;
            throw new IllegalStateException(msg);
        }
        _databaseProductName = name;
    }

    // ===================================================================================
    //                                                                   SqlClause Creator
    //                                                                   =================
    public static SqlClause createSqlClause(ConditionBean cb) {
        final String tableSqlName = cb.getTableSqlName();
        return createSqlClause(tableSqlName);
    }

    public static SqlClause createSqlClause(String tableDbName) {
        final String databaseProductName = getDatabaseProductName();
        if (databaseProductName == null) {
            return new SqlClauseH2(tableDbName);
        }
        final String name = databaseProductName.toLowerCase();
        if (name.equalsIgnoreCase(DB_NAME_DERBY)) {
            return new SqlClauseDerby(tableDbName);
        } else if (name.equalsIgnoreCase(DB_NAME_H2)) {
            return new SqlClauseH2(tableDbName);
        } else if (name.equalsIgnoreCase(DB_NAME_ORACLE)) {
            return new SqlClauseOracle(tableDbName);
        } else if (name.equalsIgnoreCase(DB_NAME_FIREBIRD)) {
            return new SqlClauseFirebird(tableDbName);
        } else if (name.equalsIgnoreCase(DB_NAME_MYSQL)) {
            return new SqlClauseMySql(tableDbName);
        } else if (name.equalsIgnoreCase(DB_NAME_POSTGRESQL)) {
            return new SqlClausePostgreSql(tableDbName);
        } else if (name.equalsIgnoreCase(DB_NAME_MSSQL)) {
            return new SqlClauseSqlServer(tableDbName);
        } else if (name.equalsIgnoreCase(DB_NAME_DB2)) {
            return new SqlClauseDb2(tableDbName);
        } else {
            return new SqlClauseH2(tableDbName);
        }
    }
}
