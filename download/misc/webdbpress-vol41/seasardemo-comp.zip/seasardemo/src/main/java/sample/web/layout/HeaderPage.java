package sample.web.layout;

public class HeaderPage extends AbstractLayoutPage {

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		return null;
	}

}
