package sample.dbflute.cbean.nss;


import sample.dbflute.cbean.cq.DeptCQ;


/**
 * The nest select setupper of DEPT.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class DeptNss {

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    /** Base query. */
    protected DeptCQ _query;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    /**
     * Constructor.
     * 
     * @param query Base query. (NotNull)
     */
    public DeptNss(DeptCQ query) {
        _query = query;
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    /**
     * Has condition query?
     * 
     * @return Determination.
     */
    public boolean hasConditionQuery() {
        return _query != null;
    }

    // ===================================================================================
    //                                                                             With...
    //                                                                             =======
  
    // ===================================================================================
    //                                                                              Helper
    //                                                                              ======
    protected void assertConditionQuery() {
        if (!hasConditionQuery()) {
            String msg = "The query should not be null.";
            throw new IllegalStateException(msg);
        }
    }
}
