package sample.dbflute.allcommon.cbean.grouping;

/**
 * The interface of grouping row setupper.
 * 
 * @param <ROW> The type of row.
 * @param <ENTITY> The type of entity.
 * @author DBFlute(AutoGenerator)
 */
public interface GroupingRowSetupper<ROW, ENTITY> {

    /**
     * Set up grouping row object.
     * 
     * @param groupingRowResource Grouping row resource. (NotNull)
     * @return Grouping row object. (NotNull)
     */
    public ROW setup(GroupingRowResource<ENTITY> groupingRowResource);
}
