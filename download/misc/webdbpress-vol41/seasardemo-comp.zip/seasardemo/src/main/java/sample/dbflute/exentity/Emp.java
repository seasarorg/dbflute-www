package sample.dbflute.exentity;


/**
 * The entity of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class Emp extends sample.dbflute.bsentity.BsEmp {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
}
