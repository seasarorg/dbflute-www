package sample.dbflute.allcommon.cbean.pagenavi;


/**
 * The class of page number link.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class PageNumberLink implements java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    // ===================================================================================
    //                                                                           Attribute
    //                                                                           =========
    protected int _pageNumberElement;

    protected boolean _current;

    protected String _pageNumberLinkHref;

    // ===================================================================================
    //                                                                         Constructor
    //                                                                         ===========
    public PageNumberLink() {
    }

    // ===================================================================================
    //                                                                         Initializer
    //                                                                         ===========
    public PageNumberLink initialize(int pageNumberElement, boolean current, String pageNumberLinkHref) {
        setPageNumberElement(pageNumberElement);
        setCurrent(current);
        setPageNumberLinkHref(pageNumberLinkHref);
        return this;
    }

    // ===================================================================================
    //                                                                            Accessor
    //                                                                            ========
    public int getPageNumberElement() {
        return _pageNumberElement;
    }

    public void setPageNumberElement(int pageNumberElement) {
        this._pageNumberElement = pageNumberElement;
    }

    public boolean isCurrent() {
        return _current;
    }

    public void setCurrent(boolean current) {
        this._current = current;
    }

    public String getPageNumberLinkHref() {
        return _pageNumberLinkHref;
    }

    public void setPageNumberLinkHref(String pageNumberLinkHref) {
        this._pageNumberLinkHref = pageNumberLinkHref;
    }

    // ===================================================================================
    //                                                                      Basic Override
    //                                                                      ==============
    /**
     * The override.
     * 
     * @return View string. (NotNull)
     */
    public String toString() {
        final StringBuffer sb = new StringBuffer();

        sb.append(" pageNumberElement=").append(_pageNumberElement);
        sb.append(" pageNumberLinkHref=").append(_pageNumberLinkHref);
        sb.append(" current=").append(_current);

        return sb.toString();
    }
}
