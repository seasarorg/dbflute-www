package sample.dbflute.allcommon.dbmeta.hierarchy;


/**
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public interface HierarchySourceRow {

    public Object extractColumnValue(HierarchySourceColumn columnInfo);
}