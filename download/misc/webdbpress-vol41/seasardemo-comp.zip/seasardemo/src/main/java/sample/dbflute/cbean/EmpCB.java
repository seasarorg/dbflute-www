package sample.dbflute.cbean;


/**
 * The condition-bean of EMP.
 * 
 * @author DBFlute(AutoGenerator)
 */
@SuppressWarnings("unchecked")
public class EmpCB extends sample.dbflute.cbean.bs.BsEmpCB {
}
