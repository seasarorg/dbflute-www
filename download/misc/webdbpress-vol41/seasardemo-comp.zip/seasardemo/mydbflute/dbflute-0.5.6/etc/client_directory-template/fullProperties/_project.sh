#!/bin/sh

export MY_PROJECT_NAME=ldb

#export DBFLUTE_HOME=../mydbflute/dbflute-x.x.x
