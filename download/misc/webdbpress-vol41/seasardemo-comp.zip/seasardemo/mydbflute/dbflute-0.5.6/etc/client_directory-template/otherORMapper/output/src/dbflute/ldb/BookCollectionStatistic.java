package dbflute.ldb;


/**
 * The entity of BookCollectionStatistic.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class BookCollectionStatistic extends dbflute.ldb.BsBookCollectionStatistic {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
}
