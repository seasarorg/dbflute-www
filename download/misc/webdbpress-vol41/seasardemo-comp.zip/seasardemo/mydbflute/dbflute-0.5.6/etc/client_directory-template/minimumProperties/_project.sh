#!/bin/sh

export MY_PROJECT_NAME=minimumProperties

#export DBFLUTE_HOME=../mydbflute/dbflute-x.x.x
