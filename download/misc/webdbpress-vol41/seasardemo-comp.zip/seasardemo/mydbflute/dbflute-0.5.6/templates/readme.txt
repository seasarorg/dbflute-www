

# ========================================================================================
#                                                                                  [./doc]
#                                                                                  =======

It is the directory that save velocity template for document task.


  [./doc/Control.vm]        : Velocity template of main.
  [./doc/html/datamodel.vm] : Velocity template of data model as html.
  [./doc/html/table.vm]     : Velocity template of table list as html.






# ========================================================================================
#                                                                                   [./om]
#                                                                                   ======

It is the directory that save velocity template for om task. (VERY IMPORTANT)
This directory see [./sql].


