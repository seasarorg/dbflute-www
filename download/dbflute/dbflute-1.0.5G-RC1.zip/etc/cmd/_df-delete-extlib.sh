#!/bin/bash

if [ -d $DBFLUTE_HOME/lib/extlib ]; then
  rm -Rf $DBFLUTE_HOME/lib/extlib
fi
