#!/bin/bash

if [ -e $DBFLUTE_HOME/lib/extlib ]; then
  rm -Rf $DBFLUTE_HOME/lib/extlib
fi
